"use strict";
/* Sistema de Cupos Amaggi - frontend (sin build, JS plano) */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fdate = (iso) => (iso ? iso.slice(0, 10).split("-").reverse().join("/") : "");
const fdt = (s) => (s ? `${fdate(s)} ${s.slice(11, 16)}` : "");
const fnum = (n, d = 0) => Number(n ?? 0).toLocaleString("es-AR", { minimumFractionDigits: d, maximumFractionDigits: d });
const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
const badge = (s, label) => `<span class="badge b-${esc(s)}">${esc(label ?? s)}</span>`;
const fcuit = (c) => (c && c.length === 11 ? `${c.slice(0, 2)}-${c.slice(2, 10)}-${c.slice(10)}` : c || "");
// Corredor vacío en SIGAM = operación directa (sin corredor)
const fcorr = (c) => esc((c || "").trim() || "Directo");
const TN_CUPO = 30;
// Origen del cupo (de dónde sale la logística para cupear los contratos de compra):
//   STOP  = stock propio de Amaggi en puertos (sistema STOP)
//   VENTA = cupos de terceros que vienen de contratos de venta
const ORIGEN_LABEL = { STOP: "Stock propio", VENTA: "Contrato de venta" };
const ORIGEN_OPTS = [["STOP", "Stock propio (STOP)"], ["VENTA", "Contratos de venta (terceros)"]];
const origenBadge = (o) => badge(o, ORIGEN_LABEL[o] || o);
// CTG: Código de Trazabilidad de Granos (12 dígitos) de la Carta de Porte Electrónica (ARCA)
const fctg = (c) => (c ? `${c.slice(0, 4)} ${c.slice(4, 8)} ${c.slice(8)}` : "");
const ctgCelda = (r) => (r.ctg ? `<span style="font-variant-numeric:tabular-nums;white-space:nowrap">${fctg(r.ctg)}</span>`
  : ["ASIGNADO", "UTILIZADO"].includes(r.estado_visible || r.estado) ? `<small class="muted">sin CTG</small>` : "")
  + (r.stop_estado ? `<span class="sub" title="Estado informado por STOP">STOP: ${esc(r.stop_estado)}</span>` : "");
function ctgModal(r, after) {
  modal({
    title: `CTG del cupo ${r.codigo}`,
    body: `<p class="muted" style="margin:0">Código de Trazabilidad de Granos de la Carta de Porte Electrónica (12 dígitos).
      Para los cupos de stock propio va a llegar automáticamente desde STOP.</p>
      <label>CTG<input name="ctg" value="${esc(r.ctg || "")}" inputmode="numeric" maxlength="15" placeholder="000000000000" autocomplete="off"></label>`,
    buttons: [{ label: "Guardar CTG", cls: "primary", onClick: async (f) => {
      await api("POST", `/api/cupos/${r.id}/ctg`, fields(f)); toast(`✓ CTG guardado en el cupo ${r.codigo}`); (after || router)();
    } }],
    onOpen: (f) => $("[name=ctg]", f).focus(),
  });
}
const IMPORT_LABEL = { STOP: "CUPOS STOP", VENTA: "CUPOS VENTA", SIGAM_COMPRA: "CONTRATOS COMPRA", SIGAM_VENTA: "CONTRATOS VENTA", SIGAM: "CONTRATOS" };

let ME = null;
let FILTROS = { destinos: [], productos: [] };

async function api(method, url, body) {
  const opt = { method, headers: {} };
  if (body instanceof FormData) opt.body = body;
  else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
  const r = await fetch(url, opt);
  if (r.status === 401 && url !== "/api/login") { showLogin(); throw new Error("Sesión vencida"); }
  const data = r.headers.get("content-type")?.includes("json") ? await r.json() : null;
  if (!r.ok) {
    let msg = data?.detail ?? `Error ${r.status}`;
    if (Array.isArray(msg)) msg = msg.map((e) => `${e.loc?.slice(-1)[0]}: ${e.msg}`).join("; ");
    throw new Error(msg);
  }
  return data;
}
const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== "" && v != null)).toString();

function toast(msg, bad = false) {
  const t = $("#toast");
  // Si hay una ventana abierta, el aviso va adentro: si no, queda tapado por la ventana
  const dlg = $("#modal");
  (dlg.open ? dlg : document.body).appendChild(t);
  if (msg === "Failed to fetch") msg = "No hay conexión con el servidor. Verificá que esté encendido y volvé a intentar.";
  t.textContent = msg; t.className = "toast show" + (bad ? " bad" : "");
  clearTimeout(t._h); t._h = setTimeout(() => (t.className = "toast"), bad ? 8000 : 5000);
}
async function run(fn) { try { return await fn(); } catch (e) { toast(e.message, true); } }

/* ---------- modal ---------- */
function modal({ title, body, buttons = [], wide = false, onOpen }) {
  const dlg = $("#modal"), form = $("#modal-form");
  dlg.style.width = wide ? "min(1000px, calc(100vw - 32px))" : "";
  form.innerHTML = `<div class="m-head"><h2>${esc(title)}</h2></div><div class="m-body">${body}</div>
    <div class="m-foot"><button type="button" class="btn ghost" data-close>Cerrar</button>
    ${buttons.map((b, i) => `<button type="button" class="btn ${b.cls || ""}" data-i="${i}">${esc(b.label)}</button>`).join("")}</div>`;
  $("[data-close]", form).onclick = () => dlg.close();
  buttons.forEach((b, i) => {
    $(`[data-i="${i}"]`, form).onclick = async (ev) => {
      ev.target.disabled = true;
      try { if ((await b.onClick(form)) !== false) { dlg.close(); document.body.appendChild($("#toast")); } }
      catch (e) { toast(e.message, true); }
      finally { ev.target.disabled = false; }
    };
  });
  // al cerrar la ventana, el aviso vuelve a la página para que se siga viendo
  dlg.onclose = () => document.body.appendChild($("#toast"));
  dlg.showModal();
  onOpen?.(form);
  return form;
}
const confirmar = (title, text, label, onClick, cls = "primary") =>
  modal({ title, body: `<p>${text}</p>`, buttons: [{ label, cls, onClick }] });

/* ---------- tabla genérica ---------- */
function table(cols, data, { empty = "Sin resultados", rowAttr } = {}) {
  if (!data.length) return `<div class="table-wrap"><div class="empty">${esc(empty)}</div></div>`;
  return `<div class="table-wrap"><table><thead><tr>${cols.map((c) => `<th class="${c.num ? "num" : ""}">${c.h}</th>`).join("")}</tr></thead>
  <tbody>${data.map((r) => `<tr ${rowAttr ? rowAttr(r) : ""}>${cols.map((c) => `<td class="${c.num ? "num" : ""}">${c.f ? c.f(r) : esc(r[c.k])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
const opts = (list, sel, blank = "Todos") =>
  (blank !== null ? `<option value="">${blank}</option>` : "") + list.map((v) => {
    const [val, lab] = Array.isArray(v) ? v : [v, v];
    return `<option value="${esc(val)}" ${String(val) === String(sel ?? "") ? "selected" : ""}>${esc(lab)}</option>`;
  }).join("");
// En la URL "-" significa "vacío a propósito" (para no volver al valor por defecto).
const pv = (v, def) => (v === "-" ? "" : v ?? def);
const fields = (el) => { const o = {}; $$("[name]", el).forEach((i) => (o[i.name] = i.type === "checkbox" ? i.checked : i.value.trim())); return o; };

/* ---------- navegación ---------- */
// Menú del personal de Amaggi. Las entradas con "#" son títulos de grupo.
const STAFF_NAV = [
  ["tablero", "Tablero"],
  ["#", "Cupos"],
  ["grilla", "Grilla"], ["asignar", "Asignar por contrato"], ["cupos", "Listado Códigos"],
  ["solicitudes", "Solicitudes de clientes"], ["trazabilidad", "Trazabilidad"],
  ["contratos", "Contratos"],
  ["#", "Clientes"],
  ["envios", "Envíos a clientes"], ["contactos", "Contactos"], ["modelos", "Modelos de CPE"],
  ["#", "Configuración"],
  ["importar", "Importaciones"], ["puertos", "Puertos"], ["usuarios", "Usuarios", "ADMIN"], ["auditoria", "Auditoría"],
];
// Qué opciones quedan dentro de un grupo (van con sangría). "Contratos" corta el grupo Cupos.
const GRUPO_DE = (() => {
  const out = {};
  let grupo = null;
  for (const [r, l] of STAFF_NAV) {
    if (r === "#") grupo = l;
    else if (r === "tablero" || r === "contratos") grupo = null;
    else if (grupo) out[r] = grupo;
  }
  return out;
})();
const CLIENT_NAV = [["mis-contratos", "Mis contratos"], ["mis-solicitudes", "Mis solicitudes"], ["mis-cupos", "Mis cupos"]];

function parseHash() {
  const [route, query] = location.hash.slice(1).split("?");
  return { route, params: Object.fromEntries(new URLSearchParams(query || "")) };
}
function go(route, params) { location.hash = route + (params ? "?" + qs(params) : ""); }

async function renderNav() {
  const items = ME.rol === "CLIENTE" ? CLIENT_NAV : STAFF_NAV.filter((n) => !n[2] || n[2] === ME.rol);
  const cuentas = {};
  if (ME.rol !== "CLIENTE") {
    const [sol, env] = await Promise.all([
      api("GET", "/api/solicitudes?estado=ABIERTAS").catch(() => []),
      api("GET", "/api/envios?estado=PENDIENTE").catch(() => []),
    ]);
    cuentas.solicitudes = sol.length;
    cuentas.envios = env.length;
  }
  const { route } = parseHash();
  // Grupos desplegables: se recuerda cuáles cerró el usuario; el grupo de la pantalla actual queda abierto
  let cerrados = [];
  try { cerrados = JSON.parse(localStorage.getItem("navCerrados") || "[]"); } catch { /* sin almacenamiento */ }
  const abierto = (g) => !cerrados.includes(g) || GRUPO_DE[route] === g;
  const pendientesDe = (g) => Object.entries(GRUPO_DE).filter(([r, x]) => x === g).reduce((a, [r]) => a + (cuentas[r] || 0), 0);
  $("#nav").innerHTML = items.map(([r, l]) => r === "#"
    ? `<button type="button" class="nav-grupo ${abierto(l) ? "" : "cerrado"}" data-grupo="${l}" aria-expanded="${abierto(l)}">
         <span class="chev">▾</span>${l}${!abierto(l) && pendientesDe(l) ? `<span class="count">${pendientesDe(l)}</span>` : ""}</button>`
    : `<a href="#${r}" class="${r === route ? "active" : ""}${GRUPO_DE[r] ? " en-grupo" : ""}" ${GRUPO_DE[r] && !abierto(GRUPO_DE[r]) ? "hidden" : ""}>${l}${cuentas[r] ? `<span class="count">${cuentas[r]}</span>` : ""}</a>`).join("");
  $$("#nav [data-grupo]").forEach((b) => (b.onclick = () => {
    const g = b.dataset.grupo;
    const plegar = !b.classList.contains("cerrado");
    cerrados = cerrados.filter((x) => x !== g).concat(plegar ? [g] : []);
    try { localStorage.setItem("navCerrados", JSON.stringify(cerrados)); } catch { /* sin almacenamiento */ }
    b.classList.toggle("cerrado", plegar);
    b.setAttribute("aria-expanded", String(!plegar));
    $$("#nav a").filter((a) => GRUPO_DE[a.getAttribute("href").slice(1)] === g).forEach((a) => (a.hidden = plegar));
  }));
}

async function router() {
  if (!ME) return;
  let { route, params } = parseHash();
  const views = ME.rol === "CLIENTE" ? CLIENT_VIEWS : STAFF_VIEWS;
  if (route === "planilla") route = "grilla"; // nombre anterior
  if (!views[route]) { route = ME.rol === "CLIENTE" ? Object.keys(views)[0] : "grilla"; history.replaceState(null, "", "#" + route); }
  renderNav();
  $("#actions").innerHTML = "";
  $("#view").innerHTML = `<div class="empty">Cargando…</div>`;
  await run(() => views[route](params));
}

/* =====================================================================
   VISTAS STAFF (ADMIN / OPERADOR)
   ===================================================================== */
const STAFF_VIEWS = {
  async tablero(p) {
    $("#title").textContent = "Tablero";
    const prod = p.producto || "";
    // Período: todas las fechas, un día o una semana (lunes a domingo)
    const per = ["dia", "sem"].includes(p.per) ? p.per : "";
    const ref = p.f || today();
    const lunes = weekToDate(isoWeek(ref));
    const [desde, hasta] = per === "dia" ? [ref, ref] : per === "sem" ? [lunes, addDays(lunes, 6)] : ["", ""];
    const t = await api("GET", "/api/tablero?" + qs({ producto: prod, desde, hasta }));
    const ir = (cambios) => go("tablero", { producto: prod, per, f: per ? ref : "", ...cambios });
    // Cantidad de cupos de un destino (o de todos) por origen y estado visible; term = una terminal ("" = sin terminal)
    const n = (destino, origen, estado, term) => t.por_destino
      .filter((r) => (!destino || r.destino === destino) && (!origen || r.origen === origen) && r.estado === estado
        && (term === undefined || r.terminal === term))
      .reduce((a, r) => a + r.n, 0);
    const link = (filtros) => `#cupos?${qs({ ...filtros, producto: prod, ...(per ? { desde, hasta } : {}) })}`;
    const sinActivar = (d, term) => t.no_activados.filter((r) => (!d || r.destino === d) && (term === undefined || (r.puerto || "") === term)).length;
    const metricas = (d, term) => {
      const pt = term === undefined ? {} : { puerto: term || "-" };
      return [
        ["Disponibles · Stock propio", n(d, "STOP", "DISPONIBLE", term), link({ origen: "STOP", estado: "DISPONIBLE", destino: d, ...pt }), "ok"],
        ["Disponibles · Contratos de venta", n(d, "VENTA", "DISPONIBLE", term), link({ origen: "VENTA", estado: "DISPONIBLE", destino: d, ...pt }), "ok"],
        ["Asignados", n(d, null, "ASIGNADO", term), link({ estado: "ASIGNADO", desde: "-", destino: d, ...pt }), "brand"],
        ["Asignados sin activar", sinActivar(d, term), `#`, "bad", d],
      ];
    };
    const mets = (d, term) => metricas(d, term).map(([l, v, href, c, na]) =>
      `<a href="${href}" ${na ? `data-na="${esc(na)}" ${term !== undefined ? `data-term="${esc(term)}"` : ""}` : ""} class="met met-${c}${v ? "" : " cero"}"><span class="v">${fnum(v)}</span><span class="l">${l}</span></a>`).join("");
    // Terminales de la zona: todas las del catálogo (aunque no tengan cupos) más las que aparecen en los cupos;
    // las de más movimiento primero y "Sin terminal" al final (solo si tiene cupos)
    const terminalesDe = (d) => {
      const tot = Object.fromEntries(((t.terminales_zona || {})[d] || []).map((x) => [x, 0]));
      t.por_destino.filter((r) => r.destino === d && r.estado !== "ANULADO").forEach((r) => (tot[r.terminal] = (tot[r.terminal] || 0) + r.n));
      if (!tot[""]) delete tot[""];
      return Object.keys(tot).sort((a, b) => (a === "") - (b === "") || tot[b] - tot[a] || a.localeCompare(b));
    };
    const nContr = (d) => { const k = (t.contratos_destino || {})[d]; return k ? `${fnum(k)} contrato${k === 1 ? "" : "s"} de compra` : "sin contratos de compra"; };
    const abiertos = new Set((() => { try { return JSON.parse(localStorage.getItem("tableroAbiertos") || "[]"); } catch { return []; } })());
    const tarjeta = (d) => {
      const terms = terminalesDe(d);
      const abierto = abiertos.has(d) && terms.length;
      return `<div class="zona">
        <div class="card puerto">
          <div class="puerto-tit">${terms.length ? `<a href="#" class="zona-tog" data-zona="${esc(d)}" title="Ver por terminal">
              <span class="chev">${abierto ? "▾" : "▸"}</span>${esc(d)}</a>` : esc(d)}
            <small class="muted zona-sub">${[nContr(d), terms.length && `${terms.length} terminal${terms.length === 1 ? "" : "es"}`].filter(Boolean).join(" · ")}</small></div>
          <div class="puerto-met">${mets(d)}</div>
          ${solic(d)}
        </div>
        <div class="terminales" data-terms="${esc(d)}" ${abierto ? "" : "hidden"}>${terms.map((term) => `
          <div class="card puerto terminal">
            <div class="puerto-tit">${term ? esc(term) : `<span class="muted">Sin terminal</span>`}</div>
            <div class="puerto-met">${mets(d, term)}</div>
            <div></div>
          </div>`).join("")}</div>
      </div>`;
    };
    // Solicitudes abiertas de clientes para ese puerto (a la derecha de cada fila)
    const solic = (d) => {
      const s = (t.solicitudes_por_destino || {})[d] || { n: 0, cupos: 0 };
      return `<a href="#solicitudes" class="met met-sol${s.n ? "" : " cero"}"><span class="v">${fnum(s.n)}<small> · ${fnum(s.cupos)} cupos</small></span><span class="l">Solicitudes abiertas</span></a>`;
    };
    const solSinDestino = (t.solicitudes_por_destino || {})["SIN DESTINO"];
    // Detalle de cupos asignados sin activar (sin CTG), de ayer en adelante: se abre al tocar el indicador
    const hoy = today(), manana = addDays(hoy, 1);
    const cuando = (f) => (f < hoy ? `<strong style="color:var(--bad)">${fdate(f)} · ayer</strong>`
      : f === hoy ? `<strong style="color:var(--bad)">Hoy</strong>` : f === manana ? `<strong style="color:var(--warn)">Mañana</strong>` : fdate(f));
    const AVISO = { ENVIADO: badge("APROBADA", "Avisado"), PENDIENTE: badge("PENDIENTE", "Aviso sin enviar") };
    // Detalle de los códigos de un vendedor (se despliega debajo de su fila en el resumen)
    const codigosNA = (filas) => `<table class="sub-tabla">${filas.map((r) => `<tr>
        <td>${cuando(r.fecha)}</td>
        <td><a href="#" data-hist="${r.id}"><strong>${esc(r.codigo)}</strong></a></td>
        <td>${esc(r.puerto || r.destino)}</td><td>${esc(r.producto)}</td>
        <td>${esc(r.contrato)}${r.contrato_venta ? `<span class="sub">CV ${esc(r.contrato_venta)}</span>` : ""}</td>
        <td><small>Corredor: ${fcorr(r.corredor)}</small></td>
        <td>${origenBadge(r.origen)}</td>
        <td>${AVISO[r.aviso] || badge("ANULADO", "Sin aviso")}</td>
        <td><small class="muted">STOP: ${esc(r.stop_estado || "—")}</small></td>
        <td><button class="btn sm" data-ctg="${r.id}">Cargar CTG</button></td></tr>`).join("")}</table>`;
    // Resumen por vendedor: total sin activar, cuántos son de hoy/ayer y mañana, y si ya se le avisó
    const detalleNA = (destino, term) => {
      const na = t.no_activados.filter((r) => r.destino === destino && (term === undefined || (r.puerto || "") === term));
      if (term !== undefined) destino = `${destino} · ${term || "sin terminal"}`;
      const vendedores = [...na.reduce((m, r) => m.set(r.vendedor, [...(m.get(r.vendedor) || []), r]), new Map())]
        .map(([vendedor, filas]) => ({ vendedor, filas, urgentes: filas.filter((r) => r.fecha <= hoy).length,
          manana: filas.filter((r) => r.fecha === manana).length, sinAviso: filas.filter((r) => r.aviso !== "ENVIADO").length,
          contratos: [...new Set(filas.map((r) => r.contrato))],
          corredores: [...new Set(filas.map((r) => (r.corredor || "").trim() || "Directo"))] }))
        .sort((a, b) => b.urgentes - a.urgentes || b.filas.length - a.filas.length || a.vendedor.localeCompare(b.vendedor));
      const body = !vendedores.length ? `<div class="empty">No hay cupos asignados sin activar en ${esc(destino)}</div>` : `
        <p class="muted" style="margin:0">Sin CTG, de ayer en adelante${prod ? ` · ${esc(prod)}` : ""} · ${na.length} cupo${na.length === 1 ? "" : "s"}
          de ${vendedores.length} vendedor${vendedores.length === 1 ? "" : "es"} · tocá un vendedor para ver sus códigos</p>
        <div class="table-wrap"><table>
          <thead><tr><th>Vendedor</th><th>Corredor</th><th>Contratos</th><th class="num">Sin activar</th><th class="num">Hoy / ayer</th>
            <th class="num">Mañana</th><th>Aviso al cliente</th></tr></thead>
          <tbody>${vendedores.map((v, i) => `
            <tr class="fila-vend" data-v="${i}" style="cursor:pointer">
              <td><span class="chev" style="display:inline-block;width:14px;color:var(--muted)">▸</span><strong style="white-space:normal">${esc(v.vendedor)}</strong></td>
              <td><span style="white-space:normal">${v.corredores.map(esc).join(", ")}</span></td>
              <td><small style="white-space:normal">${v.contratos.map(esc).join(", ")}</small></td>
              <td class="num"><strong style="font-size:15px">${v.filas.length}</strong></td>
              <td class="num">${v.urgentes ? `<strong style="color:var(--bad)">${v.urgentes}</strong>` : "·"}</td>
              <td class="num">${v.manana ? `<strong style="color:var(--warn)">${v.manana}</strong>` : "·"}</td>
              <td>${v.sinAviso ? badge("PENDIENTE", `${v.sinAviso} sin avisar`) : badge("APROBADA", "Avisado")}</td>
            </tr>
            <tr class="det-vend" data-d="${i}" hidden><td colspan="7" style="background:var(--gray-soft);padding:6px 10px 10px 28px">${codigosNA(v.filas)}</td></tr>`).join("")}
          </tbody></table></div>`;
      const form = modal({ title: `${destino} · cupos asignados sin activar`, wide: true, body });
      $$(".fila-vend", form).forEach((tr) => (tr.onclick = () => {
        const det = $(`.det-vend[data-d="${tr.dataset.v}"]`, form);
        det.hidden = !det.hidden;
        $(".chev", tr).textContent = det.hidden ? "▸" : "▾";
      }));
      $$("[data-hist]", form).forEach((a) => (a.onclick = (e) => { e.preventDefault(); historialModal(+a.dataset.hist); }));
      $$("[data-ctg]", form).forEach((b) => (b.onclick = () => ctgModal(na.find((r) => r.id === +b.dataset.ctg))));
    };
    const DIAS = ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"];
    const rotulo = per === "dia" ? `${DIAS[new Date(ref + "T00:00:00").getDay()]} ${fdate(ref)}${ref === hoy ? " · hoy" : ref === manana ? " · mañana" : ""}`
      : per === "sem" ? `${fdate(desde)} al ${fdate(hasta)}${desde === weekToDate(isoWeek(hoy)) ? " · semana actual" : ""}` : "";
    $("#view").innerHTML = `
      <div class="filters" id="per-flt" style="margin-bottom:10px;align-items:center">
        <label style="min-width:0">Fecha de los cupos<select id="per">${opts([["", "Todas las fechas"], ["dia", "Un día"], ["sem", "Una semana"]], per, null)}</select></label>
        ${per ? `<div class="row" style="flex-wrap:nowrap;align-self:end;gap:6px">
          <button class="btn sm" id="per-prev" title="${per === "dia" ? "Día" : "Semana"} anterior">◀</button>
          ${per === "dia" ? `<input type="date" id="per-pick" value="${esc(ref)}" style="padding:4px 8px">`
                          : `<input type="week" id="per-pick" value="${isoWeek(ref)}" style="padding:4px 8px">`}
          <button class="btn sm" id="per-next" title="${per === "dia" ? "Día" : "Semana"} siguiente">▶</button>
          <button class="btn sm" id="per-hoy">${per === "dia" ? "Hoy" : "Semana actual"}</button>
          ${per === "dia" ? `<button class="btn sm" id="per-man">Mañana</button>` : ""}
          <strong style="margin-left:6px;white-space:nowrap">${rotulo}</strong></div>` : ""}
      </div>
      <div class="row" style="margin-bottom:14px;gap:6px">
        <div class="row leyenda" id="prod-flt" style="gap:6px">
          ${["", ...t.productos].map((x) => `<a href="#" class="chip ${x === prod ? "on" : ""}" data-prod="${esc(x)}">${esc(x || "Todos los productos")}</a>`).join("")}
        </div>
        ${solSinDestino ? `<a href="#solicitudes" style="margin-left:auto;font-size:13px">${solSinDestino.n} solicitud${solSinDestino.n === 1 ? "" : "es"} abierta${solSinDestino.n === 1 ? "" : "s"} sin destino · ${solSinDestino.cupos} cupos</a>` : ""}
      </div>
      <div class="puertos">${t.destinos.map(tarjeta).join("")}</div>`;
    $$("#prod-flt [data-prod]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); ir({ producto: a.dataset.prod }); }));
    $("#per").onchange = (e) => ir({ per: e.target.value, f: e.target.value ? hoy : "" });
    if (per) {
      const paso = per === "dia" ? 1 : 7;
      $("#per-prev").onclick = () => ir({ f: addDays(ref, -paso) });
      $("#per-next").onclick = () => ir({ f: addDays(ref, paso) });
      $("#per-hoy").onclick = () => ir({ f: hoy });
      if ($("#per-man")) $("#per-man").onclick = () => ir({ f: manana });
      $("#per-pick").onchange = (e) => e.target.value && ir({ f: per === "dia" ? e.target.value : weekToDate(e.target.value) });
    }
    $$("#view [data-na]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); detalleNA(a.dataset.na, a.dataset.term); }));
    // Desplegable por terminal (se recuerda qué zonas quedaron abiertas)
    $$("#view .zona-tog").forEach((a) => (a.onclick = (e) => {
      e.preventDefault();
      const z = a.dataset.zona, box = $(`[data-terms="${CSS.escape(z)}"]`);
      box.hidden = !box.hidden;
      $(".chev", a).textContent = box.hidden ? "▸" : "▾";
      box.hidden ? abiertos.delete(z) : abiertos.add(z);
      try { localStorage.setItem("tableroAbiertos", JSON.stringify([...abiertos])); } catch {}
    }));
  },

  async cupos(p) {
    $("#title").textContent = "Listado Códigos";
    const f = { origen: p.origen ?? "", estado: pv(p.estado, "DISPONIBLE"), desde: pv(p.desde, today()), hasta: p.hasta ?? "", destino: p.destino ?? "", puerto: p.puerto ?? "", producto: p.producto ?? "", q: p.q ?? "" };
    const preContrato = p.contrato;
    $("#actions").innerHTML = `<button class="btn" id="exp">Exportar CSV</button><button class="btn primary" id="asig" disabled>Asignar a contrato</button>`;
    $("#view").innerHTML = `
      <div class="filters" id="flt">
        <label>Origen<select name="origen">${opts(ORIGEN_OPTS, f.origen)}</select></label>
        <label>Estado<select name="estado">${opts(["DISPONIBLE", "ASIGNADO", "UTILIZADO", "VENCIDO", "ANULADO"], f.estado)}</select></label>
        <label>Desde<input type="date" name="desde" value="${esc(f.desde)}"></label>
        <label>Hasta<input type="date" name="hasta" value="${esc(f.hasta)}"></label>
        <label>Destino<select name="destino">${opts(FILTROS.destinos, f.destino)}</select></label>
        <label>Terminal<select name="puerto" id="f-term">${opts(f.puerto ? [[f.puerto, f.puerto === "-" ? "Sin terminal" : f.puerto]] : [], f.puerto, "Todas")}</select></label>
        <label>Producto<select name="producto">${opts(FILTROS.productos, f.producto)}</select></label>
        <label>Buscar<input name="q" value="${esc(f.q)}" placeholder="Código, contrato, CTG…"></label>
        <span class="sel-info" id="selinfo"></span>
      </div>
      <div id="tbl"></div>`;
    const flt = $("#flt");
    const params = () => {
      const v = fields(flt);
      return { ...v, estado: v.estado || "-", desde: v.desde || "-", ...(preContrato ? { contrato: preContrato } : {}) };
    };
    flt.onchange = (e) => go("cupos", { ...params(), ...(e.target.name === "destino" ? { puerto: "" } : {}) });
    $("[name=q]", flt).onkeydown = (e) => { if (e.key === "Enter") go("cupos", params()); };
    $("#exp").onclick = () => (location.href = "/api/cupos/export.csv?" + qs(fields(flt)));
    // Terminales del catálogo para el destino elegido (o todas), más "Sin terminal"
    api("GET", "/api/puertos?" + qs({ zona: f.destino })).then((ps) => {
      const nombres = [...new Set(ps.filter((x) => x.activo).map((x) => x.nombre))].sort();
      if (f.puerto && f.puerto !== "-" && !nombres.includes(f.puerto)) nombres.unshift(f.puerto);
      $("#f-term").innerHTML = opts([...nombres.map((x) => [x, x]), ["-", "Sin terminal"]], f.puerto, "Todas");
    }).catch(() => {});

    const data = await api("GET", "/api/cupos?" + qs(f));
    const sel = new Set();
    $("#tbl").innerHTML = table([
      { h: `<input type="checkbox" id="all">`, f: (r) => (r.estado_visible === "DISPONIBLE" ? `<input type="checkbox" class="ck" value="${r.id}">` : "") },
      { h: "Código", f: (r) => `<a href="#" data-hist="${r.id}" title="Ver historial"><strong>${esc(r.codigo)}</strong></a>` }, { h: "Fecha", f: (r) => fdate(r.fecha) },
      { h: "Destino", f: (r) => esc(r.destino) + (r.puerto_efectivo ? `<span class="sub">${esc(r.puerto_efectivo)}</span>` : "") }, { h: "Producto", k: "producto" }, { h: "Tn", f: (r) => fnum(r.toneladas), num: 1 },
      { h: "Origen", f: (r) => origenBadge(r.origen) + (r.contrato_venta_numero ? `<span class="sub">CV ${esc(r.contrato_venta_numero)}</span>` : "") },
      { h: "Estado", f: (r) => badge(r.estado_visible) },
      { h: "Contrato compra · vendedor", f: (r) => (r.contrato_compra_numero ? `${esc(r.contrato_compra_numero)}<span class="sub">${esc(r.contrato_compra_contraparte)}</span>` : "") },
      { h: "Corredor", f: (r) => (r.contrato_compra_numero ? fcorr(r.contrato_compra_corredor) : "") },
      { h: "CTG", f: ctgCelda },
      { h: "", f: (r) => rowActions(r) },
    ], data, { empty: "No hay cupos con estos filtros" });
    const upd = () => {
      $("#asig").disabled = !sel.size;
      $("#selinfo").textContent = sel.size ? `${sel.size} seleccionados · ${fnum(sel.size * TN_CUPO)} tn aprox.` : `${data.length} cupos`;
    };
    $$(".ck").forEach((c) => (c.onchange = () => { c.checked ? sel.add(+c.value) : sel.delete(+c.value); upd(); }));
    const all = $("#all"); if (all) all.onchange = () => $$(".ck").forEach((c) => { c.checked = all.checked; c.onchange(); });
    upd();
    $("#asig").onclick = () => asignarModal(data.filter((r) => sel.has(r.id)), preContrato);
    $$("#tbl [data-hist]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); historialModal(+a.dataset.hist); }));
    bindRowActions(data);
  },

  async contratos(p) {
    $("#title").textContent = "Contratos (SIGAM)";
    const tipo = p.tipo || "COMPRA";
    $("#view").innerHTML = `
      <div class="tabs"><button data-t="COMPRA" class="${tipo === "COMPRA" ? "active" : ""}">Compra</button><button data-t="VENTA" class="${tipo === "VENTA" ? "active" : ""}">Venta</button></div>
      <div class="filters" id="flt"><label>Buscar<input name="q" value="${esc(p.q || "")}" placeholder="Número, contraparte, CUIT"></label>
      <label>Producto<select name="producto">${opts(FILTROS.productos, p.producto)}</select></label>
      <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0"><input type="checkbox" name="con_saldo" ${p.con_saldo === "true" ? "checked" : ""}> Solo vigentes con saldo</label></div>
      <div id="tbl"></div>`;
    $$(".tabs button").forEach((b) => (b.onclick = () => go("contratos", { tipo: b.dataset.t })));
    const flt = $("#flt");
    const nav = () => go("contratos", { tipo, ...fields(flt), con_saldo: $("[name=con_saldo]", flt).checked || "" });
    flt.onchange = nav; $("[name=q]", flt).onkeydown = (e) => { if (e.key === "Enter") nav(); };
    const data = await api("GET", "/api/contratos?" + qs({ tipo, q: p.q, producto: p.producto, con_saldo: p.con_saldo }));
    const periodo = (r) => `${fdate(r.fecha_desde)} – ${fdate(r.fecha_hasta)}`;
    const nro = (r) => `<strong>${esc(r.numero)}</strong>${r.operacion ? `<span class="sub">Op. ${esc(r.operacion)}</span>` : ""}`;
    const corredor = { h: "Corredor", f: (r) => fcorr(r.corredor) };
    const cols = tipo === "COMPRA" ? [
      { h: "Contrato", f: nro },
      { h: "Vendedor", f: (r) => `${esc(r.contraparte_nombre)}<span class="sub">${fcuit(r.contraparte_cuit)}</span>` }, corredor,
      { h: "Producto", f: (r) => `${esc(r.producto)}<span class="sub">${esc(r.cosecha)}</span>` },
      { h: "Tn contrato", f: (r) => fnum(r.toneladas), num: 1 }, { h: "Entregadas", f: (r) => fnum(r.toneladas_entregadas), num: 1 },
      { h: "Con cupo", f: (r) => `${fnum(r.tn_asignadas)}<span class="sub">${r.cupos_asignados} cupos</span>`, num: 1 },
      { h: "Saldo tn", f: (r) => `<strong>${fnum(r.saldo)}</strong>`, num: 1 },
      { h: "Avance", f: (r) => `<div class="bar"><i style="width:${Math.min(100, (100 * (r.toneladas_entregadas + r.tn_asignadas)) / Math.max(1, r.toneladas))}%"></i></div>` },
      { h: "Período", f: periodo }, { h: "Estado", f: (r) => badge(r.estado) },
    ] : [
      { h: "Contrato", f: nro },
      { h: "Comprador", f: (r) => `${esc(r.contraparte_nombre)}<span class="sub">${fcuit(r.contraparte_cuit)}</span>` }, corredor,
      { h: "Producto", f: (r) => `${esc(r.producto)}<span class="sub">${esc(r.cosecha)}</span>` },
      { h: "Tn pactadas", f: (r) => fnum(r.toneladas), num: 1 }, { h: "Aplicadas", f: (r) => fnum(r.toneladas_entregadas), num: 1 },
      { h: "Pendiente tn", f: (r) => `<strong>${fnum(r.saldo)}</strong>`, num: 1 },
      { h: "Cupos", k: "cupos_total", num: 1 }, { h: "Disp.", k: "cupos_disponibles", num: 1 },
      { h: "Asig.", k: "cupos_asignados", num: 1 }, { h: "Usados", k: "cupos_utilizados", num: 1 },
      { h: "Período", f: periodo }, { h: "Estado", f: (r) => badge(r.estado) },
    ];
    // Hasta 500 filas en pantalla (con miles de contratos la vista se vuelve lenta): el resto, con los filtros
    const MAX = 500;
    $("#tbl").innerHTML = (data.length > MAX ? `<p class="muted" style="margin:0 0 6px">Mostrando ${MAX} de ${fnum(data.length)} contratos · acotá con el buscador, el producto o "Solo vigentes con saldo"</p>`
        : `<p class="muted" style="margin:0 0 6px">${fnum(data.length)} contratos</p>`)
      + table(cols, data.slice(0, MAX), { empty: "No hay contratos. Importalos desde SIGAM.", rowAttr: (r) => `data-id="${r.id}" style="cursor:pointer"` });
    $$("#tbl tr[data-id]").forEach((tr) => (tr.onclick = () => contratoModal(+tr.dataset.id)));
  },

  async solicitudes(p) {
    $("#title").textContent = "Solicitudes de clientes";
    const estado = p.estado ?? "ABIERTAS";
    $("#view").innerHTML = `<div class="tabs">${[["ABIERTAS", "Abiertas"], ["TODAS", "Todas"]].map(([v, l]) => `<button data-e="${v}" class="${estado === v ? "active" : ""}">${l}</button>`).join("")}</div><div id="tbl"></div>`;
    $$(".tabs button").forEach((b) => (b.onclick = () => go("solicitudes", { estado: b.dataset.e })));
    const data = await api("GET", "/api/solicitudes?" + qs({ estado: estado === "TODAS" ? "" : estado }));
    $("#tbl").innerHTML = table([
      { h: "#", k: "id" }, { h: "Fecha pedida", f: (r) => fdate(r.fecha) },
      { h: "Cliente", f: (r) => `${esc(r.contraparte_nombre)}<span class="sub">${esc(r.usuario_nombre)}</span>` },
      { h: "Contrato", f: (r) => `${esc(r.contrato_numero)}<span class="sub">${esc(r.producto)}</span>` },
      { h: "Cupos", f: (r) => `${r.cantidad_aprobada} / ${r.cantidad}`, num: 1 },
      { h: "Destino pref.", f: (r) => esc(r.destino_preferido || "—") },
      { h: "Estado", f: (r) => badge(r.estado) }, { h: "Creada", f: (r) => fdt(r.creado) },
      { h: "", f: (r) => (["PENDIENTE", "PARCIAL"].includes(r.estado) ? `<button class="btn sm primary" data-res="${r.id}">Resolver</button>` : `<button class="btn sm" data-ver="${r.id}">Ver</button>`) },
    ], data, { empty: "No hay solicitudes" });
    $$("[data-res]").forEach((b) => (b.onclick = () => resolverModal(data.find((s) => s.id === +b.dataset.res))));
    $$("[data-ver]").forEach((b) => (b.onclick = () => solicitudDetalle(data.find((s) => s.id === +b.dataset.ver))));
  },

  async importar() {
    $("#title").textContent = "Importaciones";
    const con = await api("GET", "/api/conectores");
    const card = (tipo, titulo, desc, sync) => `
      <div class="card"><h2>${titulo}</h2><p class="muted" style="margin:0">${desc}</p>
        <div class="drop"><input type="file" accept=".csv,.xlsx,.txt" data-file="${tipo}">
        <div class="row"><button class="btn primary" data-up="${tipo}">Importar archivo</button>
        ${sync === "STOP" ? `<button class="btn" data-sync="STOP">Sincronizar con STOP</button>`
          : sync ? `<button class="btn" data-sync="${sync}" title="${con[sync] ? "Modo: " + con[sync] : "No configurado"}">Sincronizar${con[sync] ? "" : " (sin configurar)"}</button>` : ""}
        ${tipo === "VENTA" ? `<button class="btn" id="alta-venta">Alta manual</button>` : ""}</div></div>
        ${sync === "STOP" ? `<div id="stop-estado" class="muted" style="font-size:12px"></div>` : ""}
        <div data-res="${tipo}"></div></div>`;
    $("#view").innerHTML = `
      <h2>1 · Contratos (SIGAM)</h2>
      <div class="import-grid">
        ${card("SIGAM_COMPRA", "Contratos de compra", "Archivo de contratos de compra de SIGAM. Si el número ya existe se actualizan toneladas, entregas, fechas y estado.", "SIGAM_COMPRA")}
        ${card("SIGAM_VENTA", "Contratos de venta", "Archivo de contratos de venta de SIGAM. Importalo antes que los cupos de venta, que se vinculan por número de contrato.", "SIGAM_VENTA")}
      </div>
      <h2>2 · Cupos</h2>
      <div class="import-grid">
        ${card("STOP", "Cupos STOP · stock propio", "Cupos con destinatario Amaggi bajados del sistema STOP. Cada fila es un cupo, con su código.", "STOP")}
        ${card("VENTA", "Cupos de contratos de venta", "Cupos (con código) que aporta el comprador. Cada fila indica a qué contrato de venta pertenece, el destino y la terminal (obligatoria). No es el archivo de contratos.")}
      </div>
      <p class="muted">Archivos de ejemplo en la carpeta <code>ejemplos/</code>. Columnas aceptadas: ver README.</p>
      <h2>Historial</h2><div id="hist"></div>`;
    const show = (tipo, r) => {
      $(`[data-res="${tipo}"]`).innerHTML = `<div class="note ${r.omitidos ? "warn" : "ok"}">${r.insertados} nuevos${r.actualizados ? `, ${r.actualizados} actualizados` : ""}, ${r.omitidos} omitidos de ${r.total} filas.
        ${r.detalle.length ? `<ul style="margin:6px 0 0;padding-left:18px">${r.detalle.slice(0, 8).map((d) => `<li>Fila ${d.fila}: ${esc(d.motivo)}</li>`).join("")}${r.detalle.length > 8 ? `<li>… y ${r.detalle.length - 8} más (ver historial)</li>` : ""}</ul>` : ""}</div>`;
      loadFiltros(); hist();
    };
    const fail = (tipo, e) => ($(`[data-res="${tipo}"]`).innerHTML = `<div class="note bad">${esc(e.message)}</div>`);
    $$("[data-up]").forEach((b) => (b.onclick = async () => {
      const tipo = b.dataset.up, file = $(`[data-file="${tipo}"]`).files[0];
      if (!file) return fail(tipo, new Error("Elegí un archivo"));
      const fd = new FormData(); fd.append("archivo", file);
      b.disabled = true;
      $(`[data-res="${tipo}"]`).innerHTML = `<div class="note">Importando ${esc(file.name)}…</div>`;
      try { show(tipo, await api("POST", `/api/importar/${tipo.toLowerCase()}`, fd)); }
      catch (e) { fail(tipo, e); } finally { b.disabled = false; }
    }));
    // Estado de la conexión con STOP (modo, última sincronización, consultas del día)
    const MODOS = { desactivado: "desactivada", simulado: "SIMULADA (datos de prueba)", pruebas: "entorno de pruebas", produccion: "producción" };
    const stopEstado = async () => {
      const s = await api("GET", "/api/stop/estado").catch(() => null);
      if (!s || !$("#stop-estado")) return;
      $("#stop-estado").innerHTML = `Conexión STOP: <strong>${MODOS[s.modo] || s.modo}</strong>`
        + (s.faltan.length ? ` · <span style="color:var(--bad)">falta configurar ${s.faltan.join(", ")} en config.env</span>` : "")
        + (s.ultima_ok ? ` · última sincronización ${fdt(s.ultima_ok)}` : "")
        + (s.ultima && !s.ultima.ok ? ` · <span style="color:var(--bad)">último intento con error: ${esc(s.ultima.detalle || "")}</span>` : "")
        + ` · consultas hoy ${s.consultas_hoy}/${s.limite}` + (s.lista && s.minutos ? ` · automática cada ${Math.max(30, s.minutos)} min` : "");
    };
    stopEstado();
    $$("[data-sync]").forEach((b) => (b.onclick = async () => {
      b.disabled = true;
      try {
        const r = await api("POST", `/api/sync/${b.dataset.sync.toLowerCase()}`);
        if (b.dataset.sync === "STOP" && "recibidos" in r) {
          $(`[data-res="STOP"]`).innerHTML = `<div class="note ${r.avisos.length ? "warn" : "ok"}">STOP (${fdate(r.desde)} a ${fdate(r.hasta)}):
            ${r.recibidos} turnos recibidos · <strong>${r.nuevos} cupos nuevos</strong> de stock propio · ${r.actualizados} actualizados (CTG/estado)
            · ${r.utilizados} pasaron a utilizado · ${r.anulados} anulados · ${r.de_terceros} de terceros sin cupo en el sistema
            ${r.avisos.length ? `<ul style="margin:6px 0 0;padding-left:18px">${r.avisos.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>` : ""}</div>`;
          loadFiltros(); hist(); stopEstado();
        } else show(b.dataset.sync, r);
      }
      catch (e) { fail(b.dataset.sync, e); stopEstado(); } finally { b.disabled = false; }
    }));
    $("#alta-venta").onclick = altaVentaModal;
    const hist = async () => {
      const h = await api("GET", "/api/importaciones");
      $("#hist").innerHTML = table([
        { h: "Fecha", f: (r) => fdt(r.creado) }, { h: "Tipo", f: (r) => badge(r.tipo.startsWith("SIGAM") ? "UTILIZADO" : r.tipo, IMPORT_LABEL[r.tipo] || r.tipo) },
        { h: "Archivo", k: "archivo" }, { h: "Filas", k: "total", num: 1 }, { h: "Nuevos", k: "insertados", num: 1 },
        { h: "Actualiz.", k: "actualizados", num: 1 }, { h: "Omitidos", k: "omitidos", num: 1 }, { h: "Usuario", k: "usuario_nombre" },
        { h: "", f: (r) => (r.detalle.length ? `<button class="btn sm" data-det="${r.id}">Ver omitidos</button>` : "") },
      ], h, { empty: "Todavía no hubo importaciones" });
      $$("[data-det]").forEach((b) => (b.onclick = () => {
        const r = h.find((x) => x.id === +b.dataset.det);
        modal({ title: `Filas omitidas · ${r.archivo}`, body: table([{ h: "Fila", k: "fila", num: 1 }, { h: "Motivo", k: "motivo" }], r.detalle) });
      }));
    };
    hist();
  },

  async usuarios() {
    $("#title").textContent = "Usuarios";
    $("#actions").innerHTML = `<button class="btn primary" id="nuevo">Nuevo usuario</button>`;
    const data = await api("GET", "/api/usuarios");
    $("#view").innerHTML = table([
      { h: "Nombre", f: (r) => `<strong>${esc(r.nombre)}</strong><span class="sub">${esc(r.email)}</span>` },
      { h: "Rol", f: (r) => badge(r.rol === "CLIENTE" ? "VENTA" : r.rol === "ADMIN" ? "UTILIZADO" : "STOP", r.rol) },
      { h: "CUIT / razón social", f: (r) => (r.cuit ? `${fcuit(r.cuit)}<span class="sub">${esc(r.razon_social || "Sin contratos con este CUIT")}</span>` : "") },
      { h: "Estado", f: (r) => (r.activo ? badge("VIGENTE", "ACTIVO") : badge("ANULADO", "INACTIVO")) },
      { h: "Alta", f: (r) => fdate(r.creado) }, { h: "", f: (r) => `<button class="btn sm" data-ed="${r.id}">Editar</button>` },
    ], data);
    $("#nuevo").onclick = () => usuarioModal();
    $$("[data-ed]").forEach((b) => (b.onclick = () => usuarioModal(data.find((u) => u.id === +b.dataset.ed))));
  },

  async auditoria() {
    $("#title").textContent = "Auditoría";
    const data = await api("GET", "/api/auditoria");
    $("#view").innerHTML = table([
      { h: "Fecha", f: (r) => fdt(r.creado) }, { h: "Usuario", k: "usuario_nombre" }, { h: "Acción", f: (r) => `<strong>${esc(r.accion)}</strong>` },
      { h: "Detalle", f: (r) => `<span style="white-space:normal">${esc(r.detalle)}</span>` },
    ], data, { empty: "Sin actividad" });
  },
};

/* ---------- Envíos a clientes: bandeja de salida de los avisos de cupos asignados ---------- */
STAFF_VIEWS.envios = async function (p) {
  $("#title").textContent = "Envíos a clientes";
  const estado = p.estado || "PENDIENTE";
  const data = await api("GET", "/api/envios?" + qs({ estado }));
  $("#view").innerHTML = `
    <div class="tabs">${[["PENDIENTE", "Pendientes"], ["ENVIADO", "Enviados"], ["DESCARTADO", "Descartados"]]
      .map(([v, l]) => `<button data-e="${v}" class="${estado === v ? "active" : ""}">${l}</button>`).join("")}</div>
    <div id="tbl"></div>`;
  $$(".tabs button").forEach((b) => (b.onclick = () => go("envios", { estado: b.dataset.e })));
  const dest = (e) => estado === "PENDIENTE"
    ? (e.destinatarios_lista.length ? `<span style="white-space:normal">${e.destinatarios_lista.map(esc).join(", ")}</span>`
       : `<span style="color:var(--bad)">Sin contactos</span> <a href="#contactos?q=${encodeURIComponent(e.contraparte_nombre || "")}">cargar</a>`)
    : `<span style="white-space:normal">${esc(e.destinatarios || "")}</span>`;
  $("#tbl").innerHTML = table([
    { h: "Cliente · contrato", f: (e) => `<strong>${esc(e.contraparte_nombre)}</strong><span class="sub">${esc(e.numero)} · ${esc(e.producto)} · Corredor: ${fcorr(e.corredor)}</span>` },
    { h: "Cupos", k: "cantidad", num: 1 },
    { h: "Destinatarios", f: dest },
    { h: estado === "ENVIADO" ? "Enviado" : "Actualizado", f: (e) => fdt(estado === "ENVIADO" ? e.enviado_en : e.actualizado) + (e.enviado_por_nombre ? `<span class="sub">${esc(e.enviado_por_nombre)}</span>` : "") },
    { h: "", f: (e) => `<div class="row" style="flex-wrap:nowrap"><button class="btn sm" data-ver="${e.id}">Ver</button>`
      + (estado === "PENDIENTE" ? `<a class="btn sm primary" href="/api/envios/${e.id}/eml" data-outlook="${e.id}">Abrir en Outlook</a>
         <button class="btn sm" data-ok="${e.id}">Marcar enviado</button><button class="btn sm ghost" data-desc="${e.id}">Descartar</button>` : "") + "</div>" },
  ], data, { empty: estado === "PENDIENTE" ? "No hay avisos pendientes. Se arman solos cuando asignás cupos." : "Sin envíos" });
  const enviado = (id) => run(async () => { await api("POST", `/api/envios/${id}/enviado`); toast("✓ Marcado como enviado"); router(); });
  $$("[data-ver]").forEach((b) => (b.onclick = () => envioModal(+b.dataset.ver, estado === "PENDIENTE", enviado)));
  $$("[data-ok]").forEach((b) => (b.onclick = () => enviado(b.dataset.ok)));
  $$("[data-desc]").forEach((b) => (b.onclick = () => confirmar("Descartar aviso", "El aviso no se va a enviar. Los cupos siguen asignados.", "Descartar",
    async () => { await api("POST", `/api/envios/${b.dataset.desc}/descartar`); toast("Aviso descartado"); router(); }, "danger")));
  $$("[data-outlook]").forEach((a) => (a.onclick = () => setTimeout(() => toast("Se descargó el mail: abrilo, revisalo y envialo desde Outlook. Después tocá «Marcar enviado»."), 300)));
};

async function envioModal(id, pendiente, enviado) {
  const a = await api("GET", `/api/envios/${id}`);
  const form = modal({
    title: a.asunto || "Aviso de cupos", wide: true,
    body: `<div class="note">Para: <strong>${a.destinatarios.length ? a.destinatarios.map((d) => esc(d.email)).join(", ") : '<span style="color:var(--bad)">sin contactos cargados</span>'}</strong>
        ${a.quitados ? `<br><span style="color:var(--warn)">${a.quitados} cupo(s) se liberaron después de asignarse y no se incluyen.</span>` : ""}</div>
      <iframe id="prev-mail" style="width:100%;height:60vh;border:1px solid var(--line);border-radius:6px;background:#fff"></iframe>`,
    buttons: pendiente ? [
      { label: "Abrir en Outlook", cls: "", onClick: () => { location.href = `/api/envios/${id}/eml`; return false; } },
      { label: "Marcar enviado", cls: "primary", onClick: () => enviado(id) },
    ] : [],
  });
  $("#prev-mail", form).srcdoc = a.html || "<p>Sin contenido</p>";
}

/* ---------- Contactos: mails de clientes, corredores y otros para los avisos de cupos ---------- */
STAFF_VIEWS.contactos = async function (p) {
  $("#title").textContent = "Contactos";
  const data = await api("GET", "/api/contactos?" + qs({ tipo: p.tipo, q: p.q }));
  $("#actions").innerHTML = `<button class="btn primary" id="nuevo">Nuevo contacto</button>`;
  $("#view").innerHTML = `
    <div class="filters" id="flt">
      <label>Tipo<select name="tipo">${opts([["CLIENTE", "Clientes"], ["CORREDOR", "Corredores"], ["OTRO", "Otros"]], p.tipo)}</select></label>
      <label style="flex:1;max-width:380px">Buscar<input name="q" value="${esc(p.q || "")}" placeholder="Empresa, mail, nombre o CUIT"></label>
      <span class="sel-info">${data.length} contactos</span>
    </div>
    <p class="muted" style="margin:0 0 8px">Los clientes con usuario registrado aparecen solos. Los avisos de cupos van a los contactos del cliente (por CUIT) y del corredor del contrato.</p>
    <div id="tbl"></div>`;
  const flt = $("#flt");
  flt.onchange = () => go("contactos", fields(flt));
  $("[name=q]", flt).onkeydown = (e) => { if (e.key === "Enter") go("contactos", fields(flt)); };
  $("#tbl").innerHTML = table([
    { h: "Tipo", f: (c) => badge({ CLIENTE: "VENTA", CORREDOR: "STOP", OTRO: "UTILIZADO" }[c.tipo], c.tipo) },
    { h: "Empresa", f: (c) => `<strong style="white-space:normal">${esc(c.empresa)}</strong>${c.cuit ? `<span class="sub">${fcuit(c.cuit)}</span>` : ""}` },
    { h: "Contacto", f: (c) => `${esc(c.nombre || "—")}<span class="sub">${esc(c.email)}</span>` },
    { h: "Recibe cupos", f: (c) => (c.recibe_cupos ? "Sí" : "No") },
    { h: "Origen", f: (c) => (c.usuario_id ? "Usuario registrado" : "Cargado a mano") },
    { h: "Estado", f: (c) => (c.activo ? badge("VIGENTE", "ACTIVO") : badge("ANULADO", "INACTIVO")) },
    { h: "", f: (c) => `<button class="btn sm" data-ed="${c.id}">Editar</button>` },
  ], data, { empty: "Sin contactos" });
  $("#nuevo").onclick = () => contactoModal();
  $$("[data-ed]").forEach((b) => (b.onclick = () => contactoModal(data.find((c) => c.id === +b.dataset.ed))));
};

function contactoModal(c) {
  const nuevo = !c, deUsuario = c && c.usuario_id;
  modal({
    title: nuevo ? "Nuevo contacto" : `Contacto · ${c.empresa}`,
    body: `${deUsuario ? `<div class="note">Viene de un usuario registrado: el mail y la empresa se cambian desde Usuarios. Acá podés indicar si recibe los avisos.</div>` : ""}
      <div class="form-grid">
        <label>Tipo<select name="tipo" ${deUsuario ? "disabled" : ""}>${opts([["CLIENTE", "Cliente (vendedor)"], ["CORREDOR", "Corredor"], ["OTRO", "Otro"]], c?.tipo || "CLIENTE", null)}</select></label>
        <label>Empresa<input name="empresa" list="dl-emp" value="${esc(c?.empresa || "")}" ${deUsuario ? "disabled" : ""} placeholder="Buscá por nombre o CUIT" autocomplete="off"></label>
        <label>CUIT (clientes)<input name="cuit" value="${esc(fcuit(c?.cuit || ""))}" ${deUsuario ? "disabled" : ""} placeholder="30-12345678-9"></label>
        <label>Nombre de contacto<input name="nombre" value="${esc(c?.nombre || "")}" ${deUsuario ? "disabled" : ""}></label>
        <label class="full">Mail<input name="email" type="email" value="${esc(c?.email || "")}" ${deUsuario ? "disabled" : ""}></label>
        <label style="flex-direction:row;display:flex;align-items:center;gap:6px"><input type="checkbox" name="recibe_cupos" ${c?.recibe_cupos === 0 ? "" : "checked"}> Recibe los avisos de cupos</label>
        <label style="flex-direction:row;display:flex;align-items:center;gap:6px"><input type="checkbox" name="activo" ${c?.activo === 0 ? "" : "checked"}> Activo</label>
      </div><datalist id="dl-emp"></datalist>`,
    buttons: [{ label: "Guardar", cls: "primary", onClick: async (f) => {
      const d = fields(f);
      const datos = deUsuario ? { tipo: c.tipo, empresa: c.empresa, cuit: c.cuit, nombre: c.nombre, email: c.email, recibe_cupos: d.recibe_cupos, activo: d.activo } : d;
      if (nuevo) await api("POST", "/api/contactos", datos); else await api("PUT", `/api/contactos/${c.id}`, datos);
      toast("✓ Contacto guardado"); router();
    } }],
    onOpen: (f) => {
      if (deUsuario) return;
      let sug = [], t;
      const emp = $("[name=empresa]", f);
      emp.oninput = () => { clearTimeout(t); t = setTimeout(() => run(async () => {
        sug = await api("GET", "/api/contactos/empresas?" + qs({ tipo: $("[name=tipo]", f).value, q: emp.value }));
        $("#dl-emp", f).innerHTML = sug.map((s) => `<option value="${esc(s.empresa)}">${s.cuit ? fcuit(s.cuit) : ""}</option>`).join("");
      }), 250); };
      emp.onchange = () => { const s = sug.find((x) => x.empresa === emp.value); if (s?.cuit) $("[name=cuit]", f).value = fcuit(s.cuit); };
    },
  });
}

/* ---------- Modelos de Carta de Porte ---------- */
STAFF_VIEWS.modelos = async function () {
  $("#title").textContent = "Modelos de Carta de Porte";
  const { modelos, variables } = await api("GET", "/api/cpe-modelos");
  $("#actions").innerHTML = `<button class="btn primary" id="nuevo">Nuevo modelo</button>`;
  const aplica = (m) => [m.origen ? ORIGEN_LABEL[m.origen] || m.origen : "Cualquier origen", m.zona || "cualquier destino", m.puerto].filter(Boolean).join(" · ");
  $("#view").innerHTML = `
    <p class="muted" style="margin-top:0">Cada aviso de cupos lleva los datos para emitir la Carta de Porte. Se usa el modelo más específico
      para el cupo (origen + puerto, después origen + destino, después solo origen). Los textos entre {{…}} se completan solos.</p>
    <div class="import-grid">${modelos.map((m) => `<div class="card" style="${m.activo ? "" : "opacity:.55"}">
      <h2 style="margin-bottom:2px">${esc(m.nombre)}</h2><small class="muted">${esc(aplica(m))}${m.activo ? "" : " · inactivo"}</small>
      <table style="margin-top:8px">${m.campos.map((c) => `<tr><td style="padding:3px 8px 3px 0;color:var(--muted);font-size:12px;white-space:normal">${esc(c.campo)}</td>
        <td style="padding:3px 0;font-size:12px;white-space:normal">${esc(c.valor)}</td></tr>`).join("")}</table>
      <div class="row" style="margin-top:8px"><button class="btn sm" data-ed="${m.id}">Editar</button><button class="btn sm ghost" data-dup="${m.id}">Duplicar</button></div>
    </div>`).join("")}</div>`;
  $("#nuevo").onclick = () => modeloModal(null, variables);
  $$("[data-ed]").forEach((b) => (b.onclick = () => modeloModal(modelos.find((m) => m.id === +b.dataset.ed), variables)));
  $$("[data-dup]").forEach((b) => (b.onclick = () => { const m = modelos.find((x) => x.id === +b.dataset.dup); modeloModal({ ...m, id: null, nombre: m.nombre + " (copia)" }, variables); }));
};

function modeloModal(m, variables) {
  const fila = (c = {}) => `<tr><td><input data-k="seccion" value="${esc(c.seccion || "Intervinientes")}" style="width:130px"></td>
    <td><input data-k="campo" value="${esc(c.campo || "")}" style="width:220px"></td>
    <td style="width:100%"><input data-k="valor" value="${esc(c.valor || "")}" style="width:100%"></td>
    <td><button type="button" class="btn sm ghost" data-quitar>✕</button></td></tr>`;
  const form = modal({
    title: m?.id ? `Modelo · ${m.nombre}` : "Nuevo modelo de Carta de Porte", wide: true,
    body: `<div class="form-grid">
        <label class="full">Nombre<input name="nombre" value="${esc(m?.nombre || "")}"></label>
        <label>Origen del cupo<select name="origen">${opts(ORIGEN_OPTS, m?.origen || "", "Cualquiera")}</select></label>
        <label>Destino (opcional)<input name="zona" list="dl-zon" value="${esc(m?.zona || "")}" placeholder="UPRIVER, NECOCHEA…"></label>
        <label>Puerto (opcional)<input name="puerto" value="${esc(m?.puerto || "")}"></label>
        <label style="flex-direction:row;display:flex;align-items:center;gap:6px;align-self:end"><input type="checkbox" name="activo" ${m?.activo === 0 ? "" : "checked"}> Activo</label>
      </div>
      <datalist id="dl-zon">${["UPRIVER", "TLP", "NECOCHEA", "BAHIA BLANCA", ...FILTROS.destinos].map((z) => `<option value="${esc(z)}">`).join("")}</datalist>
      <div class="table-wrap"><table><thead><tr><th>Sección</th><th>Campo</th><th>Valor (texto fijo y/o variables)</th><th></th></tr></thead>
        <tbody id="campos">${(m?.campos || [{}]).map(fila).join("")}</tbody></table></div>
      <button type="button" class="btn sm" id="add-campo">+ Agregar campo</button>
      <div class="note"><strong>Variables</strong> (tocá una para insertarla en el valor donde está el cursor):<br>
        ${Object.entries(variables).map(([k, d]) => `<a href="#" data-var="${k}" title="${esc(d)}" style="margin-right:10px;white-space:nowrap">{{${k}}}</a>`).join(" ")}</div>`,
    buttons: [{ label: "Guardar modelo", cls: "primary", onClick: async (f) => {
      const campos = $$("#campos tr", f).map((tr) => Object.fromEntries($$("input", tr).map((i) => [i.dataset.k, i.value])));
      const d = { ...fields(f), campos };
      delete d.seccion; delete d.campo; delete d.valor;
      if (m?.id) await api("PUT", `/api/cpe-modelos/${m.id}`, d); else await api("POST", "/api/cpe-modelos", d);
      toast("✓ Modelo guardado"); router();
    } }],
    onOpen: (f) => {
      let ultimo = null;
      const enlazar = () => {
        $$("[data-k=valor]", f).forEach((i) => (i.onfocus = () => (ultimo = i)));
        $$("[data-quitar]", f).forEach((b) => (b.onclick = () => b.closest("tr").remove()));
      };
      enlazar();
      $("#add-campo", f).onclick = () => { $("#campos", f).insertAdjacentHTML("beforeend", fila()); enlazar(); };
      $$("[data-var]", f).forEach((a) => (a.onclick = (e) => {
        e.preventDefault();
        const i = ultimo || $$("[data-k=valor]", f).at(-1);
        if (!i) return;
        const pos = i.selectionStart ?? i.value.length, txt = `{{${a.dataset.var}}}`;
        i.value = i.value.slice(0, pos) + txt + i.value.slice(i.selectionEnd ?? pos);
        i.focus(); i.setSelectionRange(pos + txt.length, pos + txt.length);
      }));
    },
  });
}

/* ---------- Catálogo de puertos específicos por zona de destino ---------- */
STAFF_VIEWS.puertos = async function () {
  $("#title").textContent = "Puertos por destino";
  const esAdmin = ME.rol === "ADMIN";
  const data = await api("GET", "/api/puertos");
  const zonas = [...new Set([...FILTROS.destinos, ...data.map((p) => p.zona)])].sort();
  $("#view").innerHTML = `
    <p class="muted" style="margin-top:0">Puertos o terminales específicos dentro de cada destino (por ejemplo UPRIVER → TIMBUES).
      En la Grilla, al elegir un destino, cada contrato puede indicar a qué puerto van sus cupos. Los puertos que vienen en los archivos de cupos se agregan solos.</p>
    ${esAdmin ? `<div class="card filters" style="align-items:end">
      <label>Destino / zona<input name="zona" list="dl-zonas" placeholder="UPRIVER"></label>
      <datalist id="dl-zonas">${zonas.map((z) => `<option value="${esc(z)}">`).join("")}</datalist>
      <label>Puerto / terminal<input name="nombre" placeholder="TIMBUES"></label>
      <button class="btn primary" id="add">Agregar puerto</button></div>` : ""}
    <div id="tbl" style="margin-top:14px"></div>
    <h2 style="margin-top:22px">Terminales de STOP</h2>
    <p class="muted" style="margin-top:0">Cómo se traduce cada terminal que informa STOP a nuestro destino y puerto (para los cupos que entran por la sincronización).
      Se completa sola al sincronizar; si una quedó mal, corregila acá y ya no se pisa.</p>
    <div id="tbl-term"></div>`;
  run(async () => {
    const ts = await api("GET", "/api/stop/terminales");
    const zonasConocidas = [...new Set(["UPRIVER", "TLP", "NECOCHEA", "BAHIA BLANCA", ...zonas, ...ts.map((t) => t.zona).filter(Boolean)])].sort();
    $("#tbl-term").innerHTML = table([
      { h: "Id STOP", k: "id_terminal", num: 1 },
      { h: "Terminal (STOP)", f: (t) => `<span style="white-space:normal">${esc(t.descripcion)}</span><span class="sub">${esc(t.localidad)} · ${esc(t.provincia)}</span>` },
      { h: "Destino", f: (t) => esAdmin ? `<input data-tz="${t.id_terminal}" list="dl-zonas2" value="${esc(t.zona || "")}" style="width:140px">` : esc(t.zona) },
      { h: "Puerto", f: (t) => esAdmin ? `<input data-tp="${t.id_terminal}" value="${esc(t.puerto || "")}" style="width:240px">` : esc(t.puerto) },
      { h: "Turnos", k: "turnos", num: 1 },
      { h: "", f: (t) => (esAdmin ? `<button class="btn sm" data-tg2="${t.id_terminal}">Guardar</button>` : "") + (t.editado ? ` <small class="muted">fijado a mano</small>` : "") },
    ], ts, { empty: "Todavía no se sincronizó con STOP" }) + `<datalist id="dl-zonas2">${zonasConocidas.map((z) => `<option value="${esc(z)}">`).join("")}</datalist>`;
    $$("[data-tg2]").forEach((b) => (b.onclick = () => run(async () => {
      const id = b.dataset.tg2;
      await api("PATCH", `/api/stop/terminales/${id}`, { zona: $(`[data-tz="${id}"]`).value, puerto: $(`[data-tp="${id}"]`).value });
      toast("✓ Terminal actualizada"); router();
    })));
  });
  $("#tbl").innerHTML = table([
    { h: "Destino / zona", f: (r) => `<strong>${esc(r.zona)}</strong>` }, { h: "Puerto / terminal", k: "nombre" },
    { h: "Cupos con este puerto", k: "cupos", num: 1 },
    { h: "Estado", f: (r) => (r.activo ? badge("VIGENTE", "ACTIVO") : badge("ANULADO", "INACTIVO")) },
    { h: "", f: (r) => (esAdmin ? `<button class="btn sm" data-tg="${r.id}" data-a="${r.activo ? 0 : 1}">${r.activo ? "Desactivar" : "Activar"}</button>` : "") },
  ], data, { empty: "Todavía no hay puertos cargados" });
  if (esAdmin) {
    $("#add").onclick = () => run(async () => {
      const v = fields($("#view .card"));
      await api("POST", "/api/puertos", v); toast(`Puerto ${v.nombre.toUpperCase()} agregado a ${v.zona.toUpperCase()}`); router();
    });
    $$("[data-tg]").forEach((b) => (b.onclick = () => run(async () => {
      await api("PATCH", `/api/puertos/${b.dataset.tg}`, { activo: b.dataset.a === "1" }); router();
    })));
  }
};

/* ---------- Trazabilidad: historial de cada cupo con sus contratos de compra y venta ---------- */
const EVENTO_LABEL = { ALTA: "Alta", ASIGNADO: "Asignado", LIBERADO: "Liberado", UTILIZADO: "Utilizado", ANULADO: "Anulado", CTG: "CTG", TRANSPORTE: "Transporte" };
// Contrato: número, contraparte (vendedor/comprador) y corredor (vacío = Directo)
const contr = (num, nom, corr) => (num ? `<strong>${esc(num)}</strong><span class="sub" style="white-space:normal">${esc(nom || "")}</span>`
  + (corr !== undefined ? `<span class="sub" style="white-space:normal">Corredor: ${fcorr(corr)}</span>` : "") : `<span class="muted">—</span>`);

STAFF_VIEWS.trazabilidad = async function (p) {
  $("#title").textContent = "Trazabilidad de cupos";
  const modo = p.modo || "cupos";
  const f = { q: p.q || "", producto: p.producto || "", origen: p.origen || "", evento: p.evento || "", desde: p.desde || "", hasta: p.hasta || "" };
  $("#actions").innerHTML = `<button class="btn" id="exp">Exportar historial CSV</button>`;
  $("#view").innerHTML = `
    <div class="tabs">${[["cupos", "Por cupo"], ["eventos", "Todos los eventos"]].map(([v, l]) => `<button data-m="${v}" class="${modo === v ? "active" : ""}">${l}</button>`).join("")}</div>
    <div class="filters" id="flt">
      <label style="flex:1;max-width:380px">Buscar<input name="q" value="${esc(f.q)}" placeholder="Código de cupo, CTG, contrato de compra o venta, vendedor, comprador"></label>
      <label>Producto<select name="producto">${opts(FILTROS.productos, f.producto)}</select></label>
      <label>Origen<select name="origen">${opts(ORIGEN_OPTS, f.origen)}</select></label>
      ${modo === "eventos" ? `<label>Evento<select name="evento">${opts(Object.entries(EVENTO_LABEL), f.evento)}</select></label>` : ""}
      <label>Fecha cupo desde<input type="date" name="desde" value="${esc(f.desde)}"></label>
      <label>Hasta<input type="date" name="hasta" value="${esc(f.hasta)}"></label>
      <span class="sel-info" id="cnt"></span>
    </div><div id="tbl"></div>`;
  $$(".tabs button").forEach((b) => (b.onclick = () => go("trazabilidad", { ...f, modo: b.dataset.m, evento: "" })));
  const flt = $("#flt");
  flt.onchange = () => go("trazabilidad", { ...fields(flt), modo });
  $("[name=q]", flt).onkeydown = (e) => { if (e.key === "Enter") flt.onchange(); };
  $("#exp").onclick = () => (location.href = "/api/trazabilidad/export.csv?" + qs(fields(flt)));

  const data = await api("GET", "/api/trazabilidad?" + qs({ ...f, modo }));
  $("#cnt").textContent = `${fnum(data.length)} ${modo === "cupos" ? "cupos" : "eventos"}${data.length >= 2000 ? " (máx. 2000, acotá la búsqueda)" : ""}`;
  if (modo === "cupos") {
    $("#tbl").innerHTML = table([
      { h: "Cupo", f: (r) => `<strong>${esc(r.codigo)}</strong>` }, { h: "Fecha", f: (r) => fdate(r.fecha) },
      { h: "Destino", f: (r) => esc(r.destino) + (r.puerto ? `<span class="sub">${esc(r.puerto)}</span>` : "") },
      { h: "Producto", k: "producto" }, { h: "Origen", f: (r) => origenBadge(r.origen) },
      { h: "Contrato de venta", f: (r) => contr(r.contrato_venta_numero, r.contrato_venta_contraparte, r.contrato_venta_corredor) },
      { h: "Contrato de compra", f: (r) => contr(r.contrato_compra_numero, r.contrato_compra_contraparte, r.contrato_compra_corredor)
          + (!r.contrato_compra_numero && r.ultimo_compra ? `<span class="sub">antes: ${esc(r.ultimo_compra)}</span>` : "")
          + (r.veces_asignado > 1 ? `<span class="sub" style="color:var(--warn)">asignado ${r.veces_asignado} veces</span>` : "") },
      { h: "CTG", f: ctgCelda },
      { h: "Estado", f: (r) => badge(r.estado) },
      { h: "", f: (r) => `<button class="btn sm" data-hist="${r.id}">Historial (${r.eventos})</button>` },
    ], data, { empty: "Sin cupos que coincidan", rowAttr: (r) => `data-hist="${r.id}" style="cursor:pointer"` });
  } else {
    $("#tbl").innerHTML = table([
      { h: "Fecha evento", f: (r) => fdt(r.creado) }, { h: "Evento", f: (r) => badge(r.evento, EVENTO_LABEL[r.evento]) },
      { h: "Cupo", f: (r) => `<strong>${esc(r.codigo)}</strong><span class="sub">${fdate(r.fecha_cupo)} · ${esc(r.destino)}${r.puerto ? " · " + esc(r.puerto) : ""}</span>` },
      { h: "Producto", k: "producto" }, { h: "Origen", f: (r) => origenBadge(r.origen) },
      { h: "Contrato de compra", f: (r) => contr(r.contrato_compra_numero, r.contrato_compra_contraparte) },
      { h: "Contrato de venta", f: (r) => contr(r.contrato_venta_numero, r.contrato_venta_contraparte) },
      { h: "Usuario", k: "usuario_nombre" }, { h: "Detalle", f: (r) => `<span style="white-space:normal">${esc(r.detalle || "")}</span>` },
    ], data, { empty: "Sin eventos que coincidan", rowAttr: (r) => `data-hist="${r.cupo_id}" style="cursor:pointer"` });
  }
  $$("#tbl [data-hist]").forEach((el) => (el.onclick = (e) => { e.stopPropagation(); historialModal(+el.dataset.hist); }));
};

async function historialModal(cupoId) {
  const { cupo: c, eventos } = await api("GET", `/api/cupos/${cupoId}/historial`);
  modal({
    title: `Historial del cupo ${c.codigo}`, wide: true,
    body: `<div class="kpis" style="margin:0">
        <div class="card kpi"><div class="l">Cupo</div><div style="font-weight:650">${esc(c.codigo)}</div><small>${fdate(c.fecha)} · ${esc(c.destino)}${c.puerto_efectivo ? " · " + esc(c.puerto_efectivo) : ""} · ${esc(c.producto)} · ${fnum(c.toneladas)} tn</small></div>
        <div class="card kpi"><div class="l">Origen</div>${origenBadge(c.origen)} ${badge(c.estado_visible)}</div>
        <div class="card kpi"><div class="l">Contrato de venta</div>${contr(c.contrato_venta_numero, c.contrato_venta_contraparte, c.contrato_venta_corredor)}</div>
        <div class="card kpi"><div class="l">Contrato de compra actual</div>${contr(c.contrato_compra_numero, c.contrato_compra_contraparte, c.contrato_compra_corredor)}</div>
      </div>
      ${table([
        { h: "Fecha", f: (r) => fdt(r.creado) }, { h: "Evento", f: (r) => badge(r.evento, EVENTO_LABEL[r.evento]) },
        { h: "Contrato de compra", f: (r) => contr(r.contrato_compra_numero, r.contrato_compra_contraparte) },
        { h: "Contrato de venta", f: (r) => contr(r.contrato_venta_numero, r.contrato_venta_contraparte) },
        { h: "Puerto", f: (r) => esc(r.puerto || "—") },
        { h: "CTG", f: (r) => fctg(r.ctg) || (r.evento === "TRANSPORTE" ? esc([r.patente, r.transportista].filter(Boolean).join(" · ")) : "") },
        { h: "Usuario", k: "usuario_nombre" }, { h: "Detalle", f: (r) => `<span style="white-space:normal">${esc(r.detalle || "")}</span>` },
      ], eventos, { empty: "Sin eventos registrados" })}`,
  });
}

/* ---------- Grilla: semana de contratos × días para asignar cantidades de cupos ---------- */
STAFF_VIEWS.grilla = async function (p) {
  $("#title").textContent = "Grilla de asignación";
  const filtros = { producto: p.producto, destino: p.destino, puerto: p.puerto, origen: p.origen, contrato_venta_id: p.cv, semana: p.semana, q: p.q, todos: p.todos, estado: p.est, con_asignados: p.asig };
  const d = await api("GET", "/api/planilla?" + qs(filtros));
  const TN = d.toneladas_por_cupo || TN_CUPO;
  const nav = (cambios) => go("grilla", { producto: d.producto, destino: p.destino, puerto: p.puerto, origen: p.origen, cv: p.cv, semana: p.semana, q: p.q, todos: p.todos, est: p.est, asig: p.asig, ...cambios });
  const estSel = new Set((p.est || "").split(",").filter(Boolean));
  const conPuerto = true; // la terminal se elige por contrato siempre (las de la zona del contrato)
  const LETRAS = ["L", "M", "M", "J", "V", "S", "D"];
  const hoy = today();
  // Disponibilidad por terminal y día ("" = cupos sin terminal informada: sirven para cualquiera)
  // Terminales por zona: cada contrato elige entre las de su zona (lugar de entrega); si su zona no tiene, todas.
  const TERMS = d.terminales || [];
  const sinTermDe = (z) => TERMS.find((t) => t.destino === z && !t.terminal) || { disponibles: 0, dias: {} };
  const totalSemana = TERMS.reduce((a, t) => a + t.disponibles, 0);
  const termOpts = (sel, vacio, zona) => {
    const conNombre = TERMS.filter((t) => t.terminal);
    const lista = zona && conNombre.some((t) => t.destino === zona) ? conNombre.filter((t) => t.destino === zona) : conNombre;
    const zonas = [...new Set(lista.map((t) => t.destino))];
    const opt = (t) => `<option value="${esc(t.terminal)}" ${t.terminal === sel ? "selected" : ""}>${esc(t.terminal)} · ${t.disponibles} disp.</option>`;
    const sinT = zonas.reduce((a, z) => a + sinTermDe(z).disponibles, 0);
    return `<option value="">${vacio} · ${totalSemana} disp.</option>`
      + (zonas.length > 1 ? zonas.map((z) => `<optgroup label="${esc(z)}">${lista.filter((t) => t.destino === z).map(opt).join("")}</optgroup>`).join("") : lista.map(opt).join(""))
      + (sinT ? `<option disabled>+ ${sinT} sin terminal (sirven para cualquier terminal de su zona)</option>` : "");
  };

  $("#view").innerHTML = `
    <div class="filters" id="flt">
      <label>Producto<select name="producto">${opts(d.productos.map((x) => [x.producto, `${x.producto} (${x.disponibles} disp.)`]), d.producto, d.productos.length ? null : "Sin cupos")}</select></label>
      <label>Destino<select name="destino">${opts(d.destinos.map((x) => [x.destino, `${x.destino} (${x.disponibles} disp.)`]), p.destino)}</select></label>
      <label>Terminal<select name="puerto">${termOpts(p.puerto, "Todas", p.destino)}</select></label>
      <label>Origen del cupo<select name="origen">${opts(ORIGEN_OPTS, p.origen, "Todos los orígenes")}</select></label>
      ${p.origen === "VENTA" ? `<label>Contrato de venta<select name="cv">${opts(d.ventas.map((x) => [x.id, `${x.numero} · ${x.contraparte_nombre || ""} (${x.disponibles} disp.)`]), p.cv)}</select></label>` : ""}
      <label>Buscar contrato de compra<input name="q" value="${esc(p.q || "")}" placeholder="Número, vendedor o CUIT"></label>
      <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0;align-self:end;padding-bottom:8px">
        <input type="checkbox" name="todos" ${p.todos === "true" ? "checked" : ""}> Todos con saldo</label>
      <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0;align-self:end;padding-bottom:8px"
        title="Muestra solo los contratos que ya tienen cupos asignados en la semana elegida">
        <input type="checkbox" name="asig" ${p.asig === "true" ? "checked" : ""}> Solo con cupos asignados</label>
      <div class="row" style="margin-left:auto;flex-wrap:nowrap;align-self:end">
        <button class="btn sm" id="sem-prev" title="Semana anterior">◀</button>
        <input type="week" id="sem-pick" value="${isoWeek(d.desde)}" style="padding:4px 8px">
        <button class="btn sm" id="sem-next" title="Semana siguiente">▶</button>
        <button class="btn sm" id="sem-hoy">Semana actual</button>
      </div>
    </div>
    <div id="grid"></div>
    <div class="card row" style="position:sticky;bottom:12px;margin-top:12px;justify-content:space-between;z-index:2">
      <div id="resumen"></div>
      <div class="row"><button class="btn" id="limpiar">Limpiar</button><button class="btn primary" id="go" disabled>Asignar</button></div>
    </div>`;

  const flt = $("#flt");
  flt.onchange = (e) => {
    if (e.target.closest(".row")) return; // semana: tiene sus propios controles
    const v = fields(flt);
    if (e.target.classList?.contains("pp")) return; // puerto de una fila: no recarga
    const cambios = { producto: v.producto, destino: v.destino, puerto: v.puerto || "", origen: v.origen, cv: v.origen === "VENTA" ? v.cv : "", q: v.q, todos: v.todos || "", asig: v.asig || "" };
    if (e.target.name === "producto") Object.assign(cambios, { destino: "", puerto: "", cv: "" });
    if (e.target.name === "destino") Object.assign(cambios, { puerto: "" });
    nav(cambios);
  };
  $("[name=q]", flt).onkeydown = (e) => { if (e.key === "Enter") flt.onchange(e); };
  // Buscar mientras se escribe (con una pequeña pausa), sin tener que apretar Enter
  let tq;
  const inputQ = $("[name=q]", flt);
  inputQ.oninput = (e) => { clearTimeout(tq); tq = setTimeout(() => { window._focoBuscador = true; flt.onchange(e); }, 500); };
  if (window._focoBuscador) { // al recargar la grilla, el cursor sigue en el buscador
    window._focoBuscador = false;
    inputQ.focus();
    inputQ.setSelectionRange(inputQ.value.length, inputQ.value.length);
  }
  $("#sem-prev").onclick = () => nav({ semana: addDays(d.desde, -7) });
  $("#sem-next").onclick = () => nav({ semana: addDays(d.desde, 7) });
  $("#sem-hoy").onclick = () => nav({ semana: "" });
  $("#sem-pick").onchange = (e) => e.target.value && nav({ semana: weekToDate(e.target.value) });

  if (!d.producto) { $("#grid").innerHTML = `<div class="table-wrap"><div class="empty">No hay cupos cargados para esta semana</div></div>`; return; }

  const bg = (f) => (f === hoy ? "background:var(--brand-soft);" : "");
  const enPeriodo = (c, f) => (!c.fecha_desde || f >= c.fecha_desde) && (!c.fecha_hasta || f <= c.fecha_hasta);
  const thDias = d.dias.map((x, i) => `<th class="num" style="${bg(x.fecha)}"><span style="font-size:13px;color:var(--ink)">${LETRAS[i]}</span><span style="display:block;font-weight:400">${x.fecha.slice(8, 10)}/${x.fecha.slice(5, 7)}</span></th>`).join("");
  const filaResumen = (label, celda, extra = "") => `<tr style="background:var(--gray-soft)"><td><strong>${label}</strong></td><td></td><td></td>${conPuerto ? "<td></td>" : ""}<td></td>${d.dias.map((x) => `<td class="num" style="${bg(x.fecha)}">${celda(x)}</td>`).join("")}${extra}</tr>`;

  // Celda de contrato compacta: cliente en grande, número chico a la derecha, debajo lugar y vencimiento
  const celdaContrato = (nombre, numero, sub) => `<td class="g-c"><div class="row" style="flex-wrap:nowrap;justify-content:space-between;gap:10px">
      <span class="g-cli">${esc(nombre || "(sin nombre)")}</span><small class="muted" style="white-space:nowrap">${esc(numero)}</small></div>
      ${sub ? `<small class="muted">${sub}</small>` : ""}</td>`;
  const vence = (c) => [c.lugar_entrega && esc(c.lugar_entrega + (c.lugar_detalle ? ` (${c.lugar_detalle})` : "")),
                        (c.fecha_desde || c.fecha_hasta) && `entrega ${c.fecha_desde ? fdate(c.fecha_desde) : "?"} – ${c.fecha_hasta ? fdate(c.fecha_hasta) : "?"}`].filter(Boolean).join(" · ");
  // Colores por estado de entrega del contrato HOY (toda la fila del mismo color), con
  // Fec. Entrega (inicio) y Fec. Vto. Entrega (fin) de SIGAM:
  //   verde    = vigente: hoy está dentro del período de entrega
  //   amarillo = vencido: hoy es posterior a Fec. Vto. Entrega
  //   rojo     = fuera de entrega: hoy es anterior a Fec. Entrega (todavía no empieza)
  const ESTADO = {
    vigente: { cls: "e-vig", txt: "Vigente: hoy está dentro del período de entrega" },
    vencido: { cls: "e-ven", txt: "Vencido: ya pasó la fecha de vencimiento de entrega" },
    fuera: { cls: "e-fue", txt: "Fuera de entrega: el período de entrega todavía no empieza" },
  };
  const estadoHoy = (c) => (c.fecha_hasta && hoy > c.fecha_hasta ? "vencido" : c.fecha_desde && hoy < c.fecha_desde ? "fuera" : "vigente");
  const periodo = (c) => `Entrega ${c.fecha_desde ? fdate(c.fecha_desde) : "?"} – ${c.fecha_hasta ? fdate(c.fecha_hasta) : "?"}`;

  const filas = d.contratos.map((c) => `
    <tr data-row="${c.id}" class="${ESTADO[estadoHoy(c)].cls}-row">
      <td class="g-c g-corr"><span style="white-space:normal">${fcorr(c.corredor)}</span></td>
      <td class="g-vend"><span class="g-cli">${esc(c.contraparte_nombre || "(sin nombre)")}</span></td>
      <td style="white-space:nowrap"><strong>${esc(c.numero)}</strong>${vence(c) ? `<span class="sub">${vence(c)}</span>` : ""}</td>
      ${conPuerto ? `<td><select class="pp" data-pp="${c.id}" style="padding:3px 6px;max-width:190px" title="Terminal a la que van los cupos que asignes a este contrato (con su disponibilidad en la semana)">
          ${termOpts(c.puerto_sugerido, "Cualquiera", c.lugar_entrega)}</select></td>` : ""}
      <td class="num"><strong>${fnum(Math.floor(c.saldo / TN))}</strong> <small class="muted">${fnum(c.saldo)} tn</small></td>
      ${d.dias.map((x) => {
        const ya = c.ya[x.fecha];
        const off = x.pasado || (!x.disponibles);
        const e = ESTADO[estadoHoy(c)];
        return `<td class="num ${e.cls}${x.fecha === hoy ? " hoy" : ""}" title="${e.txt} · ${periodo(c)}">
          <span class="row" style="flex-wrap:nowrap;justify-content:flex-end;gap:4px">${ya ? `<small style="color:var(--ok)" title="ya asignados">✓${ya}</small>` : ""}<input class="pc" type="number" min="0" step="1" inputmode="numeric" data-c="${c.id}" data-f="${x.fecha}" ${off ? "disabled" : ""}></span>
        </td>`;
      }).join("")}
      <td class="num" data-tot="${c.id}" style="border-left:1px solid var(--line)"></td>
      <td class="num" data-rest="${c.id}"></td>
    </tr>`).join("");

  // Cupos de VENTA: grilla de contratos de venta con los cupos otorgados por día (asignados / total).
  // Clic en un contrato de venta = usar solo sus cupos para asignar.
  const ventasGrid = () => {
    const vs = d.ventas || [];
    if (!vs.length) return `<div class="note" style="margin-bottom:12px">No hay cupos de contratos de venta de ${esc(d.producto)} esta semana${p.destino ? ` en ${esc(p.destino)}` : ""}.</div>`;
    const porVenta = (id, f) => (d.ventas_dias || []).find((r) => r.contrato_venta_id === id && r.fecha === f);
    const celda = (r, f) => !r ? `<td class="num" style="${bg(f)}color:var(--muted)">·</td>`
      : `<td class="num" style="${bg(f)}"><span style="${r.disponibles ? "color:var(--warn);font-weight:650" : ""}">${r.asignados} / ${r.total}</span></td>`;
    const filasV = vs.map((v) => {
      const tot = (d.ventas_dias || []).filter((r) => r.contrato_venta_id === v.id).reduce((a, r) => ({ t: a.t + r.total, a: a.a + r.asignados, d: a.d + r.disponibles }), { t: 0, a: 0, d: 0 });
      const sel = String(p.cv) === String(v.id);
      return `<tr data-cv="${v.id}" style="cursor:pointer;${sel ? "background:var(--info-soft);" : ""}">
        ${celdaContrato(v.contraparte_nombre, v.numero, `Corredor: ${fcorr(v.corredor)}`)}
        ${d.dias.map((x) => celda(porVenta(v.id, x.fecha), x.fecha)).join("")}
        <td class="num" style="border-left:1px solid var(--line)">${tot.t}</td><td class="num">${tot.a}</td>
        <td class="num">${tot.d ? `<strong style="color:var(--warn)">${tot.d}</strong>` : "0"}</td></tr>`;
    }).join("");
    return `<h2 style="margin:4px 0 6px">Contratos de venta${p.cv ? ` <small><a href="#" id="cv-todos">usar todos</a></small>` : ""}</h2>
      <div class="table-wrap g" style="margin-bottom:14px"><table><thead><tr><th>Comprador · contrato de venta</th>${thDias}
        <th class="num" style="border-left:1px solid var(--line)">Total</th><th class="num">Asignados</th><th class="num">Pendientes</th></tr></thead>
        <tbody>${filasV}</tbody></table></div>`;
  };

  $("#grid").innerHTML = `
    ${p.origen === "VENTA" ? ventasGrid() : ""}
    <div class="row leyenda" id="est-flt" style="margin:0 0 8px">
      ${[["vig", "e-vig", "Vigentes", "Dentro del período de entrega"], ["ven", "e-ven", "Vencidos", "Pasó el fin del período de entrega"], ["fue", "e-fue", "Fuera de entrega", "El período de entrega todavía no empieza"]].map(([k, cls, txt, tip]) =>
        `<label class="chip ${estSel.has(k) ? "on" : ""}" title="${tip}"><input type="checkbox" data-est="${k}" ${estSel.has(k) ? "checked" : ""}><i class="${cls}"></i>${txt}<small class="muted">${fnum(d.por_estado?.[k] || 0)}</small></label>`).join("")}
      ${estSel.size ? `<a href="#" id="est-todos" style="font-size:12px">quitar filtro</a>` : ""}
      <small class="muted" style="margin-left:auto">${d.contratos_total > d.contratos.length ? `${d.contratos.length} de ${fnum(d.contratos_total)} contratos` : `${d.contratos.length} contratos`}</small>
    </div>
    <div class="table-wrap g" style="max-height:calc(100vh - 270px);overflow:auto"><table>
      <thead>
        <tr><th>Corredor</th><th>Vendedor</th><th>Contrato</th>${conPuerto ? `<th>Terminal</th>` : ""}<th class="num">Saldo<span style="display:block;font-weight:400;text-transform:none">cupos</span></th>${thDias}
          <th class="num" style="border-left:1px solid var(--line)">Semana</th><th class="num">Saldo<span style="display:block;font-weight:400;text-transform:none">después</span></th></tr>
      </thead>
      <tbody>
        ${filaResumen("Total", (x) => (x.disponibles + x.asignados ? fnum(x.disponibles + x.asignados) : "·"),
          `<td class="num" style="border-left:1px solid var(--line)">${fnum(d.dias.reduce((a, x) => a + x.disponibles + x.asignados, 0))}</td><td></td>`)}
        ${filaResumen("Pendientes", (x) => `<span data-pend="${x.fecha}"></span>`, `<td class="num" id="pend-tot" style="border-left:1px solid var(--line)"></td><td></td>`)}
        ${filas || `<tr><td colspan="13" class="empty">No hay contratos de compra de ${esc(d.producto)} con saldo para esta semana. Probá con "Todos con saldo" o el buscador.</td></tr>`}
      </tbody></table></div>`;

  $$("#est-flt [data-est]").forEach((cb) => (cb.onchange = () =>
    nav({ est: $$("#est-flt [data-est]").filter((x) => x.checked).map((x) => x.dataset.est).join(",") })));
  const estTodos = $("#est-todos"); if (estTodos) estTodos.onclick = (e) => { e.preventDefault(); nav({ est: "" }); };
  $$("#grid tr[data-cv]").forEach((tr) => (tr.onclick = () => nav({ cv: String(p.cv) === tr.dataset.cv ? "" : tr.dataset.cv })));
  const cvTodos = $("#cv-todos"); if (cvTodos) cvTodos.onclick = (e) => { e.preventDefault(); nav({ cv: "" }); };
  const inputs = $$(".pc");
  const contratos = Object.fromEntries(d.contratos.map((c) => [c.id, c]));
  const upd = () => {
    const porDia = {}, porContrato = {};
    let total = 0, problemas = 0;
    inputs.forEach((i) => {
      const n = Math.max(0, Math.floor(+i.value || 0));
      if (!n) return;
      porDia[i.dataset.f] = (porDia[i.dataset.f] || 0) + n;
      porContrato[i.dataset.c] = (porContrato[i.dataset.c] || 0) + n;
      total += n;
    });
    let pendTot = 0;
    d.dias.forEach((x) => {
      const rest = x.disponibles - (porDia[x.fecha] || 0);
      pendTot += Math.max(0, rest); // pendientes de asignar sobre el total de la semana
      if (rest < 0) problemas++;
      const el = $(`[data-pend="${x.fecha}"]`);
      el.innerHTML = !x.disponibles && !porDia[x.fecha] ? "·"
        : `<strong style="color:${rest < 0 ? "var(--bad)" : rest > 0 ? (x.pasado ? "var(--muted)" : "var(--warn)") : "var(--ok)"}">${rest}</strong>${porDia[x.fecha] ? `<span class="sub">${porDia[x.fecha]} cargados</span>` : ""}`;
    });
    $("#pend-tot").innerHTML = `<strong style="color:var(--warn)">${pendTot}</strong>`;
    Object.values(contratos).forEach((c) => {
      const n = porContrato[c.id] || 0;
      const ya = Object.values(c.ya).reduce((a, b) => a + b, 0);
      const rest = Math.floor((c.saldo - n * TN) / TN);
      if (n && c.saldo - n * TN < -1e-6) problemas++;
      $(`[data-tot="${c.id}"]`).innerHTML = (n ? `<strong>${n}</strong>` : "") + (ya ? `<span class="sub">✓ ${ya}</span>` : "");
      $(`[data-rest="${c.id}"]`).innerHTML = !n ? `<span class="muted">${fnum(Math.floor(c.saldo / TN))}</span>`
        : c.saldo - n * TN < -1e-6 ? `<strong style="color:var(--bad)">excede</strong>` : fnum(rest);
    });
    const nContr = Object.keys(porContrato).length;
    $("#resumen").innerHTML = total
      ? `<strong>${total} cupos</strong> en ${nContr} contrato${nContr > 1 ? "s" : ""} · ${fnum(total * TN)} tn aprox.${problemas ? ` · <span style="color:var(--bad)">revisá lo marcado en rojo</span>` : ""}`
      : `<span class="muted">0 cupos</span>`;
    $("#go").disabled = !total || problemas > 0;
  };
  inputs.forEach((i) => {
    i.oninput = upd;
    i.onkeydown = (e) => { // Enter / flechas: moverse como en una planilla
      const mov = { Enter: 1, ArrowDown: 1, ArrowUp: -1 }[e.key];
      if (!mov) return;
      e.preventDefault();
      const col = inputs.filter((x) => x.dataset.f === i.dataset.f && !x.disabled);
      col[col.indexOf(i) + mov]?.focus();
    };
    i.onfocus = () => i.select();
  });
  $("#limpiar").onclick = () => { inputs.forEach((i) => (i.value = "")); upd(); };
  $("#go").onclick = () => run(async () => {
    const items = inputs.filter((i) => +i.value > 0).map((i) => ({
      contrato_id: +i.dataset.c, fecha: i.dataset.f, cantidad: Math.floor(+i.value),
      puerto: conPuerto ? ($(`[data-pp="${i.dataset.c}"]`)?.value || null) : null,
    }));
    $("#go").disabled = true;
    try {
      const r = await api("POST", "/api/planilla/asignar", { producto: d.producto, destino: p.destino || null, origen: p.origen || null, contrato_venta_id: p.cv ? +p.cv : null, items });
      toast(`${r.asignados} cupos asignados a ${r.contratos} contrato${r.contratos > 1 ? "s" : ""}` + (r.avisos.length ? ` · ${r.avisos.length} fuera del período de entrega` : ""));
      router();
    } catch (e) { upd(); throw e; } // si falló, la grilla queda con lo cargado para corregir
  });
  upd();
};

/* ---------- Asignar cupos: buscar un contrato de compra y asignarle cupos disponibles ---------- */
STAFF_VIEWS.asignar = async function (p) {
  $("#title").textContent = "Asignar cupos a contrato de compra";
  if (!p.contrato) return asignarBuscar(p);

  const f = { destino: p.destino ?? "", origen: p.origen ?? "", desde: p.desde ?? "", hasta: p.hasta ?? "", terminal: p.terminal ?? "*" };
  const { contrato: c, cupos, terminales } = await api("GET", `/api/contratos/${p.contrato}/candidatos?` + qs(f));
  // Terminales con disponibilidad (con los demás filtros), para elegir a cuál asignar
  const totTerm = terminales.reduce((a, t) => a + t.disponibles, 0);
  const optsTerm = `<option value="*">Todas · ${totTerm} disp.</option>` + terminales.map((t) =>
    `<option value="${esc(t.terminal)}" ${t.terminal === f.terminal ? "selected" : ""}>${t.terminal ? esc(t.terminal) : "Sin terminal"}${f.destino ? "" : ` (${esc(t.destino)})`} · ${t.disponibles} disp.</option>`).join("");
  $("#actions").innerHTML = `<button class="btn" id="cambiar">Cambiar contrato</button>`;
  $("#cambiar").onclick = () => go("asignar", p.q ? { q: p.q } : null);
  const maxCupos = Math.floor(c.saldo / TN_CUPO);
  $("#view").innerHTML = `
    <div class="card" style="margin-bottom:14px">
      <div class="row" style="justify-content:space-between;align-items:flex-start">
        <div><div style="font-size:18px;font-weight:650">${esc(c.numero)} · ${esc(c.contraparte_nombre)}</div>
          <small>${fcuit(c.contraparte_cuit)} · ${esc(c.producto)} ${esc(c.cosecha || "")} · entrega ${fdate(c.fecha_desde)} – ${fdate(c.fecha_hasta)}${c.lugar_entrega ? " · " + esc(c.lugar_entrega) : ""}</small></div>
        ${badge(c.estado)}
      </div>
      <div class="kpis" style="margin:12px 0 0">
        <div><div class="muted" style="font-size:12px">Toneladas</div><strong>${fnum(c.toneladas)}</strong></div>
        <div><div class="muted" style="font-size:12px">Entregadas</div><strong>${fnum(c.toneladas_entregadas)}</strong></div>
        <div><div class="muted" style="font-size:12px">Con cupo asignado</div><strong>${fnum(c.tn_asignadas)}</strong> <small>(${c.cupos_asignados} cupos)</small></div>
        <div><div class="muted" style="font-size:12px">Saldo para asignar</div><strong style="font-size:18px">${fnum(c.saldo)} tn</strong> <small>≈ ${maxCupos} cupos</small></div>
      </div>
    </div>
    <div class="filters" id="flt">
      <label>Destino<select name="destino">${opts(FILTROS.destinos, f.destino)}</select></label>
      <label>Terminal<select name="terminal">${optsTerm}</select></label>
      <label>Origen<select name="origen">${opts(ORIGEN_OPTS, f.origen)}</select></label>
      <label>Desde<input type="date" name="desde" value="${esc(f.desde)}"></label>
      <label>Hasta<input type="date" name="hasta" value="${esc(f.hasta)}"></label>
      <label>Seleccionar primeros<div class="row" style="flex-wrap:nowrap"><input type="number" id="nsel" min="1" value="${Math.min(maxCupos, cupos.length) || ""}" style="width:70px"><button type="button" class="btn" id="bsel">Seleccionar</button></div></label>
    </div>
    <div id="tbl"></div>
    <div class="card row" id="barra" style="position:sticky;bottom:12px;margin-top:12px;justify-content:space-between">
      <div id="resumen"></div><button class="btn primary" id="go" disabled>Asignar</button>
    </div>`;
  const flt = $("#flt");
  flt.onchange = (e) => {
    if (e.target.id === "nsel") return;
    const v = fields(flt);
    if (e.target.name === "destino") v.terminal = "*"; // las terminales dependen del destino
    go("asignar", { ...p, ...v });
  };

  $("#tbl").innerHTML = table([
    { h: `<input type="checkbox" id="all">`, f: (r) => `<input type="checkbox" class="ck" value="${r.id}">` },
    { h: "Código", f: (r) => `<strong>${esc(r.codigo)}</strong>` },
    { h: "Fecha", f: (r) => fdate(r.fecha) + (r.en_periodo ? "" : ` ${badge("PENDIENTE", "fuera de período")}`) },
    { h: "Destino", k: "destino" },
    { h: "Terminal", f: (r) => (r.puerto ? esc(r.puerto) : `<span class="muted">Sin terminal</span>`) },
    { h: "Tn", f: (r) => fnum(r.toneladas), num: 1 },
    { h: "Origen", f: (r) => origenBadge(r.origen) + (r.contrato_venta_numero ? `<span class="sub">CV ${esc(r.contrato_venta_numero)} · ${esc(r.contrato_venta_contraparte)}</span>` : "") },
    { h: "Observaciones", k: "observaciones" },
  ], cupos, { empty: `No hay cupos disponibles de ${c.producto} con estos filtros` });

  const cks = $$(".ck");
  const byId = Object.fromEntries(cupos.map((r) => [r.id, r]));
  const upd = () => {
    const sel = cks.filter((x) => x.checked).map((x) => byId[x.value]);
    const tn = sel.reduce((a, r) => a + r.toneladas, 0);
    const fuera = sel.filter((r) => !r.en_periodo).length;
    const excede = tn > c.saldo + 1e-6;
    $("#resumen").innerHTML = sel.length
      ? `<strong>${sel.length} cupos · ${fnum(tn)} tn</strong> · saldo después: <strong style="color:${excede ? "var(--bad)" : "inherit"}">${fnum(c.saldo - tn)} tn</strong>`
        + (excede ? ` <span style="color:var(--bad)">· supera el saldo</span>` : "") + (fuera ? ` <span style="color:var(--warn)">· ${fuera} fuera de período</span>` : "")
      : `<span class="muted">Elegí los cupos a asignar (${cupos.length} disponibles)</span>`;
    $("#go").disabled = !sel.length || excede;
  };
  cks.forEach((x) => (x.onchange = upd));
  const all = $("#all"); if (all) all.onchange = () => { cks.forEach((x) => (x.checked = all.checked)); upd(); };
  $("#bsel").onclick = () => { const n = +$("#nsel").value || 0; cks.forEach((x, i) => (x.checked = i < n)); upd(); };
  upd();

  $("#go").onclick = () => run(async () => {
    const ids = cks.filter((x) => x.checked).map((x) => +x.value);
    $("#go").disabled = true;
    const r = await api("POST", "/api/cupos/asignar", { cupo_ids: ids, contrato_id: c.id });
    toast(`${r.asignados} cupos asignados a ${c.numero}` + (r.avisos.length ? ` · ${r.avisos.length} fuera de período` : ""));
    router();
  });
};

async function asignarBuscar(p) {
  $("#view").innerHTML = `
    <div class="filters" id="flt">
      <label style="flex:1;max-width:420px">Buscar contrato de compra<input name="q" id="q" value="${esc(p.q || "")}" placeholder="Número, vendedor o CUIT" autofocus></label>
      <label>Producto<select name="producto">${opts(FILTROS.productos, p.producto)}</select></label>
      <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0;align-self:end;padding-bottom:8px">
        <input type="checkbox" name="con_saldo" ${p.con_saldo === "false" ? "" : "checked"}> Solo vigentes con saldo para al menos 1 cupo (${TN_CUPO} tn)</label>
      <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0;align-self:end;padding-bottom:8px">
        <input type="checkbox" name="en_periodo" ${p.en_periodo === "true" ? "checked" : ""}> Con período de entrega vigente</label>
      <div class="row" style="margin-left:auto;flex-wrap:nowrap;align-self:end">
        <button type="button" class="btn sm" id="sem-prev" title="Semana anterior">◀</button>
        <input type="week" id="sem-pick" style="padding:4px 8px">
        <button type="button" class="btn sm" id="sem-next" title="Semana siguiente">▶</button>
        <button type="button" class="btn sm" id="sem-hoy">Semana actual</button>
      </div>
    </div>
    <div class="row leyenda" style="margin:-4px 0 8px;gap:8px">
      ${[["e-vig", "Vigente"], ["e-ven", "Vencido"], ["e-fue", "Fuera de entrega"]].map(([c, l]) => `<span class="chip" style="cursor:default"><i class="${c}"></i>${l}</span>`).join("")}
      <span class="sel-info" id="cnt" style="margin-left:auto"></span>
    </div><div id="tbl"></div>
    <div class="card row" style="position:sticky;bottom:12px;margin-top:12px;justify-content:space-between;z-index:2">
      <div id="resumen"></div>
      <div class="row"><button type="button" class="btn" id="limpiar">Limpiar</button><button type="button" class="btn primary" id="go" disabled>Asignar cupos</button></div>
    </div>`;
  const flt = $("#flt");
  const tbl = $("#tbl");
  // Terminales del catálogo por zona (para elegir a qué terminal van los cupos de cada contrato)
  const terminales = {};
  (await api("GET", "/api/puertos").catch(() => [])).filter((x) => x.activo)
    .forEach((x) => (terminales[x.zona] ||= []).push(x.nombre));
  let filasActuales = [];
  // Semana que se muestra en las columnas L a D (cupos ya asignados a cada contrato por día)
  const hoy = today();
  let lunes = weekToDate(isoWeek(p.semana || hoy));
  const LETRAS = ["L", "M", "M", "J", "V", "S", "D"];
  // Estado del contrato HOY: mismos colores que la Grilla
  const EST = { vig: ["e-vig", "Vigente"], ven: ["e-ven", "Vencido"], fue: ["e-fue", "Fuera de entrega"] };
  const estado = (c) => (c.fecha_hasta && hoy > c.fecha_hasta ? "ven" : c.fecha_desde && hoy < c.fecha_desde ? "fue" : "vig");
  const load = async () => {
    const v = fields(flt);
    const dias = [...Array(7)].map((_, i) => addDays(lunes, i));
    $("#sem-pick").value = isoWeek(lunes);
    let [data, asig] = await Promise.all([
      api("GET", "/api/contratos?" + qs({ tipo: "COMPRA", q: v.q, producto: v.producto, con_saldo: v.con_saldo })),
      api("GET", "/api/asignados-semana?" + qs({ desde: dias[0], hasta: dias[6] })),
    ]);
    if (v.con_saldo) data = data.filter((r) => r.saldo >= TN_CUPO);
    if (v.en_periodo) data = data.filter((r) => !r.fecha_hasta || r.fecha_hasta >= hoy);
    $("#cnt").textContent = `${fnum(data.length)} contratos`;
    // Orden: los que tienen cupos esta semana, después vigentes, fuera de entrega y vencidos; dentro, por vencimiento
    const tieneSem = (r) => dias.some((f) => (asig[r.id] || {})[f]);
    const ORDEN = { vig: 0, fue: 1, ven: 2 };
    data.sort((a, b) => tieneSem(b) - tieneSem(a) || ORDEN[estado(a)] - ORDEN[estado(b)]
      || (a.fecha_hasta || "9999").localeCompare(b.fecha_hasta || "9999") || a.numero.localeCompare(b.numero));
    data = data.slice(0, 300);
    if (!tbl.isConnected) return; // el usuario ya navegó a otra vista
    const bg = (f) => (f === hoy ? " hoy" : "");
    const puede = (r) => r.saldo >= TN_CUPO && r.estado === "VIGENTE";
    filasActuales = data;
    const optsTerm = (r) => `<option value="">Cualquiera</option>`
      + (terminales[r.lugar_entrega] || []).map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join("");
    tbl.innerHTML = `<div class="table-wrap g" style="max-height:calc(100vh - 300px);overflow:auto"><table>
      <thead><tr><th>Corredor</th><th>Vendedor</th><th>Contrato</th><th>Terminal</th><th class="num">Saldo<span style="display:block;font-weight:400;text-transform:none">cupos</span></th>
        ${dias.map((f, i) => `<th class="num${f === hoy ? " hoy" : ""}"><span style="font-size:13px;color:var(--ink)">${LETRAS[i]}</span><span style="display:block;font-weight:400">${f.slice(8, 10)}/${f.slice(5, 7)}</span></th>`).join("")}
        <th class="num" style="border-left:1px solid var(--line)">Semana</th><th class="num">Saldo<span style="display:block;font-weight:400;text-transform:none">después</span></th><th></th></tr></thead>
      <tbody>${data.map((r) => {
        const [cls, txt] = EST[estado(r)];
        const porDia = asig[r.id] || {};
        const tot = dias.reduce((a, f) => a + (porDia[f] || 0), 0);
        const periodo = `entrega ${r.fecha_desde ? fdate(r.fecha_desde) : "?"} – ${r.fecha_hasta ? fdate(r.fecha_hasta) : "?"}`;
        return `<tr class="${cls}-row">
          <td class="g-c g-corr"><span style="white-space:normal">${fcorr(r.corredor)}</span></td>
          <td class="g-vend"><span class="g-cli">${esc(r.contraparte_nombre || "(sin nombre)")}</span></td>
          <td style="white-space:nowrap"><strong>${esc(r.numero)}</strong><span class="sub">${esc(r.producto)} · ${esc(r.lugar_entrega || "—")} · ${periodo}</span></td>
          <td>${puede(r) ? `<select class="pp" data-pp="${r.id}" style="padding:3px 6px;max-width:170px" title="Terminal a la que van los cupos de este contrato">${optsTerm(r)}</select>` : ""}</td>
          <td class="num"><strong>${fnum(Math.max(0, Math.floor(r.saldo / TN_CUPO)))}</strong> <small class="muted">${fnum(r.saldo)} tn</small></td>
          ${dias.map((f) => `<td class="num ${cls}${bg(f)}" title="${txt} · ${periodo}">
            <span class="row" style="flex-wrap:nowrap;justify-content:flex-end;gap:4px">${porDia[f] ? `<small style="color:var(--ok)" title="ya asignados">✓${porDia[f]}</small>` : ""}<input class="pc" type="number" min="0" step="1" inputmode="numeric" data-c="${r.id}" data-f="${f}" ${f < hoy || !puede(r) ? "disabled" : ""}></span></td>`).join("")}
          <td class="num" data-tot="${r.id}" style="border-left:1px solid var(--line)">${tot ? `<span class="sub">✓ ${tot}</span>` : ""}</td>
          <td class="num" data-rest="${r.id}"><span class="muted">${fnum(Math.max(0, Math.floor(r.saldo / TN_CUPO)))}</span></td>
          <td>${puede(r) ? `<button type="button" class="btn sm" data-c="${r.id}" title="Elegir los códigos de cupo uno por uno">Elegir códigos</button>`
            : `<small class="muted">${r.estado !== "VIGENTE" ? "No vigente" : r.saldo > 0 ? "Saldo &lt; 1 cupo" : "Sin saldo"}</small>`}</td>
        </tr>`;
      }).join("") || `<tr><td colspan="15" class="empty">No hay contratos de compra que coincidan con los filtros</td></tr>`}</tbody></table></div>`;
    $$("button[data-c]", tbl).forEach((el) => (el.onclick = (e) => { e.stopPropagation(); go("asignar", { contrato: el.dataset.c, q: fields(flt).q }); }));
    const ins = $$(".pc", tbl);
    ins.forEach((i) => {
      i.oninput = upd;
      i.onfocus = () => i.select();
      i.onkeydown = (e) => { // Enter / flechas: moverse como en una planilla
        const mov = { Enter: 1, ArrowDown: 1, ArrowUp: -1 }[e.key];
        if (!mov) return;
        e.preventDefault();
        const col = ins.filter((x) => x.dataset.f === i.dataset.f && !x.disabled);
        col[col.indexOf(i) + mov]?.focus();
      };
    });
    upd();
  };
  // Totales de lo cargado: por contrato (no puede superar el saldo) y en general
  const upd = () => {
    const porC = {};
    let total = 0, problemas = 0;
    $$(".pc", tbl).forEach((i) => {
      const n = Math.max(0, Math.floor(+i.value || 0));
      if (n) { porC[i.dataset.c] = (porC[i.dataset.c] || 0) + n; total += n; }
    });
    filasActuales.forEach((r) => {
      const n = porC[r.id] || 0, tot = $(`[data-tot="${r.id}"]`), rest = $(`[data-rest="${r.id}"]`);
      if (!tot) return;
      const ya = tot.querySelector(".sub")?.outerHTML || "";
      tot.innerHTML = (n ? `<strong>${n}</strong>` : "") + ya;
      const exc = n && r.saldo - n * TN_CUPO < -1e-6;
      if (exc) problemas++;
      rest.innerHTML = !n ? `<span class="muted">${fnum(Math.max(0, Math.floor(r.saldo / TN_CUPO)))}</span>`
        : exc ? `<strong style="color:var(--bad)">excede</strong>` : fnum(Math.floor((r.saldo - n * TN_CUPO) / TN_CUPO));
    });
    const nC = Object.keys(porC).length;
    $("#resumen").innerHTML = total
      ? `<strong>${total} cupos</strong> en ${nC} contrato${nC > 1 ? "s" : ""} · ${fnum(total * TN_CUPO)} tn aprox.${problemas ? ` · <span style="color:var(--bad)">revisá lo marcado en rojo</span>` : ""}`
      : `<span class="muted">Cargá la cantidad de cupos por día en cada contrato</span>`;
    $("#go").disabled = !total || problemas > 0;
  };
  $("#limpiar").onclick = () => { $$(".pc", tbl).forEach((i) => (i.value = "")); upd(); };
  $("#go").onclick = () => run(async () => {
    const porId = Object.fromEntries(filasActuales.map((r) => [r.id, r]));
    const items = $$(".pc", tbl).filter((i) => +i.value > 0).map((i) => ({
      contrato_id: +i.dataset.c, fecha: i.dataset.f, cantidad: Math.floor(+i.value),
      destino: porId[i.dataset.c]?.lugar_entrega || null,
      puerto: $(`[data-pp="${i.dataset.c}"]`)?.value || null,
    }));
    $("#go").disabled = true;
    try {
      const r = await api("POST", "/api/planilla/asignar", { items });
      toast(`${r.asignados} cupos asignados a ${r.contratos} contrato${r.contratos > 1 ? "s" : ""}` + (r.avisos.length ? ` · ${r.avisos.length} fuera del período de entrega` : ""));
      await load();
    } catch (e) { upd(); throw e; } // si falló, queda lo cargado para corregir
  });
  const semana = (f) => { lunes = weekToDate(isoWeek(f)); run(load); };
  $("#sem-prev").onclick = () => semana(addDays(lunes, -7));
  $("#sem-next").onclick = () => semana(addDays(lunes, 7));
  $("#sem-hoy").onclick = () => semana(hoy);
  $("#sem-pick").onchange = (e) => e.target.value && semana(weekToDate(e.target.value));
  let t;
  $("#q").oninput = () => { clearTimeout(t); t = setTimeout(() => run(load), 250); };
  flt.onchange = (e) => { if (!e.target.closest(".row")) run(load); };
  $("#q").focus();
  await load();
}

/* ---------- fechas de semana (todo en UTC para no correr días por zona horaria) ---------- */
const addDays = (iso, n) => { const d = new Date(iso + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
function isoWeek(iso) { // "2026-11-02" -> "2026-W45" (valor de <input type="week">)
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + 3 - ((d.getUTCDay() + 6) % 7)); // jueves de esa semana
  const y = d.getUTCFullYear(), jan4 = new Date(Date.UTC(y, 0, 4));
  const w = 1 + Math.round(((d - jan4) / 864e5 - 3 + ((jan4.getUTCDay() + 6) % 7)) / 7);
  return `${y}-W${String(w).padStart(2, "0")}`;
}
function weekToDate(v) { // "2026-W45" -> lunes de esa semana
  const [y, w] = v.split("-W").map(Number);
  const jan4 = new Date(Date.UTC(y, 0, 4));
  const lunes1 = addDays(jan4.toISOString().slice(0, 10), -((jan4.getUTCDay() + 6) % 7));
  return addDays(lunes1, (w - 1) * 7);
}

/* Tablero: por producto y destino, una columna por día (L a D) con asignados / total, y totales de la semana */
function semanaTabla(t) {
  if (!t.semana.length) return `<div class="table-wrap"><div class="empty">No hay cupos cargados para esta semana</div></div>`;
  const dias = [...Array(7)].map((_, i) => addDays(t.semana_desde, i));
  const LETRAS = ["L", "M", "M", "J", "V", "S", "D"];
  const hoy = today();
  const suma = (list) => list.reduce((a, r) => ({ total: a.total + r.total, asignados: a.asignados + r.asignados, pendientes: a.pendientes + r.pendientes }), { total: 0, asignados: 0, pendientes: 0 });
  const pct = (r) => Math.round((100 * r.asignados) / Math.max(1, r.total));
  const bg = (f) => (f === hoy ? "background:var(--brand-soft);" : "");
  const celdaDia = (r, f, attrs) => !r.total ? `<td class="num" style="${bg(f)}color:var(--muted)">·</td>`
    : `<td class="num" ${attrs} style="${bg(f)}cursor:${attrs ? "pointer" : "default"}" title="${r.asignados} asignados · ${r.pendientes} pendientes · ${r.total} total">
        <span style="${r.pendientes ? "color:var(--warn);font-weight:650" : ""}">${r.asignados} / ${r.total}</span></td>`;
  const totales = (r, fuerte) => {
    const w = (v) => (fuerte ? `<strong>${v}</strong>` : v);
    return `<td class="num" style="border-left:1px solid var(--line)">${w(fnum(r.total))}</td><td class="num">${w(fnum(r.asignados))}</td>
      <td class="num">${r.pendientes ? `<strong style="color:var(--warn)">${fnum(r.pendientes)}</strong>` : "0"}</td>
      <td><div class="row" style="flex-wrap:nowrap"><div class="bar" style="flex:1"><i style="width:${pct(r)}%"></i></div><small style="width:36px;text-align:right">${pct(r)}%</small></div></td>`;
  };
  // labelAttrs: atributos de la celda del nombre (si se omite, usa los mismos que las celdas de día)
  const fila = (label, list, attrs, estilo, labelAttrs) => `<tr style="${estilo || ""}"><td ${labelAttrs ?? attrs} style="cursor:${(labelAttrs ?? attrs) ? "pointer" : "default"}">${label}</td>
    ${dias.map((f) => celdaDia(suma(list.filter((r) => r.fecha === f)), f, attrs ? `${attrs} data-f="${f}"` : "")).join("")}${totales(suma(list), !attrs)}</tr>`;

  // Filas desplegables de un destino: un renglón por contrato de compra con cupos asignados por día, y uno de "sin asignar"
  const subFilas = (key, p, d, list) => {
    const asig = (t.por_contrato || []).filter((r) => r.producto === p && r.destino === d);
    const oculto = `class="sub-${key}" style="display:none;font-size:13px"`;
    const contratos = [...new Map(asig.map((r) => [r.contrato_id, r])).values()];
    let html = contratos.map((c) => {
      const porDia = Object.fromEntries(asig.filter((r) => r.contrato_id === c.contrato_id).map((r) => [r.fecha, r.asignados]));
      const tot = Object.values(porDia).reduce((a, b) => a + b, 0);
      return `<tr ${oculto}><td data-contrato="${c.contrato_id}" style="cursor:pointer;padding-left:44px">
          <strong>${esc(c.numero)}</strong><span class="sub" style="white-space:normal">${esc(c.contraparte_nombre || "")}</span></td>
        ${dias.map((f) => `<td class="num" style="${bg(f)}${porDia[f] ? "" : "color:var(--muted)"}">${porDia[f] || "·"}</td>`).join("")}
        <td class="num" style="border-left:1px solid var(--line)">${tot}</td><td class="num">${tot}</td><td></td><td></td></tr>`;
    }).join("");
    const pend = suma(list).pendientes;
    if (pend) {
      html += `<tr ${oculto}><td style="padding-left:44px;color:var(--warn)">Sin asignar</td>
        ${dias.map((f) => { const n = suma(list.filter((r) => r.fecha === f)).pendientes;
          return `<td class="num" style="${bg(f)}${n ? "color:var(--warn);font-weight:650" : "color:var(--muted)"}">${n || "·"}</td>`; }).join("")}
        <td class="num" style="border-left:1px solid var(--line)">${pend}</td><td class="num">0</td><td class="num"><strong style="color:var(--warn)">${pend}</strong></td><td></td></tr>`;
    }
    return { html, n: contratos.length };
  };

  const productos = [...new Set(t.semana.map((r) => r.producto))];
  let body = "", key = 0;
  for (const p of productos) {
    const prod = t.semana.filter((r) => r.producto === p);
    body += fila(`<strong>${esc(p)}</strong>`, prod, `data-p="${esc(p)}"`, "background:var(--gray-soft)");
    for (const d of [...new Set(prod.map((r) => r.destino))]) {
      const list = prod.filter((r) => r.destino === d);
      const sub = subFilas(++key, p, d, list);
      const label = `<span style="padding-left:4px"><span class="chev" style="display:inline-block;width:14px;color:var(--muted)">▸</span>${esc(d)}</span>
        <small class="muted"> · ${sub.n ? `${sub.n} contrato${sub.n > 1 ? "s" : ""}` : "sin asignar"}</small>`;
      body += fila(label, list, `data-p="${esc(p)}" data-d="${esc(d)}"`, "", `data-toggle="${key}"`) + sub.html;
    }
  }
  body += fila("<strong>Total</strong>", t.semana, "", "border-top:2px solid var(--line)");
  return `<div class="table-wrap"><table><thead><tr><th>Producto / destino</th>
    ${dias.map((f, i) => `<th class="num" style="${bg(f)}"><span style="font-size:13px;color:var(--ink)">${LETRAS[i]}</span><span style="display:block;font-weight:400;text-transform:none">${f.slice(8, 10)}/${f.slice(5, 7)}</span></th>`).join("")}
    <th class="num" style="border-left:1px solid var(--line)">Total</th><th class="num">Asignados</th><th class="num">Pendientes</th><th style="min-width:130px">Asignado</th>
    </tr></thead><tbody>${body}</tbody></table></div>`;
}

function rowActions(r) {
  const b = [];
  if (["ASIGNADO", "UTILIZADO"].includes(r.estado_visible)) b.push(`<button class="btn sm" data-act="ctg" data-id="${r.id}">${r.ctg ? "Editar CTG" : "Cargar CTG"}</button>`);
  if (r.estado_visible === "ASIGNADO") b.push(`<button class="btn sm" data-act="usar" data-id="${r.id}">Utilizado</button>`, `<button class="btn sm" data-act="liberar" data-id="${r.id}">Liberar</button>`);
  if (r.estado_visible === "DISPONIBLE") b.push(`<button class="btn sm ghost" data-act="anular" data-id="${r.id}">Anular</button>`);
  return `<div class="row" style="flex-wrap:nowrap">${b.join("")}</div>`;
}
function bindRowActions(data, after = router) {
  $$("[data-act]").forEach((btn) => (btn.onclick = (ev) => {
    ev.stopPropagation();
    const r = data.find((x) => x.id === +btn.dataset.id);
    if (btn.dataset.act === "liberar") confirmar("Liberar cupo", `El cupo <strong>${esc(r.codigo)}</strong> vuelve a estar disponible y se desvincula del contrato ${esc(r.contrato_compra_numero)}.`, "Liberar", async () => { await api("POST", `/api/cupos/${r.id}/liberar`); toast("Cupo liberado"); after(); });
    if (btn.dataset.act === "anular") confirmar("Anular cupo", `¿Anular el cupo <strong>${esc(r.codigo)}</strong>? No podrá asignarse.`, "Anular", async () => { await api("POST", `/api/cupos/${r.id}/anular`); toast("Cupo anulado"); after(); }, "danger");
    if (btn.dataset.act === "ctg") ctgModal(r, after);
    if (btn.dataset.act === "usar") modal({
      title: `Marcar ${r.codigo} como utilizado`,
      body: `<label>CTG (opcional, 12 dígitos)<input name="ctg" value="${esc(r.ctg || "")}" inputmode="numeric" maxlength="15" placeholder="000000000000"></label>`,
      buttons: [{ label: "Confirmar descarga", cls: "primary", onClick: async (f) => { await api("POST", `/api/cupos/${r.id}/utilizar`, fields(f)); toast("Cupo marcado como utilizado"); after(); } }],
    });
  }));
}

async function asignarModal(cupos, preContrato) {
  const prods = [...new Set(cupos.map((c) => c.producto))];
  if (prods.length > 1) return toast("Seleccioná cupos de un solo producto", true);
  const contratos = await api("GET", "/api/contratos?" + qs({ tipo: "COMPRA", producto: prods[0], con_saldo: true }));
  const tn = cupos.reduce((a, c) => a + c.toneladas, 0);
  const fechas = cupos.map((c) => c.fecha).sort();
  modal({
    title: `Asignar ${cupos.length} cupos de ${prods[0]}`,
    body: `<div class="note">${cupos.length} cupos · ${fnum(tn)} tn · ${fdate(fechas[0])}${fechas.length > 1 ? " a " + fdate(fechas.at(-1)) : ""} · ${[...new Set(cupos.map((c) => c.destino))].join(", ")}</div>
      ${contratos.length ? `<label>Contrato de compra<select name="contrato_id">${opts(contratos.map((c) => [c.id, `${c.numero} · ${c.contraparte_nombre} · saldo ${fnum(c.saldo)} tn · ${fdate(c.fecha_desde)}–${fdate(c.fecha_hasta)}`]), preContrato, null)}</select></label>
      <div id="chk"></div>` : `<div class="note bad">No hay contratos de compra vigentes de ${esc(prods[0])} con saldo.</div>`}`,
    buttons: contratos.length ? [{ label: "Asignar", cls: "primary", onClick: async (f) => {
      const r = await api("POST", "/api/cupos/asignar", { cupo_ids: cupos.map((c) => c.id), contrato_id: +fields(f).contrato_id });
      toast(`${r.asignados} cupos asignados` + (r.avisos.length ? ` · ${r.avisos.length} avisos de fecha` : ""), !!r.avisos.length);
      router();
    } }] : [],
    onOpen: (f) => {
      const sel = $("[name=contrato_id]", f); if (!sel) return;
      const check = () => {
        const c = contratos.find((x) => x.id === +sel.value);
        const fuera = cupos.filter((cu) => (c.fecha_desde && cu.fecha < c.fecha_desde) || (c.fecha_hasta && cu.fecha > c.fecha_hasta));
        $("#chk").innerHTML = (tn > c.saldo ? `<div class="note bad">Saldo insuficiente: el contrato tiene ${fnum(c.saldo)} tn y los cupos suman ${fnum(tn)} tn.</div>` : `<div class="note ok">Saldo después de asignar: ${fnum(c.saldo - tn)} tn.</div>`)
          + (fuera.length ? `<div class="note warn">${fuera.length} cupos quedan fuera del período de entrega del contrato.</div>` : "");
      };
      sel.onchange = check; check();
    },
  });
}

async function contratoModal(id) {
  const c = await api("GET", `/api/contratos/${id}`);
  const compra = c.tipo === "COMPRA";
  modal({
    title: `Contrato ${c.tipo.toLowerCase()} ${c.numero}`, wide: true,
    body: `<div class="kpis" style="margin:0">
        <div class="card kpi"><div class="l">${compra ? "Vendedor" : "Comprador"}</div><div style="font-weight:600">${esc(c.contraparte_nombre)}</div><small>${fcuit(c.contraparte_cuit)}</small></div>
        <div class="card kpi"><div class="l">Corredor</div><div style="font-weight:600">${fcorr(c.corredor)}</div></div>
        <div class="card kpi"><div class="l">Producto</div><div class="v" style="font-size:18px">${esc(c.producto)} <small>${esc(c.cosecha)}</small></div></div>
        <div class="card kpi"><div class="l">Toneladas / entregadas</div><div class="v" style="font-size:18px">${fnum(c.toneladas)} / ${fnum(c.toneladas_entregadas)}</div></div>
        <div class="card kpi"><div class="l">Saldo${compra ? " sin cupo" : ""}</div><div class="v" style="font-size:18px">${fnum(c.saldo)} tn</div></div>
      </div>
      <p class="muted" style="margin:0">Entrega ${fdate(c.fecha_desde)} – ${fdate(c.fecha_hasta)}${c.lugar_entrega ? " · " + esc(c.lugar_entrega) : ""}${c.operacion ? " · Operación " + esc(c.operacion) : ""} · Actualizado de SIGAM ${fdt(c.actualizado)}</p>
      <h2 style="margin-top:6px">Cupos ${compra ? "asignados" : "aportados por este contrato"}</h2>
      ${table([
        { h: "Código", k: "codigo" }, { h: "Fecha", f: (r) => fdate(r.fecha) }, { h: "Destino", k: "destino" },
        { h: "Origen", f: (r) => origenBadge(r.origen) }, { h: "Estado", f: (r) => badge(r.estado_visible) },
        compra ? { h: "CTG", f: ctgCelda } : { h: "Contrato compra", k: "contrato_compra_numero" },
        { h: "", f: rowActions },
      ], c.cupos, { empty: "Sin cupos" })}`,
    buttons: compra && c.estado === "VIGENTE" && c.saldo > 0
      ? [{ label: "Asignar cupos", cls: "primary", onClick: () => go("asignar", { contrato: c.id }) }] : [],
    onOpen: () => bindRowActions(c.cupos, () => { $("#modal").close(); router(); }),
  });
}

async function resolverModal(s) {
  const cand = await api("GET", `/api/solicitudes/${s.id}/candidatos`);
  const faltan = s.cantidad - s.cantidad_aprobada;
  modal({
    title: `Solicitud #${s.id} · ${s.contraparte_nombre}`, wide: true,
    body: `<div class="note">Contrato <strong>${esc(s.contrato_numero)}</strong> (${esc(s.producto)}) · pide <strong>${s.cantidad}</strong> cupos para el <strong>${fdate(s.fecha)}</strong>${s.destino_preferido ? ` en <strong>${esc(s.destino_preferido)}</strong>` : ""}${s.cantidad_aprobada ? ` · ya aprobados ${s.cantidad_aprobada}` : ""}.
      ${s.observaciones ? `<br>Obs.: ${esc(s.observaciones)}` : ""}</div>
      <div class="row"><strong>Elegí hasta ${faltan} cupos</strong><span class="sel-info" id="cnt">0 seleccionados</span>
      <button type="button" class="btn sm" id="auto">Seleccionar sugeridos</button></div>
      ${table([
        { h: "", f: (r) => `<input type="checkbox" class="ck" value="${r.id}">` }, { h: "Código", k: "codigo" },
        { h: "Fecha", f: (r) => fdate(r.fecha) + (r.distancia ? `<span class="sub">${r.distancia > 0 ? "±" : ""}${fnum(r.distancia)} días</span>` : "") },
        { h: "Destino", f: (r) => esc(r.destino) + (s.destino_preferido && r.destino === s.destino_preferido ? ` ${badge("DISPONIBLE", "preferido")}` : "") },
        { h: "Origen", f: (r) => origenBadge(r.origen) + (r.contrato_venta_numero ? `<span class="sub">CV ${esc(r.contrato_venta_numero)}</span>` : "") },
        { h: "Tn", f: (r) => fnum(r.toneladas), num: 1 },
      ], cand, { empty: `No hay cupos disponibles de ${s.producto}` })}
      <label>Respuesta al cliente (obligatoria para rechazar)<textarea name="respuesta" rows="2"></textarea></label>`,
    buttons: [
      { label: faltan < s.cantidad ? "Rechazar resto" : "Rechazar", cls: "danger", onClick: async (f) => {
        await api("POST", `/api/solicitudes/${s.id}/rechazar`, { respuesta: fields(f).respuesta }); toast("Solicitud rechazada"); router();
      } },
      { label: "Aprobar seleccionados", cls: "primary", onClick: async (f) => {
        const ids = $$(".ck:checked", f).map((c) => +c.value);
        if (!ids.length) throw new Error("Seleccioná al menos un cupo");
        const r = await api("POST", `/api/solicitudes/${s.id}/aprobar`, { cupo_ids: ids, respuesta: fields(f).respuesta });
        toast(`${r.asignados} cupos asignados · solicitud ${r.estado}` + (r.avisos.length ? ` · ${r.avisos.join("; ")}` : ""), !!r.avisos.length); router();
      } },
    ],
    onOpen: (f) => {
      const cks = $$(".ck", f);
      const upd = () => {
        const n = cks.filter((c) => c.checked).length;
        $("#cnt").textContent = `${n} seleccionados`;
        cks.forEach((c) => (c.disabled = !c.checked && n >= faltan));
      };
      cks.forEach((c) => (c.onchange = upd));
      $("#auto").onclick = () => { cks.forEach((c, i) => (c.checked = i < faltan)); upd(); };
      upd();
    },
  });
}

function solicitudDetalle(s) {
  modal({
    title: `Solicitud #${s.id}`,
    body: `<div class="note">${esc(s.contraparte_nombre)} · contrato ${esc(s.contrato_numero)} · ${s.cantidad_aprobada} de ${s.cantidad} cupos para ${fdate(s.fecha)} · ${badge(s.estado)}</div>
      ${s.respuesta ? `<p style="margin:0"><strong>Respuesta:</strong> ${esc(s.respuesta)} <small>(${esc(s.resuelto_por_nombre)}, ${fdt(s.resuelto_en)})</small></p>` : ""}
      ${table([{ h: "Código", k: "codigo" }, { h: "Fecha", f: (r) => fdate(r.fecha) }, { h: "Destino", k: "destino" }, { h: "Estado", f: (r) => badge(r.estado) }, { h: "CTG", f: (r) => fctg(r.ctg) }], s.cupos, { empty: "Sin cupos asignados" })}`,
  });
}

/* Alta manual de cupos de venta: se elige el contrato y se pegan uno o varios códigos separados por ";".
   Producto y comprador salen del contrato; la fecha, del código (AAAAMMDD…) o del campo Fecha. */
function altaVentaModal() {
  let contrato = null;
  const fechaCodigo = (c) => {
    const m = /^(\d{4})(\d{2})(\d{2})\d*$/.exec(c);
    if (!m) return null;
    const d = new Date(`${m[1]}-${m[2]}-${m[3]}T00:00:00`);
    return !isNaN(d) && d.getDate() === +m[3] && Math.abs(d - new Date()) < 366 * 864e5 ? `${m[1]}-${m[2]}-${m[3]}` : null;
  };
  const separar = (t) => [...new Set(t.split(/[;\n\r\t]+/).map((s) => s.trim()).filter(Boolean))];

  modal({
    title: "Alta manual de cupos de venta", wide: true,
    body: `
      <div class="filters" style="margin:0">
        <label style="flex:1;min-width:220px">Contrato de venta<input id="cv-q" placeholder="Número o comprador" autocomplete="off"></label>
        <label>Producto<select id="cv-prod"><option value="">Todos</option></select></label>
        <label>Destino<select id="cv-lugar"><option value="">Todos</option></select></label>
        <label style="flex-direction:row;display:flex;align-items:center;gap:6px;min-width:0;align-self:end;padding-bottom:8px">
          <input type="checkbox" id="cv-pend" checked> Con pendiente</label>
      </div>
      <div id="cv-res"></div>
      <div id="cv-sel"></div>
      <label>Códigos de cupo (separados por ;)<textarea name="codigos" id="cv-cod" rows="3" placeholder="20261106082286; 20261106049846; 20261106009154;"></textarea></label>
      <div class="form-grid">
        <label>Fecha (si el código no la trae)<input type="date" name="fecha" value="${today()}"></label>
        <label>Destino<input name="destino" id="cv-dest" list="dl-dest" placeholder="Del contrato"></label>
        <label>Terminal (STOP) <span style="color:var(--bad)">*</span><select name="puerto" id="cv-puerto" required><option value="">Cargando terminales…</option></select></label>
        <label>Toneladas por cupo<input type="number" name="toneladas" value="${TN_CUPO}"></label>
        <label class="full">Observaciones<input name="observaciones"></label>
      </div>
      <datalist id="dl-dest">${FILTROS.destinos.map((d) => `<option value="${esc(d)}">`).join("")}</datalist>
      <div id="cv-prev"></div>`,
    buttons: [{ label: "Guardar cupos", cls: "primary", onClick: async (f) => {
      if (!contrato) throw new Error("Elegí el contrato de venta");
      const d = fields(f);
      if (!(d.puerto || "").trim()) { $("#cv-puerto", f).focus(); throw new Error("Indicá la terminal: es obligatoria en los cupos de venta"); }
      const r = await api("POST", "/api/cupos/venta", { ...d, contrato_venta_id: contrato.id, toneladas: d.toneladas ? +d.toneladas : null });
      loadFiltros();
      if (r.omitidos) {
        $("#cv-prev").innerHTML = `<div class="note ${r.insertados ? "warn" : "bad"}">${r.insertados} cupos cargados, ${r.omitidos} omitidos:
          <ul style="margin:6px 0 0;padding-left:18px">${r.detalle.map((x) => `<li>${esc(separar(d.codigos)[x.fila - 2] || "")}: ${esc(x.motivo)}</li>`).join("")}</ul></div>`;
        if (r.insertados) $("#cv-cod").value = r.detalle.map((x) => separar(d.codigos)[x.fila - 2]).join("; ");
        $("#cv-prev").scrollIntoView({ behavior: "smooth", block: "center" });
        return false; // dejar abierto para corregir los omitidos
      }
      // Todo bien: se cierra la ventana y queda el aviso de confirmación
      toast(`✓ ${r.insertados} cupo${r.insertados > 1 ? "s" : ""} cargado${r.insertados > 1 ? "s" : ""} al contrato de venta ${contrato.numero}`);
      router();
    } }],
    onOpen: (f) => {
      const q = $("#cv-q", f), res = $("#cv-res", f);
      let lista = [];
      const elegir = (c) => {
        contrato = c;
        $$("tr[data-k]", res).forEach((tr) => tr.classList.toggle("sel", lista[+tr.dataset.k]?.id === c.id));
        $("#cv-sel", f).innerHTML = `<div class="note ok"><strong>${esc(c.numero)}</strong> · ${esc(c.contraparte_nombre || "sin comprador")} · ${esc(c.producto)}
          · entrega ${fdate(c.fecha_desde)} – ${fdate(c.fecha_hasta)} · pendiente ${fnum(c.saldo)} tn · ${c.cupos_total} cupos cargados</div>`;
        const dest = $("#cv-dest", f);
        dest.value = c.lugar_entrega || "";
        dest.placeholder = c.lugar_entrega ? "" : "El contrato no tiene destino: indicalo";
        dest.dispatchEvent(new Event("change")); // terminales de ese destino primero
        prev();
      };
      // Buscador de contratos de venta: texto + producto + destino, lista con scroll
      const buscar = () => run(async () => {
        const filtros = { tipo: "VENTA", q: q.value.trim(), producto: $("#cv-prod", f).value, lugar: $("#cv-lugar", f).value,
                          con_saldo: $("#cv-pend", f).checked || "" };
        lista = await api("GET", "/api/contratos?" + qs(filtros));
        const mostrar = lista.slice(0, 500);
        res.innerHTML = !lista.length ? `<div class="note">Sin contratos de venta que coincidan</div>`
          : `<div class="table-wrap cv-lista"><table><thead><tr><th>Contrato</th><th>Comprador</th><th>Corredor</th><th>Producto</th><th>Destino</th>
              <th class="num">Pendiente tn</th><th>Entrega</th><th class="num">Cupos</th></tr></thead><tbody>
              ${mostrar.map((c, i) => `<tr data-k="${i}" class="${contrato && contrato.id === c.id ? "sel" : ""}">
                <td><strong>${esc(c.numero)}</strong></td><td style="white-space:normal">${esc(c.contraparte_nombre || "")}</td>
                <td style="white-space:normal">${fcorr(c.corredor)}</td><td>${esc(c.producto)}</td><td>${esc(c.lugar_entrega || "—")}${c.lugar_detalle ? ` <small class="muted">${esc(c.lugar_detalle)}</small>` : ""}</td>
                <td class="num">${fnum(Math.max(0, c.saldo))}</td><td>${fdate(c.fecha_desde)} – ${fdate(c.fecha_hasta)}</td>
                <td class="num">${c.cupos_total}</td></tr>`).join("")}
            </tbody></table></div>
            <small class="muted">${lista.length > mostrar.length ? `${mostrar.length} de ${fnum(lista.length)} · acotá con los filtros` : `${lista.length} contratos`}</small>`;
        $$("tr[data-k]", res).forEach((tr) => (tr.onclick = () => elegir(lista[+tr.dataset.k])));
      });
      let t;
      q.oninput = () => { clearTimeout(t); t = setTimeout(buscar, 250); };
      ["#cv-prod", "#cv-lugar", "#cv-pend"].forEach((s) => ($(s, f).onchange = buscar));
      run(async () => { // opciones de los filtros y primera carga
        const o = await api("GET", "/api/contratos-opciones?tipo=VENTA");
        $("#cv-prod", f).innerHTML = opts(o.productos, "");
        $("#cv-lugar", f).innerHTML = opts(o.lugares, "");
        buscar();
      });
      const prev = () => {
        const cods = separar($("#cv-cod", f).value);
        const fdef = $("[name=fecha]", f).value;
        if (!cods.length) { $("#cv-prev", f).innerHTML = ""; return; }
        $("#cv-prev", f).innerHTML = `<p class="muted" style="margin:0 0 6px">${cods.length} cupos a cargar${contrato ? ` · ${esc(contrato.producto)} · ${fnum(cods.length * (+$("[name=toneladas]", f).value || 0))} tn` : ""}</p>`
          + table([{ h: "Código", f: (c) => `<strong>${esc(c)}</strong>` },
                   { h: "Fecha", f: (c) => (fechaCodigo(c) ? `${fdate(fechaCodigo(c))} <small class="muted">del código</small>` : fdate(fdef)) }], cods);
      };
      // Terminal: lista desplegable con todas las terminales informadas por STOP, agrupadas por destino.
      // Las del destino elegido van primero; al elegir una terminal se completa su destino.
      let terminales = [];
      const selTerm = $("#cv-puerto", f), dest = $("#cv-dest", f);
      const armarTerminales = () => {
        const z = dest.value.trim().toUpperCase(), actual = selTerm.value;
        const grupos = {};
        terminales.filter((t) => t.puerto).forEach((t) => (grupos[t.zona || "SIN DESTINO"] ||= []).push(t));
        const zonasOrden = Object.keys(grupos).sort((a, b) => (b === z) - (a === z) || a.localeCompare(b));
        selTerm.innerHTML = !terminales.length ? `<option value="">No hay terminales de STOP: sincronizá STOP primero</option>`
          : `<option value="">Elegí la terminal…</option>` + zonasOrden.map((zn) => `<optgroup label="${esc(zn)}">${grupos[zn]
              .sort((a, b) => a.puerto.localeCompare(b.puerto))
              .map((t) => `<option value="${esc(t.puerto)}" data-zona="${esc(t.zona || "")}" ${t.puerto === actual ? "selected" : ""}>${esc(t.puerto)}${t.localidad ? ` · ${esc(t.localidad)}` : ""}</option>`).join("")}</optgroup>`).join("");
      };
      run(async () => { terminales = await api("GET", "/api/stop/terminales"); armarTerminales(); });
      dest.addEventListener("change", armarTerminales);
      selTerm.onchange = () => { const z = selTerm.selectedOptions[0]?.dataset.zona; if (z) dest.value = z; };
      $("#cv-cod", f).oninput = prev;
      $("[name=fecha]", f).onchange = prev;
      $("[name=toneladas]", f).oninput = prev;
      q.focus();
    },
  });
}

function usuarioModal(u) {
  const nuevo = !u;
  modal({
    title: nuevo ? "Nuevo usuario" : `Editar ${u.nombre}`,
    body: `<div class="form-grid">
      <label>Email<input name="email" type="email" value="${esc(u?.email)}" ${nuevo ? "" : "disabled"}></label>
      <label>Nombre<input name="nombre" value="${esc(u?.nombre)}"></label>
      <label>Rol<select name="rol">${opts([["CLIENTE", "Cliente (vendedor)"], ["OPERADOR", "Operador logística"], ["ADMIN", "Administrador"]], u?.rol || "CLIENTE", null)}</select></label>
      <label>CUIT (clientes)<input name="cuit" value="${esc(fcuit(u?.cuit))}" placeholder="30-12345678-9"></label>
      <label>${nuevo ? "Contraseña inicial" : "Nueva contraseña (opcional)"}<input name="password" type="text" minlength="8" autocomplete="new-password"></label>
      ${nuevo ? "" : `<label style="flex-direction:row;display:flex;align-items:center;gap:6px;align-self:end"><input type="checkbox" name="activo" ${u.activo ? "checked" : ""}> Activo</label>`}
      <p class="muted full" style="margin:0">El cliente ve los contratos de compra de SIGAM cuyo CUIT de contraparte coincide con el suyo.</p></div>`,
    buttons: [{ label: "Guardar", cls: "primary", onClick: async (f) => {
      const d = fields(f);
      if (nuevo) await api("POST", "/api/usuarios", d);
      else { if (!d.password) delete d.password; delete d.email; await api("PATCH", `/api/usuarios/${u.id}`, d); }
      toast("Usuario guardado"); router();
    } }],
  });
}

/* =====================================================================
   VISTAS CLIENTE
   ===================================================================== */
const CLIENT_VIEWS = {
  async "mis-contratos"() {
    $("#title").textContent = "Mis contratos de compra";
    const data = await api("GET", "/api/contratos?tipo=COMPRA");
    $("#view").innerHTML = `<p class="muted" style="margin-top:0">Contratos donde vendés a Amaggi. El saldo descuenta lo entregado y los cupos ya asignados.</p>` + table([
      { h: "Contrato", f: (r) => `<strong>${esc(r.numero)}</strong>` },
      { h: "Producto", f: (r) => `${esc(r.producto)}<span class="sub">${esc(r.cosecha)}</span>` },
      { h: "Toneladas", f: (r) => fnum(r.toneladas), num: 1 }, { h: "Entregadas", f: (r) => fnum(r.toneladas_entregadas), num: 1 },
      { h: "Con cupo", f: (r) => `${fnum(r.tn_asignadas)}<span class="sub">${r.cupos_asignados} cupos</span>`, num: 1 },
      { h: "Saldo", f: (r) => `<strong>${fnum(r.saldo)}</strong>`, num: 1 },
      { h: "Entrega", f: (r) => `${fdate(r.fecha_desde)} – ${fdate(r.fecha_hasta)}<span class="sub">${esc(r.lugar_entrega)}</span>` },
      { h: "Estado", f: (r) => badge(r.estado) },
      { h: "", f: (r) => (r.estado === "VIGENTE" && r.saldo >= TN_CUPO ? `<button class="btn sm primary" data-sol="${r.id}">Solicitar cupos</button>` : "") },
    ], data, { empty: "No hay contratos asociados a tu CUIT. Contactá a Amaggi." });
    $$("[data-sol]").forEach((b) => (b.onclick = () => solicitarModal(data.find((c) => c.id === +b.dataset.sol))));
  },

  async "mis-solicitudes"() {
    $("#title").textContent = "Mis solicitudes";
    const data = await api("GET", "/api/solicitudes");
    $("#view").innerHTML = table([
      { h: "#", k: "id" }, { h: "Fecha pedida", f: (r) => fdate(r.fecha) }, { h: "Contrato", f: (r) => `${esc(r.contrato_numero)}<span class="sub">${esc(r.producto)}</span>` },
      { h: "Cupos", f: (r) => `${r.cantidad_aprobada} / ${r.cantidad}`, num: 1 }, { h: "Destino pref.", f: (r) => esc(r.destino_preferido || "—") },
      { h: "Estado", f: (r) => badge(r.estado) },
      { h: "Cupos asignados", f: (r) => `<span style="white-space:normal">${r.cupos.map((c) => `${esc(c.codigo)} <small>${fdate(c.fecha)} ${esc(c.destino)}</small>`).join("<br>") || "—"}</span>` },
      { h: "Respuesta", f: (r) => `<span style="white-space:normal">${esc(r.respuesta || "")}</span>` },
      { h: "", f: (r) => (r.estado === "PENDIENTE" ? `<button class="btn sm danger" data-can="${r.id}">Cancelar</button>` : "") },
    ], data, { empty: "Todavía no hiciste solicitudes. Pedí cupos desde Mis contratos." });
    $$("[data-can]").forEach((b) => (b.onclick = () => confirmar("Cancelar solicitud", "¿Cancelar esta solicitud pendiente?", "Cancelar solicitud", async () => { await api("POST", `/api/solicitudes/${b.dataset.can}/cancelar`); toast("Solicitud cancelada"); router(); }, "danger")));
  },

  async "mis-cupos"() {
    $("#title").textContent = "Mis cupos";
    const data = await api("GET", "/api/cupos?" + qs({ desde: "" }));
    $("#view").innerHTML = table([
      { h: "Código de cupo", f: (r) => `<strong>${esc(r.codigo)}</strong>` }, { h: "Fecha", f: (r) => fdate(r.fecha) },
      { h: "Destino", k: "destino" }, { h: "Producto", k: "producto" }, { h: "Contrato", k: "contrato_compra_numero" },
      { h: "CTG", f: ctgCelda }, { h: "Estado", f: (r) => badge(r.estado_visible) },
      { h: "", f: (r) => (["ASIGNADO", "UTILIZADO"].includes(r.estado) ? `<button class="btn sm" data-tr="${r.id}">${r.ctg ? "Editar" : "Cargar"} CTG</button>` : "") },
    ], data, { empty: "No tenés cupos asignados" });
    $$("[data-tr]").forEach((b) => (b.onclick = () => ctgModal(data.find((x) => x.id === +b.dataset.tr))));
  },
};

function solicitarModal(c) {
  const max = Math.floor(c.saldo / TN_CUPO);
  const minDate = [today(), c.fecha_desde].filter(Boolean).sort().at(-1);
  modal({
    title: `Solicitar cupos · contrato ${c.numero}`,
    body: `<div class="note">${esc(c.producto)} · saldo ${fnum(c.saldo)} tn ≈ hasta <strong>${max}</strong> cupos de ${TN_CUPO} tn · entrega ${fdate(c.fecha_desde)} – ${fdate(c.fecha_hasta)}</div>
      <div class="form-grid">
        <label>Fecha de descarga<input type="date" name="fecha" value="${minDate}" min="${today()}"></label>
        <label>Cantidad de cupos (camiones)<input type="number" name="cantidad" value="1" min="1" max="${max}"></label>
        <label>Destino preferido<select name="destino_preferido">${opts(FILTROS.destinos, "", "Indistinto")}</select></label>
        <label class="full">Observaciones<textarea name="observaciones" rows="2"></textarea></label></div>`,
    buttons: [{ label: "Enviar solicitud", cls: "primary", onClick: async (f) => {
      const d = fields(f);
      await api("POST", "/api/solicitudes", { ...d, contrato_compra_id: c.id, cantidad: +d.cantidad });
      toast("Solicitud enviada. Te avisaremos cuando sea aprobada."); go("mis-solicitudes");
    } }],
  });
}

/* ---------- arranque ---------- */
async function loadFiltros() { FILTROS = await api("GET", "/api/filtros").catch(() => FILTROS); }

function showLogin() {
  ME = null;
  $("#shell").classList.add("hidden");
  $("#login").classList.remove("hidden");
}
async function start() {
  try { ME = await api("GET", "/api/me"); } catch { return showLogin(); }
  $("#login").classList.add("hidden");
  $("#shell").classList.remove("hidden");
  $("#me-name").textContent = ME.nombre;
  $("#me-role").textContent = { ADMIN: "Administrador", OPERADOR: "Operador logística", CLIENTE: "Cliente · " + fcuit(ME.cuit) }[ME.rol];
  await loadFiltros();
  router();
}
$("#login-form").onsubmit = async (e) => {
  e.preventDefault();
  $("#login-error").textContent = "";
  try { await api("POST", "/api/login", fields(e.target)); location.hash = ""; start(); }
  catch (err) { $("#login-error").textContent = err.message; }
};
$("#logout").onclick = async () => { await api("POST", "/api/logout").catch(() => {}); showLogin(); };
window.addEventListener("hashchange", router);
start();
