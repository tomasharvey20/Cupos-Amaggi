# Abre el Sistema de Cupos: si el servidor no está corriendo lo inicia (en una ventana minimizada)
# y después abre la app en el navegador.
$ErrorActionPreference = "SilentlyContinue"
Set-Location $PSScriptRoot
$activo = $false
try { $activo = (Invoke-WebRequest http://127.0.0.1:8000/ -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch {}
if (-not $activo) {
    # La ruta va entre comillas: la carpeta puede tener espacios (ej. "OneDrive - Amaggi Corp")
    Start-Process powershell -ArgumentList "-NoExit -NoProfile -ExecutionPolicy Bypass -File `"$PSScriptRoot\iniciar.ps1`"" `
        -WorkingDirectory $PSScriptRoot -WindowStyle Minimized
    for ($i = 0; $i -lt 20 -and -not $activo; $i++) {
        Start-Sleep -Milliseconds 500
        try { $activo = (Invoke-WebRequest http://127.0.0.1:8000/ -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch {}
    }
}
Start-Process "http://localhost:8000"
