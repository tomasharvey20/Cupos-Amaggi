# Inicia el Sistema de Cupos Amaggi.
#   .\iniciar.ps1            -> levanta el servidor en http://localhost:8000
#   .\iniciar.ps1 -Demo      -> la primera vez, carga usuarios y datos de ejemplo
#   .\iniciar.ps1 -Port 9000 -Listen 0.0.0.0   -> accesible desde la red
param([switch]$Demo, [int]$Port = 8000, [string]$Listen = "127.0.0.1")
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# El entorno virtual vive en una ruta corta: Windows sin "long paths" falla al instalar pydantic en rutas largas.
$venv = Join-Path $env:USERPROFILE ".venvs\cupos"
$py = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path $py)) {
    $base = (Get-Command py -ErrorAction SilentlyContinue).Source
    if (-not $base) { $base = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe" }
    Write-Host "Creando entorno virtual en $venv ..."
    & $base -m venv $venv
    & $py -m pip install -q -r requirements.txt
}

$db = if ($env:CUPOS_DB) { $env:CUPOS_DB } else { Join-Path $PSScriptRoot "data\cupos.db" }
if (-not (Test-Path $db)) {
    if ($Demo) { & $py -m app.seed --demo }
    else {
        Write-Host "Base nueva. Creá el administrador con:"
        Write-Host "  $py -m app.seed --admin tu@email.com --password 'ClaveSegura123'"
        Write-Host "o reiniciá con -Demo para cargar datos de ejemplo."
    }
}

& $py -m uvicorn app.main:app --host $Listen --port $Port
