# Sistema de Cupos AMAGGI

App web interna de Originación / Logística de Amaggi Argentina para gestionar **cupos de descarga en puerto** y asignarlos a **contratos de compra**.

- **Contratos (SIGAM):** compra y venta se importan desde dos archivos Excel de SIGAM (columnas en portugués, cantidades en kg → se pasan a tn).
- **Cupos:** siempre se asignan a contratos de compra. Vienen de dos orígenes:
  - **Stock propio (STOP):** cupos con destinatario Amaggi del sistema de turnos STOP (API oficial o archivo).
  - **Contratos de venta:** cupos de terceros que da el comprador (alta manual o archivo). La **terminal es obligatoria**.
- **Clientes (vendedores):** tienen usuario, ven sus contratos de compra (por CUIT), piden cupos y cargan el CTG.
- **Avisos:** al asignar se arma un mail por contrato con un modelo de Carta de Porte (CPE), que se exporta como `.eml` borrador.

Stack: **Python 3.12 + FastAPI + SQLite** (backend) y **HTML/JS/CSS sin build** (frontend SPA con hash routing, `static/app.js`).

## Puesta en marcha (Windows)

```powershell
copy config.env.example config.env   # opcional: si no existe, la app lo crea
.\iniciar.ps1 -Demo                  # primera vez: crea el venv, instala dependencias y carga datos demo
.\iniciar.ps1                        # siguientes veces
```

Abrir http://localhost:8000 · Documentación de la API: http://localhost:8000/docs

Usuarios demo (contraseña `demo1234`, **solo para desarrollo**): `admin@demo.local`, `operador@demo.local`, `agro.sur@demo.local`, `campos.norte@demo.local`.

- El entorno virtual se crea en `%USERPROFILE%\.venvs\cupos` (ruta corta a propósito: pip falla con rutas largas en Windows sin *long paths*).
- La base queda en `data/cupos.db` (variable `CUPOS_DB` para otra ruta). Al arrancar, `db.init_db()` crea el esquema y aplica las migraciones.
- `abrir-cupos.ps1`: levanta el servidor si no está corriendo y abre el navegador (lo usa el acceso directo del escritorio).
- Base real sin datos demo: `python -m app.seed --admin tu@email.com --password "ClaveSegura123"`.

En Linux/Mac: `python -m venv .venv && .venv/bin/pip install -r requirements.txt && .venv/bin/python -m app.seed --demo && .venv/bin/uvicorn app.main:app`.

## Configuración (`config.env`)

| Variable | Uso |
|---|---|
| `AMAGGI_CUIT` | CUIT de Amaggi para reconocer los cupos con destinatario Amaggi en STOP |
| `STOP_MODO` | `desactivado` · `simulado` (simulador propio) · `pruebas` · `produccion` |
| `STOP_SECRET_KEY` | Clave de la API de STOP |
| `STOP_SYNC_MINUTOS` | Sincronización automática con STOP (límite de STOP: 48 consultas/día) |
| `SIGAM_COMPRA_API_URL` / `_EXPORT_PATH`, `SIGAM_VENTA_…` | Conectores para sincronizar SIGAM (ver `app/connectors.py`) |
| `CUPOS_DB` | Ruta de la base SQLite |

`config.env` no se versiona (puede tener claves). Las variables de entorno del sistema tienen prioridad.

## Pantallas

| Menú | Qué hace |
|---|---|
| **Tablero** | Por destino (UPRIVER, TLP, BUENOS AIRES, NECOCHEA, BAHIA BLANCA): disponibles de stock propio y de contratos de venta, asignados, asignados sin activar (sin CTG) y solicitudes abiertas. Filtro por producto y por día/semana. Cada destino se despliega por terminal. |
| **Grilla** | Vista principal de asignación: contratos de compra × días (L–D), un producto por vez, con filtros de destino, terminal, origen y contrato de venta. Se cargan cantidades por día y se asigna (todo o nada). |
| **Asignar por contrato** | Misma lógica en grilla pero partiendo de la búsqueda de contratos (todos los productos); cada contrato toma cupos de su producto y su zona. "Elegir códigos" permite asignar cupos puntuales. |
| **Listado Códigos** | Todos los cupos con filtros (estado, fechas, destino, terminal, producto); liberar, anular, cargar CTG, historial. |
| **Solicitudes de clientes** | Aprobar (total/parcial) o rechazar pedidos de cupos. |
| **Trazabilidad** | Historial de cada cupo (alta, asignación, liberación, CTG, uso) y export CSV. |
| **Contratos** | Contratos SIGAM de compra y venta con saldo. |
| **Envíos a clientes / Contactos / Modelos de CPE** | Bandeja de avisos por mail, mails por empresa/corredor y modelos de Carta de Porte con `{{variables}}`. |
| **Importaciones / Puertos / Usuarios / Auditoría** | Carga de archivos y sincronización, catálogo de terminales por zona, usuarios y log de acciones. |

Portal del cliente: **Mis contratos**, **Mis solicitudes**, **Mis cupos**.

## Reglas de negocio principales

- **Zonas** (`app/zonas.py`): los destinos se agrupan (UPRIVER = Rosario, San Lorenzo, Timbúes, Gral. San Martín, Arroyo Seco, Ramallo…; NECOCHEA = Necochea/Quequén; TLP = La Plata/Ensenada). El nombre original queda como terminal del cupo o `lugar_detalle` del contrato.
- **Terminal del cupo:** `puerto` (informada por STOP o en la carga) o `puerto_asignado` (elegida al asignar; se borra al liberar). Los cupos sin terminal sirven para cualquier terminal de su zona.
- **Saldo de un contrato de compra** = toneladas − entregadas (SIGAM) − tn de cupos ASIGNADOS. Un cupo ≈ 30 tn (`TONELADAS_POR_CUPO`).
- **Estado de entrega** (colores): vigente si hoy está entre *Fec. Entrega* y *Fec. Vto. Entrega*; vencido si ya pasó; fuera de entrega si todavía no empieza.
- **Estados del cupo:** DISPONIBLE → ASIGNADO → UTILIZADO; DISPONIBLE → ANULADO; ASIGNADO → liberar → DISPONIBLE. Un DISPONIBLE con fecha pasada se muestra VENCIDO.
- **CTG:** 12 dígitos, único por cupo. STOP lo completa solo para el stock propio; para cupos de venta se carga a mano (operador o cliente).
- **Corredor vacío** en SIGAM = operación **Directo**.
- **Solicitudes:** PENDIENTE → PARCIAL → APROBADA, o RECHAZADA / CANCELADA.
- Todo cambio de cupo queda en `cupos_historial` y las acciones en `auditoria`.

## Integraciones

- **STOP** (`app/stop.py`): API v1.1.0 para Corredores y Acopiadores (token de 2 minutos, ventana hoy−2…hoy+5, máx. 48 consultas/día). Da de alta los cupos con destinatario Amaggi y actualiza CTG/estado. Modo `simulado` para desarrollo.
- **SIGAM** (`app/connectors.py`): hoy por archivo (import manual). Está previsto conectar la API de SIGAM (`cloudqas.amaggi.com.br/tarnet/v1/…`) desde el backend.

## Estructura

```
app/main.py        rutas de la API (FastAPI)
app/services.py    saldos, asignación (grilla y por contrato), liberar, CTG, solicitudes
app/importers.py   lectura de CSV/XLSX, alias de columnas SIGAM/STOP, importación
app/db.py          esquema SQLite y migraciones (se aplican al arrancar)
app/stop.py        cliente de la API de STOP, simulador y sincronización automática
app/avisos.py      bandeja de avisos, destinatarios y armado del mail / .eml
app/zonas.py       agrupación de destinos en zonas
app/connectors.py  sincronización por API o archivo (SIGAM)
app/security.py    contraseñas (scrypt) y sesiones por cookie
app/config.py      lectura de config.env
app/seed.py        administrador inicial y datos demo
static/            frontend (index.html, app.js, styles.css, marca/)
ejemplos/          archivos de ejemplo para importar
```

## Pendientes conocidos

- **CUIT de la contraparte:** el export de SIGAM no lo trae, por eso los usuarios cliente todavía no ven sus contratos. A definir: vincular por razón social al crear el usuario o sumar el CUIT al export/API de SIGAM.
- **API de SIGAM:** reemplazar la importación manual por sincronización.
- **Producción:** servidor interno, HTTPS, SSO corporativo, cambiar las claves demo, backups de la base y endurecimiento de seguridad.
- **Mails:** hoy se exportan como `.eml`; falta el envío automático (M365/SMTP).
- No hay tests automatizados todavía.
