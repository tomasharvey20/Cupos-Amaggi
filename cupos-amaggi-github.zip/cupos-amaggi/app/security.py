"""Contraseñas (scrypt) y sesiones por cookie."""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta

from fastapi import Depends, HTTPException, Request

from .db import get_conn

SESSION_COOKIE = "cupos_sesion"
SESSION_HOURS = 12


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, salt_hex, digest_hex = stored.split("$")
    except ValueError:
        return False
    digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
    return hmac.compare_digest(digest.hex(), digest_hex)


def create_session(conn, usuario_id: int) -> str:
    token = secrets.token_urlsafe(32)
    expira = (datetime.now() + timedelta(hours=SESSION_HOURS)).isoformat(timespec="seconds")
    conn.execute("DELETE FROM sesiones WHERE expira < ?", (datetime.now().isoformat(timespec="seconds"),))
    conn.execute("INSERT INTO sesiones (token, usuario_id, expira) VALUES (?,?,?)", (token, usuario_id, expira))
    return token


def current_user(request: Request, conn=Depends(get_conn)) -> dict:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        raise HTTPException(401, "No autenticado")
    row = conn.execute(
        """SELECT u.id, u.email, u.nombre, u.rol, u.cuit, u.activo, s.expira
           FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id WHERE s.token = ?""",
        (token,),
    ).fetchone()
    if not row or not row["activo"] or row["expira"] < datetime.now().isoformat(timespec="seconds"):
        raise HTTPException(401, "Sesión vencida")
    return dict(row)


def require_roles(*roles):
    def dep(user=Depends(current_user)):
        if user["rol"] not in roles:
            raise HTTPException(403, "Sin permiso para esta acción")
        return user
    return dep


staff = require_roles("ADMIN", "OPERADOR")
admin = require_roles("ADMIN")
