"""Lectura de archivos CSV/XLSX e importación de cupos (STOP, VENTA) y contratos (SIGAM).

Los encabezados se normalizan (minúsculas, sin acentos, espacios -> "_") y se mapean
por alias, así el mismo importador acepta pequeñas variaciones de los exports.
Si el formato real de STOP o SIGAM usa otros nombres de columna, alcanza con
agregarlos en ALIASES.
"""
import csv
import io
import json
import os
import re
import unicodedata
from datetime import date, datetime

from . import zonas
from .db import audit, historial, transaction

AMAGGI_CUIT = re.sub(r"\D", "", os.environ.get("AMAGGI_CUIT", ""))
AMAGGI_NOMBRE = os.environ.get("AMAGGI_NOMBRE", "AMAGGI").upper()
TONELADAS_POR_CUPO = float(os.environ.get("TONELADAS_POR_CUPO", "30"))

# Se aceptan nombres en castellano y en portugués (SIGAM exporta en portugués).
# El orden importa: se usa la primera columna presente con valor.
ALIASES = {
    "codigo": ["codigo", "codigo_cupo", "cupo", "nro_cupo", "numero_cupo", "turno", "codigo_turno"],
    "fecha": ["fecha", "fecha_cupo", "fecha_turno", "fecha_descarga"],
    "destino": ["destino", "zona", "terminal", "planta", "puerto", "planta_destino", "lugar_descarga"],
    # Puerto/terminal específico dentro del destino (si el archivo trae ambas columnas, ej. Destino=UPRIVER y Terminal=TIMBUES)
    "puerto": ["puerto_especifico", "puerto", "terminal", "planta", "terminal_descarga", "planta_descarga"],
    "producto": ["producto", "produto", "grano", "especie", "cereal", "mercadoria"],
    "cosecha": ["safra", "cosecha", "campana"],
    "toneladas": ["toneladas", "tn", "cantidad_tn"],
    "destinatario_cuit": ["destinatario_cuit", "cuit_destinatario", "cuit_dest"],
    "destinatario_nombre": ["destinatario", "destinatario_nombre", "razon_social_destinatario"],
    "contrato_venta": ["contrato_venta", "nro_contrato_venta", "contrato", "numero_contrato"],
    "observaciones": ["observaciones", "obs", "comentario"],
    # CTG de la Carta de Porte Electrónica (lo informa STOP para los cupos con destinatario Amaggi)
    "ctg": ["ctg", "nro_ctg", "numero_ctg", "codigo_ctg", "ctg_numero", "cod_trazabilidad"],
    # SIGAM
    "numero": ["numero", "nr_contrato", "nro_contrato", "contrato", "numero_contrato", "num_contrato"],
    "tipo": ["tipo", "tipo_contrato"],
    "corredor": ["corredor", "broker", "corretor"],
    "operacion": ["operacion", "operacao", "tipo_operacion"],
    # Cantidades en kilos (se convierten a toneladas). SIGAM informa en kg, también en el export
    # en portugués (qtde_vendido = qtde_original ± amp_red).
    # Export real de SIGAM: kg_pact (N), kg_aplicadas (Q), kg_pend_ent (R)
    "kg": ["kg_pact", "kg_pactados", "kilos_pactados", "kg_contratados", "kg", "kilos_estimados",
           "qtde_vendido", "qtde_comprado", "qtde_original", "quantidade", "qtde"],
    "kg_entregados": ["kg_aplicadas", "kg_aplicados", "kilos_aplicados", "kg_entregados", "kilos_entregados",
                      "qtde_entregue", "qtde_embarcada", "qtde_recebida", "qtde_aplicada"],
    "kg_pendientes": ["kg_pend_ent", "kg_pendiente_entrega", "kg_pendientes", "kilos_pendientes", "kg_pendiente"],
    "contraparte_cuit": ["contraparte_cuit", "cuit", "cuit_contraparte", "cuit_vendedor", "cuit_comprador",
                         "cuit_cliente", "cnpj", "cpf_cnpj", "cnpj_cpf", "documento"],
    "contraparte_nombre": ["contraparte", "contraparte_nombre", "razon_social", "vendedor", "comprador",
                           "cliente", "fornecedor", "produtor", "parceiro", "razao_social", "nome_cliente"],
    "toneladas_entregadas": ["toneladas_entregadas", "entregado", "tn_entregadas", "cumplido"],
    # SIGAM compras lo trae como "Fec. Entrega" (inicio del período); ventas como "Fec. Inicio Entrega"
    "fecha_desde": ["fecha_desde", "entrega_desde", "desde", "fec_inicio_entrega", "fecha_inicio_entrega", "inicio_entrega",
                    "dt_inicio_entrega", "data_inicio_entrega", "fec_entrega", "fecha_entrega", "data_entrega"],
    "fecha_hasta": ["fecha_hasta", "entrega_hasta", "hasta", "fec_vto_entrega", "fecha_vencimiento_entrega", "vencimiento_entrega",
                    "fecha_fin_entrega", "dt_final_entrega", "dt_fim_entrega", "data_final_entrega", "final_entrega"],
    "lugar_entrega": ["lugar_entrega", "destino", "puerto", "procedencia", "local_entrega", "porto"],
    # "status" de SIGAM no se usa: sus valores no son VIGENTE/CERRADO y dejarían contratos sin poder asignar.
    "estado": ["estado"],
}

# Nombres de producto unificados: los cupos de STOP vienen en castellano y SIGAM en portugués;
# si no coinciden, un cupo no se puede asignar al contrato.
# Se compara por el comienzo del nombre, porque SIGAM agrega descripción y NCM
# (ej. "MILHO EM GRAOS NCM 1005.90.10"). Los más específicos van primero.
PRODUCTOS = [
    ("MILHO", "MAIZ"), ("MAIZ", "MAIZ"),
    ("SOJA", "SOJA"), ("POROTO_DE_SOJA", "SOJA"),
    ("TRIGO", "TRIGO"),
    ("GIRASSOL_OLEICO", "GIRASOL OLEICO"), ("GIRASSOL_ALTO_OLEICO", "GIRASOL OLEICO"),
    ("GIRASOL_ALTO_OLEICO", "GIRASOL OLEICO"), ("GIRASOL_OLEICO", "GIRASOL OLEICO"),
    ("GIRASSOL", "GIRASOL"), ("GIRASOL", "GIRASOL"),
    ("SORGO", "SORGO"),
    ("CEVADA_FORRAJEIRA", "CEBADA FORRAJERA"), ("CEBADA_FORRAJERA", "CEBADA FORRAJERA"),
    ("CEVADA", "CEBADA"), ("CEBADA", "CEBADA"),
    ("ALGODAO", "ALGODON"), ("ALGODON", "ALGODON"),
]
# Productos que operamos: aparecen siempre en los filtros, tengan o no cupos cargados
PRODUCTOS_CATALOGO = ["SOJA", "MAIZ", "TRIGO", "SORGO", "GIRASOL", "GIRASOL OLEICO", "CEBADA FORRAJERA"]


def catalogo_productos(*extra) -> list[str]:
    """Catálogo + cualquier otro producto que aparezca en los datos (en ese orden)."""
    out = list(PRODUCTOS_CATALOGO)
    for lista in extra:
        out += sorted(p for p in lista if p and p not in out)
    return out


def norm_producto(v) -> str:
    key = _norm(v).upper()
    for prefijo, nombre in PRODUCTOS:
        if key == prefijo or key.startswith(prefijo + "_"):
            return nombre
    return str(v).strip().upper()


class ImportError_(Exception):
    pass


def _norm(s) -> str:
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "_", s.strip().lower()).strip("_")


def cuit_digits(v) -> str:
    return re.sub(r"\D", "", str(v or ""))


def parse_date(v) -> str | None:
    if v in (None, ""):
        return None
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%Y/%m/%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(s[:10] if fmt.startswith("%Y") else s, fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError(f"fecha inválida '{s}'")


def separar_codigos(texto: str) -> list[str]:
    """'A; B;C;' (o uno por línea) -> ['A','B','C'] sin vacíos ni repetidos, en el orden pegado."""
    vistos = []
    for c in re.split(r"[;\n\r\t]+", texto or ""):
        c = c.strip()
        if c and c not in vistos:
            vistos.append(c)
    return vistos


def fecha_de_codigo(codigo: str) -> str | None:
    """Los códigos de cupo empiezan con la fecha: 20261106082286 -> 2026-11-06.
    Solo se acepta si es una fecha válida a menos de un año de hoy."""
    m = re.match(r"(\d{4})(\d{2})(\d{2})\d*$", codigo.strip())
    if not m:
        return None
    try:
        d = date(int(m[1]), int(m[2]), int(m[3]))
    except ValueError:
        return None
    return d.isoformat() if abs((d - date.today()).days) <= 366 else None


def parse_num(v, default=0.0) -> float:
    if v in (None, ""):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "")
    if "," in s and "." in s:          # 1.234,56 -> 1234.56
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    elif s.count(".") > 1:              # 1.234.567 -> 1234567
        s = s.replace(".", "")
    return float(s)


def read_table(filename: str, content: bytes) -> list[dict]:
    """Devuelve filas como dicts con claves normalizadas."""
    name = (filename or "").lower()
    if name.endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        ws = wb.active
        raw = [list(r) for r in ws.iter_rows(values_only=True)]
    elif name.endswith((".csv", ".txt")):
        for enc in ("utf-8-sig", "latin-1"):
            try:
                text = content.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        first = text.splitlines()[0] if text else ""
        delim = ";" if first.count(";") >= first.count(",") else ","
        raw = list(csv.reader(io.StringIO(text), delimiter=delim))
    else:
        raise ImportError_("Formato no soportado. Usá .csv o .xlsx")

    vacio = lambda c: c is None or (isinstance(c, str) and not c.strip())
    raw = [r for r in raw if r is not None]
    # Los exports suelen traer filas de título antes del encabezado: se toma como encabezado
    # la primera fila (de las 15 primeras) que tenga al menos el 60% de las columnas con texto.
    ancho = max((sum(not vacio(c) for c in r) for r in raw[:15]), default=0)
    h_idx = next((i for i, r in enumerate(raw[:15])
                  if sum(isinstance(c, str) and not vacio(c) for c in r) >= max(2, 0.6 * ancho)), 0)
    headers = [_norm(h) for h in (raw[h_idx] if raw else [])]
    data = []
    for n, r in enumerate(raw[h_idx + 1:], start=h_idx + 2):
        if any(not vacio(c) for c in r):
            d = dict(zip(headers, r))
            d["__fila__"] = n
            data.append(d)
    if not data:
        raise ImportError_("El archivo no tiene filas de datos")
    return data


def columnas(filas: list[dict]) -> list[str]:
    return [k for k in filas[0] if k and k != "__fila__"] if filas else []


def _tiene(cols: list[str], field: str) -> bool:
    return any(a in cols for a in ALIASES.get(field, [field]))


def validar_columnas(filas: list[dict], requeridas: list[str], clase: str) -> None:
    """Corta la importación antes de empezar si al archivo le faltan columnas obligatorias,
    y si parece ser de otro tipo, dice en qué tarjeta subirlo."""
    cols = columnas(filas)
    faltan = [f for f in requeridas if not _tiene(cols, f)]
    if not faltan:
        return
    nombres = {"codigo": "Código de cupo", "fecha": "Fecha", "destino": "Destino/Terminal", "producto": "Producto",
               "contrato_venta": "Contrato de venta", "numero": "Nro de contrato", "puerto": "Terminal"}
    msg = f"Al archivo le faltan columnas obligatorias: {', '.join(nombres.get(f, f) for f in faltan)}."
    es_contratos = not _tiene(cols, "codigo") and (_tiene(cols, "numero") or _tiene(cols, "contraparte_nombre"))
    es_cupos = _tiene(cols, "codigo") and _tiene(cols, "fecha")
    if clase == "cupos" and es_contratos:
        msg += " Parece un archivo de CONTRATOS: subilo en la tarjeta «Contratos de compra» o «Contratos de venta»."
    elif clase == "contratos" and es_cupos:
        msg += " Parece un archivo de CUPOS: subilo en la tarjeta de cupos STOP o de venta."
    msg += f" Columnas encontradas: {', '.join(cols[:80]) or 'ninguna'}."
    raise ImportError_(msg)


def _pick(row: dict, field: str):
    for alias in ALIASES.get(field, [field]):
        if alias in row and row[alias] not in (None, ""):
            v = row[alias]
            return v.strip() if isinstance(v, str) else v
    return None


def _pick_col(row: dict, field: str, excluir: str | None = None):
    """Como _pick pero devuelve también la columna usada, salteando `excluir`."""
    for alias in ALIASES.get(field, [field]):
        if alias != excluir and alias in row and row[alias] not in (None, ""):
            v = row[alias]
            return alias, (v.strip() if isinstance(v, str) else v)
    return None, None


def asegurar_puerto(conn, zona: str, nombre: str) -> str:
    """Agrega el puerto al catálogo de la zona si no existe (los que vienen en los archivos)."""
    nombre = str(nombre).strip().upper()
    zona = zonas.normalizar(zona)[0]
    conn.execute("INSERT OR IGNORE INTO puertos (zona, nombre) VALUES (?, ?)", (zona, nombre))
    return nombre


def _registrar(conn, tipo, archivo, total, ins, act, omit, detalle, user_id) -> int:
    cur = conn.execute(
        """INSERT INTO importaciones (tipo, archivo, total, insertados, actualizados, omitidos, detalle, usuario_id)
           VALUES (?,?,?,?,?,?,?,?)""",
        (tipo, archivo, total, ins, act, omit, json.dumps(detalle[:200], ensure_ascii=False), user_id),
    )
    return cur.lastrowid


def _es_amaggi(cuit: str, nombre: str) -> bool:
    if AMAGGI_CUIT and cuit:
        return cuit == AMAGGI_CUIT
    return AMAGGI_NOMBRE in (nombre or "").upper()


def importar_cupos(conn, filas: list[dict], origen: str, archivo: str, user_id: int) -> dict:
    """origen: 'STOP' (solo destinatario Amaggi) o 'VENTA' (requiere contrato de venta)."""
    assert origen in ("STOP", "VENTA")
    # Cupos de venta: la terminal es obligatoria (al asignar se elige la terminal según disponibilidad)
    validar_columnas(filas, ["codigo", "fecha", "destino", "producto"] + (["contrato_venta", "puerto"] if origen == "VENTA" else []), "cupos")
    ins = act = omit = 0
    detalle = []
    with transaction(conn):
        imp_id = _registrar(conn, origen, archivo, len(filas), 0, 0, 0, [], user_id)
        for n, f in enumerate(filas, start=2):
            i = f.get("__fila__", n)  # número de fila real en el archivo
            try:
                codigo = str(_pick(f, "codigo") or "").strip()
                if not codigo:
                    raise ValueError("falta código de cupo")
                fecha = parse_date(_pick(f, "fecha"))
                if not fecha:
                    raise ValueError("falta fecha")
                col_dest, destino = _pick_col(f, "destino")
                producto = _pick(f, "producto")
                if not destino or not producto:
                    raise ValueError("falta destino o producto")
                # Destinos agrupados en una zona (ej. TIMBUES -> UPRIVER): el original pasa a ser el puerto
                destino, destino_original = zonas.normalizar(destino)
                _, puerto = _pick_col(f, "puerto", excluir=col_dest)
                if origen == "VENTA" and not puerto:
                    raise ValueError("falta la terminal (obligatoria en cupos de venta)")
                puerto = puerto or destino_original
                puerto = asegurar_puerto(conn, destino, puerto) if puerto else None
                dest_cuit = cuit_digits(_pick(f, "destinatario_cuit"))
                dest_nombre = _pick(f, "destinatario_nombre")
                contrato_venta_id = None
                if origen == "STOP":
                    if not _es_amaggi(dest_cuit, dest_nombre):
                        raise ValueError(f"destinatario no es Amaggi ({dest_nombre or dest_cuit or 'vacío'})")
                else:
                    nro = _pick(f, "contrato_venta")
                    if not nro:
                        raise ValueError("falta contrato de venta")
                    cv = conn.execute(
                        "SELECT id, contraparte_cuit, contraparte_nombre, producto FROM contratos WHERE tipo='VENTA' AND numero=?",
                        (_texto(nro),),
                    ).fetchone()
                    if not cv:
                        raise ValueError(f"contrato de venta {nro} no existe (importá SIGAM primero)")
                    contrato_venta_id = cv["id"]
                    dest_cuit = dest_cuit or cv["contraparte_cuit"]
                    dest_nombre = dest_nombre or cv["contraparte_nombre"]
                existe = conn.execute("SELECT id, ctg FROM cupos WHERE codigo=?", (codigo,)).fetchone()
                ctg = _ctg(conn, _pick(f, "ctg"), existe["id"] if existe else None)
                if existe:
                    # Re-importación / sincronización de STOP: si ahora el cupo trae CTG, se completa
                    if ctg and existe["ctg"] != ctg:
                        conn.execute("UPDATE cupos SET ctg=? WHERE id=?", (ctg, existe["id"]))
                        historial(conn, [existe["id"]], "CTG", user_id, f"CTG {ctg} · {archivo}")
                        act += 1
                        continue
                    raise ValueError(f"cupo {codigo} ya existe")
                cur = conn.execute(
                    """INSERT INTO cupos (codigo, fecha, destino, puerto, producto, cosecha, toneladas, origen,
                       destinatario_cuit, destinatario_nombre, contrato_venta_id, observaciones, importacion_id, ctg)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (codigo, fecha, destino, puerto, norm_producto(producto), _pick(f, "cosecha"),
                     parse_num(_pick(f, "toneladas"), TONELADAS_POR_CUPO), origen, dest_cuit, dest_nombre,
                     contrato_venta_id, _pick(f, "observaciones"), imp_id, ctg),
                )
                historial(conn, [cur.lastrowid], "ALTA", user_id, f"{'Cupo STOP' if origen == 'STOP' else 'Cupo de venta'} · {archivo}")
                ins += 1
            except (ValueError, TypeError) as e:
                omit += 1
                detalle.append({"fila": i, "motivo": str(e)})
        conn.execute(
            "UPDATE importaciones SET insertados=?, actualizados=?, omitidos=?, detalle=? WHERE id=?",
            (ins, act, omit, json.dumps(detalle[:200], ensure_ascii=False), imp_id),
        )
        audit(conn, user_id, f"IMPORTAR_CUPOS_{origen}", "importacion", imp_id,
              f"{ins} insertados, {act} con CTG actualizado, {omit} omitidos")
    return {"importacion_id": imp_id, "total": len(filas), "insertados": ins, "actualizados": act,
            "omitidos": omit, "detalle": detalle}


def _ctg(conn, valor, cupo_id=None) -> str | None:
    """CTG (Código de Trazabilidad de Granos): 12 dígitos y no repetido en otro cupo."""
    if valor in (None, ""):
        return None
    ctg = re.sub(r"\D", "", _texto(valor) or "")
    if len(ctg) != 12:
        raise ValueError(f"CTG inválido '{valor}' (debe tener 12 dígitos)")
    otro = conn.execute("SELECT codigo FROM cupos WHERE ctg=? AND id <> COALESCE(?, -1)", (ctg, cupo_id)).fetchone()
    if otro:
        raise ValueError(f"CTG {ctg} ya está asociado al cupo {otro[0]}")
    return ctg


def _texto(v):
    """Valores que Excel guarda como número pero son códigos (ej. operación 1234.0 -> '1234')."""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return None if v is None else str(v).strip()


def _cantidades(f: dict) -> tuple[float, float]:
    """Toneladas del contrato y toneladas entregadas.
    Acepta toneladas directas o kilos (Kg Pactados / Kg Aplicados / Kg Pendiente entrega)."""
    if _pick(f, "toneladas") is not None:
        tn = parse_num(_pick(f, "toneladas"))
        entregadas = parse_num(_pick(f, "toneladas_entregadas"))
        return tn, entregadas
    tn = parse_num(_pick(f, "kg")) / 1000
    if _pick(f, "kg_entregados") is not None:
        entregadas = parse_num(_pick(f, "kg_entregados")) / 1000
    elif _pick(f, "kg_pendientes") is not None:
        entregadas = tn - parse_num(_pick(f, "kg_pendientes")) / 1000
    else:
        entregadas = parse_num(_pick(f, "toneladas_entregadas"))
    return tn, max(0.0, entregadas)


def importar_contratos(conn, filas: list[dict], tipo: str, archivo: str, user_id: int) -> dict:
    """Alta/actualización de contratos SIGAM por (tipo, numero).

    SIGAM exporta compras y ventas en archivos separados: el tipo lo define la importación,
    no una columna del archivo. Si el archivo trae una columna "tipo" que no coincide, la fila se omite
    (evita cargar el archivo de ventas como compras por error)."""
    assert tipo in ("COMPRA", "VENTA")
    validar_columnas(filas, ["numero", "producto"], "contratos")
    cols = columnas(filas)
    if not (_tiene(cols, "toneladas") or _tiene(cols, "kg")):
        raise ImportError_("Al archivo le falta la cantidad del contrato (Kg Pactados o Toneladas). "
                           f"Columnas encontradas: {', '.join(cols[:25])}.")
    ins = act = omit = 0
    detalle = []
    with transaction(conn):
        imp_id = _registrar(conn, f"SIGAM_{tipo}", archivo, len(filas), 0, 0, 0, [], user_id)
        for n, f in enumerate(filas, start=2):
            i = f.get("__fila__", n)
            try:
                numero = _texto(_pick(f, "numero")) or ""
                if not numero:
                    raise ValueError("falta número de contrato")
                tipo_fila = _norm(_pick(f, "tipo")).upper()
                tipo_fila = {"C": "COMPRA", "V": "VENTA"}.get(tipo_fila, tipo_fila)
                if tipo_fila in ("COMPRA", "VENTA") and tipo_fila != tipo:
                    raise ValueError(f"la fila es de {tipo_fila} y estás importando contratos de {tipo}")
                producto = _pick(f, "producto")
                if not producto:
                    raise ValueError("falta producto")
                tn, tn_entregadas = _cantidades(f)
                vals = dict(
                    contraparte_cuit=cuit_digits(_pick(f, "contraparte_cuit")),
                    contraparte_nombre=_pick(f, "contraparte_nombre"),
                    corredor=_pick(f, "corredor"),
                    operacion=_texto(_pick(f, "operacion")),
                    producto=norm_producto(producto),
                    cosecha=_texto(_pick(f, "cosecha")),
                    toneladas=tn,
                    toneladas_entregadas=tn_entregadas,
                    fecha_desde=parse_date(_pick(f, "fecha_desde")),
                    fecha_hasta=parse_date(_pick(f, "fecha_hasta")),
                    lugar_entrega=zonas.normalizar(_pick(f, "lugar_entrega"))[0] or None,
                    lugar_detalle=zonas.normalizar(_pick(f, "lugar_entrega"))[1],
                    estado=str(_pick(f, "estado") or "VIGENTE").upper(),
                )
                existe = conn.execute("SELECT id FROM contratos WHERE tipo=? AND numero=?", (tipo, numero)).fetchone()
                if existe:
                    sets = ", ".join(f"{k}=?" for k in vals)
                    conn.execute(f"UPDATE contratos SET {sets}, actualizado=datetime('now','localtime') WHERE id=?",
                                 (*vals.values(), existe["id"]))
                    act += 1
                else:
                    cols = ", ".join(["numero", "tipo", *vals])
                    conn.execute(f"INSERT INTO contratos ({cols}) VALUES ({', '.join('?' * (len(vals) + 2))})",
                                 (numero, tipo, *vals.values()))
                    ins += 1
            except (ValueError, TypeError) as e:
                omit += 1
                detalle.append({"fila": i, "motivo": str(e)})
        conn.execute(
            "UPDATE importaciones SET insertados=?, actualizados=?, omitidos=?, detalle=? WHERE id=?",
            (ins, act, omit, json.dumps(detalle[:200], ensure_ascii=False), imp_id),
        )
        audit(conn, user_id, f"IMPORTAR_SIGAM_{tipo}", "importacion", imp_id, f"{ins} nuevos, {act} actualizados, {omit} omitidos")
    return {"importacion_id": imp_id, "total": len(filas), "insertados": ins, "actualizados": act,
            "omitidos": omit, "detalle": detalle}
