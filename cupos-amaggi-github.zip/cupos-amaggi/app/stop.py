"""Integración con STOP (Sistema de Turnos, Ministerio de Transporte) — API REST v1.1.0
para CORREDORES y ACOPIADORES.

Recursos usados (todos GET, token como parámetro de la URL):
  /v1.1.0/auths/<secretKey>                              -> token (vale 2 minutos; 1 hora en pruebas)
  /v1.1.0/misturnosactivos/<token>/<desde>/<hasta>        -> turnos donde figura el CUIT de Amaggi
  /v1.1.0/terminales/<token>                              -> terminales (id, descripción, localidad, provincia)
  /v1.1.0/especies/<token>                                -> especies / granos
Límites: fecha desde >= hoy - 2 días, fecha hasta <= hoy + 5 días, 48 consultas de turnos por día.

Modos (STOP_MODO en config.env): desactivado | simulado | pruebas | produccion.
El modo "simulado" no se conecta a STOP: genera turnos de ejemplo con el formato del instructivo,
para probar el circuito sin clave. El entorno de pruebas de STOP ya no ofrece respuestas simuladas.
"""
import json
import logging
import os
import random
import re
import threading
import time
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta

from . import db, importers, zonas
from .db import historial, rows, transaction

log = logging.getLogger("cupos.stop")

URLS = {"pruebas": "https://demo.ssta.gob.ar/turnos/v1.1.0", "produccion": "https://www.ssta.gob.ar/turnos/v1.1.0"}
LIMITE_DIARIO = 48          # consultas de turnos por día que permite STOP
RESERVA = 2                 # se dejan 2 libres por las dudas
ESTADOS = {1: "SIN_CTG", 2: "ACTIVADO", 3: "DESCARGADO", 4: "BORRADO", 5: "ARRIBADO", 6: "RECHAZADO"}

_lock = threading.Lock()    # una sincronización a la vez


class StopError(Exception):
    pass


def modo() -> str:
    return (os.environ.get("STOP_MODO") or "desactivado").strip().lower()


CUIT_SIMULADO = "30700000006"  # CUIT ficticio que usa el simulador si no se configuró el real


def amaggi_cuit() -> str:
    cuit = re.sub(r"\D", "", os.environ.get("AMAGGI_CUIT", ""))
    return cuit or (CUIT_SIMULADO if modo() == "simulado" else "")


def configuracion() -> dict:
    m = modo()
    falta = []
    if m in ("pruebas", "produccion") and not os.environ.get("STOP_SECRET_KEY"):
        falta.append("STOP_SECRET_KEY")
    if m != "desactivado" and len(amaggi_cuit()) != 11:
        falta.append("AMAGGI_CUIT")
    return {"modo": m, "url": URLS.get(m), "faltan": falta, "lista": m != "desactivado" and not falta,
            "minutos": int(os.environ.get("STOP_SYNC_MINUTOS") or 0)}


# ---------------------------------------------------------------- llamadas HTTP
def _get(url: str, recurso: str, conn) -> object:
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "Cupos-AMAGGI/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            cuerpo = r.read().decode("utf-8", "replace")
    except (urllib.error.URLError, TimeoutError) as e:
        _registrar(conn, recurso, False, f"sin conexión: {e}")
        raise StopError(f"No se pudo conectar con STOP ({e})")
    try:
        data = json.loads(cuerpo)
    except json.JSONDecodeError:
        _registrar(conn, recurso, False, "respuesta no JSON")
        raise StopError("STOP respondió algo que no es JSON (¿cambió la dirección de la API?)")
    if isinstance(data, dict) and data.get("isError"):
        err = data.get("data") or {}
        msg = err.get("userMessage") or err.get("developerMessage") or "error"
        _registrar(conn, recurso, False, f"{err.get('errorCode')}: {msg}")
        raise StopError(f"STOP: {msg} (código {err.get('errorCode')})")
    _registrar(conn, recurso, True, None)
    return data.get("data") if isinstance(data, dict) and "data" in data else data


def _registrar(conn, recurso, ok, detalle):
    conn.execute("INSERT INTO stop_consultas (recurso, ok, detalle) VALUES (?,?,?)", (recurso, int(ok), detalle))


def consultas_hoy(conn) -> int:
    return conn.execute("SELECT COUNT(*) FROM stop_consultas WHERE fecha = date('now','localtime') "
                        "AND recurso = 'misturnosactivos'").fetchone()[0]


class Cliente:
    def __init__(self, conn):
        self.conn = conn
        self.modo = modo()
        self.base = URLS.get(self.modo)
        self._token, self._token_hasta = None, 0.0

    def token(self) -> str:
        if self.modo == "simulado":
            return "SIMULADO"
        if self._token and time.time() < self._token_hasta:
            return self._token
        clave = os.environ.get("STOP_SECRET_KEY", "")
        tok = _get(f"{self.base}/auths/{urllib.request.quote(clave, safe='')}", "auths", self.conn)
        self._token, self._token_hasta = str(tok), time.time() + 100  # vale 2 min: se renueva antes
        return self._token

    def terminales(self) -> list[dict]:
        if self.modo == "simulado":
            _registrar(self.conn, "terminales", True, "simulado")
            return SIMULADOR.terminales()
        return _get(f"{self.base}/terminales/{self.token()}", "terminales", self.conn) or []

    def especies(self) -> list[dict]:
        if self.modo == "simulado":
            _registrar(self.conn, "especies", True, "simulado")
            return SIMULADOR.especies()
        return _get(f"{self.base}/especies/{self.token()}", "especies", self.conn) or []

    def mis_turnos(self, desde: str, hasta: str) -> list[dict]:
        if consultas_hoy(self.conn) >= LIMITE_DIARIO - RESERVA:
            raise StopError(f"Se alcanzó el límite diario de consultas a STOP ({LIMITE_DIARIO - RESERVA}). Mañana se habilita de nuevo.")
        if self.modo == "simulado":
            _registrar(self.conn, "misturnosactivos", True, "simulado")
            return SIMULADOR.mis_turnos(desde, hasta)
        return _get(f"{self.base}/misturnosactivos/{self.token()}/{desde}/{hasta}", "misturnosactivos", self.conn) or []


# ---------------------------------------------------------------- catálogos
def _campo(d: dict, *nombres, defecto=None):
    """STOP no es consistente con mayúsculas en los nombres de campo (Idterminal / idTerminal)."""
    bajos = {k.lower(): v for k, v in d.items()}
    for n in nombres:
        if n.lower() in bajos and bajos[n.lower()] not in (None, ""):
            return bajos[n.lower()]
    return defecto


def actualizar_catalogos(conn, cli: Cliente, forzar=False) -> None:
    """Terminales y especies: una vez por día (no cuentan para el límite de turnos)."""
    ult = conn.execute("SELECT MAX(actualizado) FROM stop_terminales").fetchone()[0]
    if not forzar and ult and ult[:10] == date.today().isoformat():
        return
    for t in cli.terminales():
        tid = _campo(t, "idTerminal", "Idterminal")
        if tid is None:
            continue
        desc = str(_campo(t, "descripcion", "Descipcion", "descipcion", defecto="")).strip()
        loc = str(_campo(t, "nombreLocalidad", "NombreLocalidad", defecto="")).strip()
        prov = str(_campo(t, "nombreProvincia", defecto="")).strip()
        zona = zonas.normalizar(loc)[0] or loc.upper()
        conn.execute(
            """INSERT INTO stop_terminales (id_terminal, descripcion, localidad, provincia, zona, puerto)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(id_terminal) DO UPDATE SET descripcion=excluded.descripcion, localidad=excluded.localidad,
                 provincia=excluded.provincia, actualizado=datetime('now','localtime'),
                 zona=CASE WHEN editado=1 THEN zona ELSE excluded.zona END,
                 puerto=CASE WHEN editado=1 THEN puerto ELSE excluded.puerto END""",
            (int(tid), desc, loc, prov, zona, _puerto_corto(desc)))
    for e in cli.especies():
        cod = _campo(e, "codGrano", "idEspecie", "codigo", "id")
        nombre = str(_campo(e, "descripcion", "nombre", "grano", defecto="")).strip()
        if cod is None:
            continue
        conn.execute(
            """INSERT INTO stop_especies (cod_grano, nombre, producto) VALUES (?,?,?)
               ON CONFLICT(cod_grano) DO UPDATE SET nombre=excluded.nombre, producto=excluded.producto,
                 actualizado=datetime('now','localtime')""",
            (int(cod), nombre, importers.norm_producto(nombre) if nombre else None))


def _puerto_corto(desc: str) -> str:
    """'SERVICIOS PORTUARIOS S.A. - Rosario - Terminal VI-VII Elevador de Granos' -> 'SERVICIOS PORTUARIOS S.A. - TERMINAL VI-VII'."""
    partes = [p.strip() for p in desc.split(" - ") if p.strip()]
    if len(partes) >= 3:
        texto = f"{partes[0]} - {' '.join(partes[2].split()[:2])}"
    else:
        texto = desc
    return texto.upper()[:60]


# ---------------------------------------------------------------- sincronización
def sincronizar(conn, usuario_id: int | None = None, origen: str = "manual") -> dict:
    """Trae de STOP los turnos de hoy-2 a hoy+5 donde figura Amaggi y actualiza los cupos.
      * Destinatario Amaggi y no existe en el sistema -> se da de alta como cupo de STOCK PROPIO.
      * Ya existe (por código)                         -> se actualizan CTG, carta de porte y estado STOP.
      * Descargado en STOP y asignado acá              -> pasa a UTILIZADO.
      * Borrado/anulado en STOP y disponible acá       -> pasa a ANULADO.
      * De terceros y no existe acá                    -> queda registrado en stop_turnos (sin cupo)."""
    cfg = configuracion()
    if cfg["modo"] == "desactivado":
        raise StopError("La conexión con STOP está desactivada (STOP_MODO en config.env).")
    if cfg["faltan"]:
        raise StopError("Falta configurar en config.env: " + ", ".join(cfg["faltan"]))
    if not _lock.acquire(blocking=False):
        raise StopError("Ya hay una sincronización con STOP en curso.")
    try:
        cli = Cliente(conn)
        actualizar_catalogos(conn, cli)
        desde = (date.today() - timedelta(days=2)).isoformat()
        hasta = (date.today() + timedelta(days=5)).isoformat()
        turnos = cli.mis_turnos(desde, hasta)
        res = _procesar(conn, turnos, usuario_id)
        res.update(desde=desde, hasta=hasta, modo=cfg["modo"], origen=origen, consultas_hoy=consultas_hoy(conn))
        db.audit(conn, usuario_id, "SYNC_STOP", None, None,
                 f"{origen} · {len(turnos)} turnos · {res['nuevos']} nuevos · {res['actualizados']} actualizados")
        return res
    finally:
        _lock.release()


def _procesar(conn, turnos: list[dict], usuario_id) -> dict:
    cuit_amaggi = amaggi_cuit()
    term = {r["id_terminal"]: r for r in rows(conn.execute("SELECT * FROM stop_terminales"))}
    esp = {r["cod_grano"]: r for r in rows(conn.execute("SELECT * FROM stop_especies"))}
    res = {"recibidos": len(turnos), "nuevos": 0, "actualizados": 0, "utilizados": 0, "anulados": 0,
           "de_terceros": 0, "sin_cambios": 0, "avisos": []}
    with transaction(conn):
        for t in turnos:
            codigo = str(_campo(t, "idCupoTerminal", defecto="")).strip()
            if not codigo:
                continue
            id_term = _campo(t, "idTerminal")
            id_term = int(id_term) if id_term is not None else None
            fecha = str(_campo(t, "fecha", defecto=""))[:10] or None
            id_estado = int(_campo(t, "idCupoEstado", defecto=0) or 0)
            anulado = str(_campo(t, "esAnulado", defecto="N")).upper() == "S"
            estado = "BORRADO" if anulado else ESTADOS.get(id_estado, str(_campo(t, "cupoEstado", defecto="")) or None)
            ctg = re.sub(r"\D", "", str(_campo(t, "ctg", defecto="") or "")) or None
            carta = re.sub(r"\D", "", str(_campo(t, "cartaPorte", defecto="") or "")) or None
            dest = re.sub(r"\D", "", str(_campo(t, "idCuitDestinatario", defecto="") or ""))
            es_amaggi = bool(cuit_amaggi) and dest == cuit_amaggi
            cupo = conn.execute("SELECT * FROM cupos WHERE codigo = ?", (codigo,)).fetchone()

            if not cupo and es_amaggi:
                tinfo = term.get(id_term) or {}
                if tinfo.get("zona") and tinfo.get("puerto"):
                    importers.asegurar_puerto(conn, tinfo["zona"], tinfo["puerto"])
                cod_grano = _campo(t, "codGrano")
                producto = (esp.get(int(cod_grano)) or {}).get("producto") if cod_grano is not None else None
                producto = producto or importers.norm_producto(_campo(t, "grano", defecto="") or "") or "SIN DEFINIR"
                peso = float(_campo(t, "pesoNetoEstimado", defecto=0) or 0)
                cur = conn.execute(
                    """INSERT INTO cupos (codigo, fecha, destino, puerto, producto, cosecha, toneladas, origen,
                       destinatario_cuit, destinatario_nombre, observaciones, ctg, carta_porte, stop_estado,
                       stop_id_terminal, stop_actualizado)
                       VALUES (?,?,?,?,?,?,?, 'STOP', ?, 'AMAGGI', ?, ?, ?, ?, ?, datetime('now','localtime'))""",
                    (codigo, fecha, tinfo.get("zona") or "SIN DEFINIR", tinfo.get("puerto"), producto,
                     _campo(t, "cosecha"), round(peso / 1000, 2) if peso > 0 else importers.TONELADAS_POR_CUPO,
                     dest, "Alta automática desde STOP", _ctg_libre(conn, ctg, None), carta, estado, id_term))
                cupo_id = cur.lastrowid
                historial(conn, [cupo_id], "ALTA", usuario_id, f"Cupo STOP · sincronización ({estado or 's/estado'})")
                res["nuevos"] += 1
            elif cupo:
                cupo_id = cupo["id"]
                cambios, params = [], []
                ctg_nuevo = _ctg_libre(conn, ctg, cupo_id)
                if ctg and not ctg_nuevo:
                    res["avisos"].append(f"Cupo {codigo}: el CTG {ctg} ya está en otro cupo")
                for col, val in (("ctg", ctg_nuevo), ("carta_porte", carta), ("stop_estado", estado), ("stop_id_terminal", id_term)):
                    if val is not None and str(cupo[col] or "") != str(val):
                        cambios.append(f"{col}=?")
                        params.append(val)
                if cambios:
                    conn.execute(f"UPDATE cupos SET {', '.join(cambios)}, stop_actualizado=datetime('now','localtime') "
                                 "WHERE id=?", (*params, cupo_id))
                    if ctg_nuevo and ctg_nuevo != cupo["ctg"]:
                        historial(conn, [cupo_id], "CTG", usuario_id, f"CTG {ctg_nuevo} · STOP")
                    res["actualizados"] += 1
                else:
                    res["sin_cambios"] += 1
                if estado == "DESCARGADO" and cupo["estado"] == "ASIGNADO":
                    conn.execute("UPDATE cupos SET estado='UTILIZADO' WHERE id=?", (cupo_id,))
                    historial(conn, [cupo_id], "UTILIZADO", usuario_id, "Descargado según STOP")
                    res["utilizados"] += 1
                elif estado == "BORRADO" and cupo["estado"] == "DISPONIBLE":
                    conn.execute("UPDATE cupos SET estado='ANULADO' WHERE id=?", (cupo_id,))
                    historial(conn, [cupo_id], "ANULADO", usuario_id, "Borrado/anulado en STOP")
                    res["anulados"] += 1
                elif estado == "BORRADO" and cupo["estado"] == "ASIGNADO":
                    res["avisos"].append(f"Cupo {codigo}: está ASIGNADO pero STOP lo informa borrado/anulado")
            else:
                cupo_id = None
                res["de_terceros"] += 1
            conn.execute(
                """INSERT INTO stop_turnos (codigo, id_terminal, fecha, cuit_destinatario, es_amaggi, cupo_id, estado, ctg, datos)
                   VALUES (?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(codigo) DO UPDATE SET id_terminal=excluded.id_terminal, fecha=excluded.fecha,
                     cuit_destinatario=excluded.cuit_destinatario, es_amaggi=excluded.es_amaggi,
                     cupo_id=COALESCE(excluded.cupo_id, cupo_id), estado=excluded.estado, ctg=excluded.ctg,
                     datos=excluded.datos, actualizado=datetime('now','localtime')""",
                (codigo, id_term, fecha, dest, int(es_amaggi), cupo_id, estado, ctg, json.dumps(t, ensure_ascii=False)))
    return res


def _ctg_libre(conn, ctg, cupo_id):
    """El CTG que informa STOP se acepta tal cual (STOP es la fuente), salvo que ya esté en otro cupo."""
    if not ctg:
        return None
    otro = conn.execute("SELECT 1 FROM cupos WHERE ctg=? AND id <> COALESCE(?, -1)", (ctg, cupo_id)).fetchone()
    return None if otro else ctg


def estado(conn) -> dict:
    cfg = configuracion()
    ult = conn.execute("SELECT creado, ok, detalle FROM stop_consultas WHERE recurso='misturnosactivos' "
                       "ORDER BY id DESC LIMIT 1").fetchone()
    ult_ok = conn.execute("SELECT creado FROM stop_consultas WHERE recurso='misturnosactivos' AND ok=1 "
                          "ORDER BY id DESC LIMIT 1").fetchone()
    return {**cfg, "consultas_hoy": consultas_hoy(conn), "limite": LIMITE_DIARIO - RESERVA,
            "ultima": dict(ult) if ult else None, "ultima_ok": ult_ok[0] if ult_ok else None,
            "turnos": conn.execute("SELECT COUNT(*) FROM stop_turnos").fetchone()[0],
            "terminales": conn.execute("SELECT COUNT(*) FROM stop_terminales").fetchone()[0]}


# ---------------------------------------------------------------- sincronización automática
def iniciar_automatico() -> None:
    """Hilo que sincroniza cada STOP_SYNC_MINUTOS (mínimo 30, por el límite de 48 consultas diarias)."""
    cfg = configuracion()
    if not cfg["lista"] or cfg["minutos"] <= 0:
        log.info("STOP: sincronización automática apagada (%s)", cfg)
        return
    minutos = max(30, cfg["minutos"])

    def bucle():
        time.sleep(20)  # dejar arrancar el servidor
        while True:
            conn = db.connect()
            try:
                sincronizar(conn, None, "automática")
            except StopError as e:
                log.warning("STOP: %s", e)
            except Exception:  # noqa: BLE001
                log.exception("STOP: error inesperado en la sincronización automática")
            finally:
                conn.close()
            time.sleep(minutos * 60)

    threading.Thread(target=bucle, name="stop-sync", daemon=True).start()


# ---------------------------------------------------------------- simulador (modo "simulado")
class _Simulador:
    """Genera respuestas con el formato documentado de STOP. Datos inventados y estables por día."""

    TERMINALES = [
        (22, "SERVICIOS PORTUARIOS S.A. - Rosario - Terminal VI-VII Elevador de Granos", "ROSARIO", "SANTA FE"),
        (31, "TERMINAL 6 S.A. - Puerto General San Martin - Terminal 6", "PUERTO GENERAL SAN MARTIN", "SANTA FE"),
        (39, "RENOVA S.A. - Timbues - Terminal Renova", "TIMBUES", "SANTA FE"),
        (51, "TERMINAL QUEQUEN S.A. - Quequen - Terminal Quequen", "QUEQUEN", "BUENOS AIRES"),
        (60, "TERMINAL BAHIA BLANCA S.A. - Bahia Blanca - Puerto Galvan", "BAHIA BLANCA", "BUENOS AIRES"),
    ]
    ESPECIES = [(15, "Maiz"), (23, "Soja"), (2, "Trigo Pan"), (22, "Sorgo Granifero"), (26, "Girasol")]

    def terminales(self):
        return [{"idTerminal": i, "descripcion": d, "nombreLocalidad": l, "nombreProvincia": p} for i, d, l, p in self.TERMINALES]

    def especies(self):
        return [{"codGrano": c, "descripcion": n} for c, n in self.ESPECIES]

    def mis_turnos(self, desde, hasta):
        cuit = amaggi_cuit() or CUIT_SIMULADO
        d, h = date.fromisoformat(desde), date.fromisoformat(hasta)
        hoy = date.today()
        out = []
        while d <= h:
            rnd = random.Random(d.toordinal())
            for n in range(4):
                term = rnd.choice(self.TERMINALES)
                grano = rnd.choice(self.ESPECIES[:3])
                codigo = f"{d:%Y%m%d}{rnd.randint(0, 999999):06d}"
                propio = n < 3
                if d < hoy:
                    estado = rnd.choice([3, 3, 5])
                elif d == hoy:
                    estado = rnd.choice([2, 5, 1])
                else:
                    estado = rnd.choice([1, 1, 2])
                ctg = f"{rnd.randint(10**11, 10**12 - 1)}" if estado != 1 else None
                out.append({
                    "idCupo": rnd.randint(10**6, 10**7), "idCupoTerminal": codigo, "idTerminal": term[0],
                    "fecha": f"{d.isoformat()}T00:00:00", "ctg": ctg,
                    "cartaPorte": f"{rnd.randint(10**8, 10**9 - 1)}" if ctg else None,
                    "idCupoEstado": estado, "esAnulado": "N", "esRechazado": "N", "codGrano": grano[0],
                    "cosecha": "2526", "pesoNetoEstimado": rnd.choice([28500, 30000, 30360, 29420]) if ctg else None,
                    "idCuitDestinatario": int(cuit) if propio else 30500120882,
                    "idCuitRemComercial": None if propio else int(cuit),
                    "fechaActivado": f"{d.isoformat()}T08:00:00" if estado in (2, 3, 5) else None,
                    "fechaDescargado": f"{d.isoformat()}T15:00:00" if estado == 3 else None,
                })
            d += timedelta(days=1)
        return out


SIMULADOR = _Simulador()
