"""Conectores de sincronización automática con STOP y SIGAM.

No conozco las APIs reales de STOP ni de SIGAM, así que cada conector admite dos modos,
configurables por variables de entorno (ver README):

  * *_API_URL     -> GET que devuelve JSON: lista de objetos con las mismas columnas que el archivo.
  * *_EXPORT_PATH -> ruta a un archivo .csv/.xlsx que otro proceso deja actualizado
                     (por ejemplo, un export programado de SIGAM en una carpeta compartida).

Para conectar la API real, reemplazar `_fetch_api` por el cliente correspondiente
(autenticación, paginación, etc.) manteniendo la salida: lista de dicts.
"""
import json
import os
import urllib.request
from pathlib import Path

from . import importers


class NoConfigurado(Exception):
    pass


def _fetch_api(url: str, token_env: str) -> list[dict]:
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    token = os.environ.get(token_env)
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if isinstance(data, dict):
        data = data.get("items") or data.get("data") or data.get("cupos") or data.get("contratos") or []
    return [{importers._norm(k): v for k, v in row.items()} for row in data]


def _leer(prefix: str) -> tuple[list[dict], str]:
    url = os.environ.get(f"{prefix}_API_URL")
    if url:
        return _fetch_api(url, f"{prefix}_API_TOKEN"), url
    path = os.environ.get(f"{prefix}_EXPORT_PATH")
    if path:
        p = Path(path)
        if not p.exists():
            raise NoConfigurado(f"No existe el archivo {p}")
        return importers.read_table(p.name, p.read_bytes()), str(p)
    raise NoConfigurado(
        f"Sincronización con {prefix} no configurada. Definí {prefix}_API_URL o {prefix}_EXPORT_PATH, "
        "o importá un archivo manualmente."
    )


def sync_stop(conn, user_id: int) -> dict:
    filas, fuente = _leer("STOP")
    return importers.importar_cupos(conn, filas, "STOP", f"sync:{fuente}", user_id)


def sync_sigam(conn, tipo: str, user_id: int) -> dict:
    """tipo: COMPRA o VENTA (SIGAM los exporta por separado)."""
    filas, fuente = _leer(f"SIGAM_{tipo}")
    return importers.importar_contratos(conn, filas, tipo, f"sync:{fuente}", user_id)


def estado() -> dict:
    def modo(prefix):
        if os.environ.get(f"{prefix}_API_URL"):
            return "API"
        if os.environ.get(f"{prefix}_EXPORT_PATH"):
            return "ARCHIVO"
        return None
    return {k: modo(k) for k in ("STOP", "SIGAM_COMPRA", "SIGAM_VENTA")}
