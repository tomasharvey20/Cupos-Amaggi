"""Avisos de cupos asignados a los clientes: contactos, modelos de Carta de Porte y bandeja de salida.

Flujo:
  1. Al asignar cupos a un contrato de compra, se agregan a un ENVÍO PENDIENTE de ese contrato
     (uno por contrato: si ya había uno sin enviar, se suman ahí).
  2. En la bandeja de salida se ve el mail armado: destinatarios (contactos del cliente y del corredor),
     tabla de cupos y el modelo de Carta de Porte con los datos completos.
  3. "Abrir en Outlook" descarga un .eml que Outlook abre como mensaje nuevo listo para enviar.
     Cuando haya cuenta de envío (Microsoft 365 / SMTP) se puede enviar directo desde acá.

Los modelos de CPE tienen campos con texto fijo y variables {{variable}} que se completan con
los datos del contrato de compra, del contrato de venta (si el cupo es de venta) y del destino.
"""
import html
import json
import os
import re
from email.message import EmailMessage
from email.utils import formatdate

from .db import audit, rows

# ---------------------------------------------------------------- variables disponibles en los modelos
VARIABLES = {
    "vendedor": "Vendedor del contrato de compra (titular de la CP)",
    "vendedor_cuit": "CUIT del vendedor",
    "contrato_compra": "N° de contrato de compra",
    "corredor_compra": "Corredor del contrato de compra",
    "producto": "Producto",
    "cosecha": "Cosecha",
    "destino": "Destino (zona: UPRIVER, NECOCHEA…)",
    "puerto": "Puerto / terminal del cupo",
    "terminal": "Terminal según STOP (o puerto/destino si no hay)",
    "comprador_venta": "Comprador del contrato de venta (cupos de venta)",
    "comprador_venta_cuit": "CUIT del comprador",
    "contrato_venta": "N° de contrato de venta",
    "corredor_venta": "Corredor del contrato de venta",
    "amaggi": "Razón social de Amaggi",
    "amaggi_cuit": "CUIT de Amaggi",
}

MODELOS_INICIALES = [
    ("Stock propio (STOP) · destinatario Amaggi", "STOP", [
        ("Intervinientes", "Titular de la Carta de Porte", "{{vendedor}} — CUIT {{vendedor_cuit}}"),
        ("Intervinientes", "Corredor venta primaria", "{{corredor_compra}}"),
        ("Intervinientes", "Destinatario", "{{amaggi}} — CUIT {{amaggi_cuit}}"),
        ("Intervinientes", "Destino", "{{terminal}}"),
        ("Grano", "Producto", "{{producto}}"),
        ("Grano", "Cosecha", "{{cosecha}}"),
        ("Grano", "Contrato", "{{contrato_compra}}"),
        ("Observaciones", "Observaciones", "Contrato de compra AMAGGI N° {{contrato_compra}}"),
    ]),
    ("Cupo de contrato de venta · destinatario comprador", "VENTA", [
        ("Intervinientes", "Titular de la Carta de Porte", "{{vendedor}} — CUIT {{vendedor_cuit}}"),
        ("Intervinientes", "Remitente comercial venta primaria", "{{amaggi}} — CUIT {{amaggi_cuit}}"),
        ("Intervinientes", "Corredor venta primaria", "{{corredor_compra}}"),
        ("Intervinientes", "Corredor venta secundaria", "{{corredor_venta}}"),
        ("Intervinientes", "Destinatario", "{{comprador_venta}} — CUIT {{comprador_venta_cuit}}"),
        ("Intervinientes", "Destino", "{{terminal}}"),
        ("Grano", "Producto", "{{producto}}"),
        ("Grano", "Cosecha", "{{cosecha}}"),
        ("Grano", "Contrato", "{{contrato_compra}}"),
        ("Observaciones", "Observaciones", "Compra AMAGGI N° {{contrato_compra}} · Venta N° {{contrato_venta}}"),
    ]),
]


def inicializar(conn) -> None:
    """Modelos de CPE iniciales y contactos de los clientes ya registrados (se corre al arrancar)."""
    if not conn.execute("SELECT 1 FROM cpe_modelos LIMIT 1").fetchone():
        for nombre, origen, campos in MODELOS_INICIALES:
            conn.execute("INSERT INTO cpe_modelos (nombre, origen, campos) VALUES (?,?,?)",
                         (nombre, origen, json.dumps([{"seccion": s, "campo": c, "valor": v} for s, c, v in campos],
                                                     ensure_ascii=False)))
    for (uid,) in conn.execute("SELECT id FROM usuarios WHERE rol='CLIENTE'").fetchall():
        sync_contacto_usuario(conn, uid)


# ---------------------------------------------------------------- contactos
def sync_contacto_usuario(conn, usuario_id: int) -> None:
    """Cada usuario CLIENTE registrado es también un contacto que recibe los cupos de su CUIT."""
    u = conn.execute("SELECT * FROM usuarios WHERE id=?", (usuario_id,)).fetchone()
    if not u:
        return
    existente = conn.execute("SELECT id FROM contactos WHERE usuario_id=?", (usuario_id,)).fetchone()
    if u["rol"] != "CLIENTE" or not u["cuit"]:
        if existente:
            conn.execute("UPDATE contactos SET activo=0 WHERE id=?", (existente["id"],))
        return
    r = conn.execute("SELECT contraparte_nombre FROM contratos WHERE contraparte_cuit=? AND contraparte_nombre <> '' LIMIT 1",
                     (u["cuit"],)).fetchone()
    empresa = (r[0] if r else None) or u["nombre"]
    if existente:
        conn.execute("UPDATE contactos SET empresa=?, cuit=?, nombre=?, email=?, activo=? WHERE id=?",
                      (empresa, u["cuit"], u["nombre"], u["email"], u["activo"], existente["id"]))
    else:
        conn.execute("""INSERT OR IGNORE INTO contactos (tipo, empresa, cuit, nombre, email, usuario_id, activo)
                        VALUES ('CLIENTE', ?, ?, ?, ?, ?, ?)""",
                     (empresa, u["cuit"], u["nombre"], u["email"], usuario_id, u["activo"]))


def destinatarios(conn, contrato: dict) -> list[dict]:
    """Contactos activos que reciben cupos: los del cliente (por CUIT, o por razón social si el contrato
    no trae CUIT — el export de SIGAM hoy no lo trae) y los del corredor (por nombre)."""
    out = rows(conn.execute(
        """SELECT * FROM contactos WHERE activo=1 AND recibe_cupos=1 AND (
             (tipo IN ('CLIENTE','OTRO') AND (
                 (COALESCE(cuit,'') <> '' AND cuit = ?) OR
                 UPPER(TRIM(empresa)) = UPPER(TRIM(COALESCE(?, ''))))) OR
             (tipo = 'CORREDOR' AND UPPER(TRIM(empresa)) = UPPER(TRIM(COALESCE(?, ''))) AND COALESCE(?, '') <> '')
           ) ORDER BY tipo, empresa, email""",
        (contrato.get("contraparte_cuit") or "-", contrato.get("contraparte_nombre") or "-",
         contrato.get("corredor"), contrato.get("corredor"))))
    vistos, unicos = set(), []
    for c in out:
        if c["email"].lower() not in vistos:
            vistos.add(c["email"].lower())
            unicos.append(c)
    return unicos


# ---------------------------------------------------------------- bandeja de salida
def encolar(conn, contrato_id: int, cupo_ids: list[int]) -> None:
    """Suma cupos recién asignados al envío pendiente del contrato (o crea uno)."""
    if not cupo_ids:
        return
    env = conn.execute("SELECT * FROM envios WHERE contrato_compra_id=? AND estado='PENDIENTE' ORDER BY id DESC LIMIT 1",
                       (contrato_id,)).fetchone()
    if env:
        ids = sorted(set(json.loads(env["cupo_ids"])) | set(cupo_ids))
        conn.execute("UPDATE envios SET cupo_ids=?, actualizado=datetime('now','localtime') WHERE id=?",
                     (json.dumps(ids), env["id"]))
    else:
        conn.execute("INSERT INTO envios (contrato_compra_id, cupo_ids) VALUES (?, ?)",
                     (contrato_id, json.dumps(sorted(set(cupo_ids)))))


def quitar(conn, cupo_id: int) -> None:
    """Al liberar un cupo, sale del envío pendiente (si el envío queda vacío, se borra)."""
    for env in conn.execute("SELECT * FROM envios WHERE estado='PENDIENTE'").fetchall():
        ids = json.loads(env["cupo_ids"])
        if cupo_id in ids:
            ids.remove(cupo_id)
            if ids:
                conn.execute("UPDATE envios SET cupo_ids=?, actualizado=datetime('now','localtime') WHERE id=?",
                             (json.dumps(ids), env["id"]))
            else:
                conn.execute("DELETE FROM envios WHERE id=?", (env["id"],))


def _amaggi() -> tuple[str, str]:
    cuit = re.sub(r"\D", "", os.environ.get("AMAGGI_CUIT", ""))
    cuit_fmt = f"{cuit[:2]}-{cuit[2:10]}-{cuit[10:]}" if len(cuit) == 11 else "(completar CUIT de Amaggi)"
    return os.environ.get("AMAGGI_RAZON_SOCIAL", "AMAGGI ARGENTINA S.A."), cuit_fmt


def _cuit(c) -> str:
    c = re.sub(r"\D", "", c or "")
    return f"{c[:2]}-{c[2:10]}-{c[10:]}" if len(c) == 11 else (c or "—")


def modelo_para(conn, origen: str, zona: str | None, puerto: str | None) -> dict | None:
    """El modelo más específico: origen + puerto > origen + destino > origen > cualquiera."""
    mods = rows(conn.execute("SELECT * FROM cpe_modelos WHERE activo=1"))

    def puntaje(m):
        if m["origen"] and m["origen"] != origen:
            return -1
        if m["zona"] and m["zona"] != zona:
            return -1
        if m["puerto"] and m["puerto"] != puerto:
            return -1
        return (4 if m["puerto"] else 0) + (2 if m["zona"] else 0) + (1 if m["origen"] else 0)

    candidatos = [(puntaje(m), m) for m in mods]
    candidatos = [c for c in candidatos if c[0] >= 0]
    return max(candidatos, key=lambda c: (c[0], -c[1]["id"]))[1] if candidatos else None


def _completar(texto: str, v: dict) -> str:
    return re.sub(r"\{\{\s*(\w+)\s*\}\}", lambda m: str(v.get(m.group(1)) or "—"), texto or "")


def armar(conn, envio_id: int) -> dict:
    """Arma el mail de un envío con los datos actuales (asunto, html, destinatarios, cupos)."""
    env = conn.execute("SELECT * FROM envios WHERE id=?", (envio_id,)).fetchone()
    if not env:
        raise ValueError("Envío inexistente")
    c = dict(conn.execute("SELECT * FROM contratos WHERE id=?", (env["contrato_compra_id"],)).fetchone())
    ids = json.loads(env["cupo_ids"])
    marks = ",".join("?" * len(ids)) or "NULL"
    cupos = rows(conn.execute(
        f"""SELECT cu.*, COALESCE(cu.puerto, cu.puerto_asignado) AS puerto_ef, st.descripcion AS terminal_stop,
                   cv.numero AS cv_numero, cv.contraparte_nombre AS cv_comprador, cv.contraparte_cuit AS cv_cuit,
                   cv.corredor AS cv_corredor
            FROM cupos cu
            LEFT JOIN stop_terminales st ON st.id_terminal = cu.stop_id_terminal
            LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE cu.id IN ({marks}) ORDER BY cu.fecha, cu.codigo""", ids))
    vigentes = [cu for cu in cupos if cu["contrato_compra_id"] == c["id"] and cu["estado"] in ("ASIGNADO", "UTILIZADO")]
    amaggi, amaggi_cuit = _amaggi()
    base = {"vendedor": c["contraparte_nombre"], "vendedor_cuit": _cuit(c["contraparte_cuit"]),
            # Corredor vacío en SIGAM = operación directa
            "contrato_compra": c["numero"], "corredor_compra": (c.get("corredor") or "").strip() or "Directo",
            "producto": c["producto"],
            "cosecha": c.get("cosecha"), "amaggi": amaggi, "amaggi_cuit": amaggi_cuit}

    # Un bloque de Carta de Porte por grupo de cupos que comparten modelo y datos (destino/terminal/venta)
    grupos = {}
    for cu in vigentes:
        v = {**base, "destino": cu["destino"], "puerto": cu["puerto_ef"],
             "terminal": cu["terminal_stop"] or cu["puerto_ef"] or cu["destino"],
             "comprador_venta": cu["cv_comprador"], "comprador_venta_cuit": _cuit(cu["cv_cuit"]),
             "contrato_venta": cu["cv_numero"], "corredor_venta": ((cu["cv_corredor"] or "").strip() or "Directo") if cu["cv_numero"] else None}
        modelo = modelo_para(conn, cu["origen"], cu["destino"], cu["puerto_ef"])
        campos = [(f["seccion"], f["campo"], _completar(f["valor"], v)) for f in json.loads(modelo["campos"])] if modelo else []
        clave = (modelo["id"] if modelo else 0, json.dumps(campos, ensure_ascii=False))
        grupos.setdefault(clave, {"modelo": modelo, "campos": campos, "cupos": []})["cupos"].append(cu)

    dest = destinatarios(conn, c)
    asunto = f"Cupos asignados – Contrato {c['numero']} – {c['producto']} – {len(vigentes)} cupo{'s' if len(vigentes) != 1 else ''}"
    return {"envio": dict(env), "contrato": c, "cupos": vigentes, "quitados": len(ids) - len(vigentes),
            "destinatarios": dest, "asunto": asunto, "html": _html(c, grupos, len(vigentes))}


E = lambda s: html.escape(str(s if s not in (None, "") else "—"))  # noqa: E731
AZUL, VERDE = "#006398", "#009E61"


def _fecha(iso):
    return f"{iso[8:10]}/{iso[5:7]}/{iso[:4]}" if iso and len(iso) >= 10 else "—"


def _html(c, grupos, total) -> str:
    th = f'style="text-align:left;padding:6px 10px;background:{AZUL};color:#fff;font-size:12px"'
    td = 'style="padding:6px 10px;border-bottom:1px solid #dde3ea;font-size:13px"'
    partes = [f"""<div style="font-family:Segoe UI,Arial,sans-serif;color:#1c2b38;max-width:820px">
      <div style="border-top:4px solid {AZUL};padding:14px 0 6px"><strong style="color:{AZUL};font-size:18px">AMAGGI</strong>
        <span style="color:#5d6e7c"> · Cupos asignados</span></div>
      <p>Estimados {E(c['contraparte_nombre'])}:</p>
      <p>Les informamos {'el cupo asignado' if total == 1 else f'los {total} cupos asignados'} al contrato de compra
        <strong>N° {E(c['numero'])}</strong> ({E(c['producto'])}{' · cosecha ' + E(c['cosecha']) if c.get('cosecha') else ''}).
        Debajo se detallan los datos para emitir la Carta de Porte Electrónica.</p>"""]
    for g in grupos.values():
        cupos = g["cupos"]
        partes.append(f"""<table style="border-collapse:collapse;width:100%;margin:14px 0 6px">
          <tr><th {th}>Código de cupo</th><th {th}>Fecha</th><th {th}>Destino / terminal</th><th {th}>Tn</th></tr>
          {''.join(f'<tr><td {td}><strong>{E(cu["codigo"])}</strong></td><td {td}>{_fecha(cu["fecha"])}</td>'
                   f'<td {td}>{E(cu["terminal_stop"] or cu["puerto_ef"] or cu["destino"])}</td><td {td}>{E(cu["toneladas"])}</td></tr>'
                   for cu in cupos)}</table>""")
        if g["campos"]:
            filas, seccion = [], None
            for s, campo, valor in g["campos"]:
                if s != seccion:
                    filas.append(f'<tr><td colspan="2" style="padding:8px 10px 4px;font-size:11px;letter-spacing:.08em;'
                                 f'text-transform:uppercase;color:{AZUL};font-weight:700">{E(s)}</td></tr>')
                    seccion = s
                filas.append(f'<tr><td {td} width="38%"><span style="color:#5d6e7c">{E(campo)}</span></td><td {td}><strong>{E(valor)}</strong></td></tr>')
            partes.append(f"""<div style="border:1px solid #dde3ea;border-left:4px solid {VERDE};border-radius:6px;margin:6px 0 18px">
              <div style="padding:8px 10px;font-weight:700">Modelo de Carta de Porte
                <span style="font-weight:400;color:#5d6e7c">· {len(cupos)} cupo{'s' if len(cupos) != 1 else ''}</span></div>
              <table style="border-collapse:collapse;width:100%">{''.join(filas)}</table></div>""")
    partes.append("""<p style="color:#5d6e7c;font-size:12px">Ante cualquier duda respondan este mail.<br>
      Mensaje generado por el Sistema de Cupos AMAGGI.</p></div>""")
    return "".join(partes)


def eml(conn, envio_id: int) -> bytes:
    """Mensaje .eml que Outlook abre como borrador nuevo (X-Unsent) con destinatarios, asunto y cuerpo."""
    a = armar(conn, envio_id)
    msg = EmailMessage()
    msg["To"] = ", ".join(d["email"] for d in a["destinatarios"])
    msg["Subject"] = a["asunto"]
    msg["Date"] = formatdate(localtime=True)
    msg["X-Unsent"] = "1"
    msg.set_content("Este mensaje requiere un cliente de correo con soporte HTML.")
    msg.add_alternative(a["html"], subtype="html")
    return bytes(msg)


def marcar_enviado(conn, envio_id: int, user: dict) -> None:
    a = armar(conn, envio_id)
    conn.execute("""UPDATE envios SET estado='ENVIADO', destinatarios=?, asunto=?, cuerpo_html=?,
                    enviado_en=datetime('now','localtime'), enviado_por=? WHERE id=?""",
                 (", ".join(d["email"] for d in a["destinatarios"]), a["asunto"], a["html"], user["id"], envio_id))
    audit(conn, user["id"], "ENVIO_CUPOS", "envio", envio_id, f"{a['asunto']} → {len(a['destinatarios'])} destinatarios")
