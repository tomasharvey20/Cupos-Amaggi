"""Zonas de destino que agrupan varios destinos/puertos.

Todos los destinos de una zona se guardan con el nombre de la zona (ej. UPRIVER), así los
listados y filtros quedan simples. El nombre original (ROSARIO, TIMBUES, …) no se pierde:
en los cupos pasa a ser el *puerto* y en los contratos queda en `lugar_detalle`.

Para agregar destinos a una zona, o una zona nueva, alcanza con editar ZONAS.
"""
import re
import unicodedata

ZONAS = {
    "UPRIVER": [
        "UPRIVER", "UP RIVER", "ROSARIO", "SAN LORENZO", "SANTA FE", "ARROYO SECO",
        "GENERAL SAN MARTIN", "GRAL SAN MARTIN", "GRAL. SAN MARTIN", "PUERTO GENERAL SAN MARTIN",
        "PTO GENERAL SAN MARTIN", "PGSM", "TIMBUES", "RAMALLO",
    ],
    "NECOCHEA": ["NECOCHEA", "NECOCHEA PORT", "QUEQUEN", "PUERTO QUEQUEN"],
    # TLP = Terminal La Plata (localidades que informa STOP para esa terminal)
    "TLP": ["TLP", "TERMINAL LA PLATA", "LA PLATA", "ENSENADA"],
}

# Otras formas de escribir el MISMO lugar que la zona: se unifican sin guardar detalle
# (a diferencia de ROSARIO o TIMBUES, que sí quedan como puerto/detalle dentro de UPRIVER).
MISMO_LUGAR = {"UPRIVER": ["UP RIVER"], "NECOCHEA": ["NECOCHEA PORT"], "TLP": ["TERMINAL LA PLATA"]}


def _clave(v) -> str:
    s = unicodedata.normalize("NFKD", str(v or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Z0-9]+", " ", s.upper()).strip()


_A_ZONA = {_clave(d): zona for zona, destinos in ZONAS.items() for d in destinos}


def zona_de(destino) -> str | None:
    """Zona a la que pertenece un destino, o None si no está agrupado."""
    return _A_ZONA.get(_clave(destino))


def normalizar(destino) -> tuple[str, str | None]:
    """(destino a guardar, detalle original). Ej.: 'Timbúes' -> ('UPRIVER', 'TIMBUES');
    'UPRIVER' -> ('UPRIVER', None); 'NECOCHEA PORT' -> ('NECOCHEA PORT', None)."""
    texto = str(destino or "").strip().upper()
    zona = zona_de(texto)
    if not zona:
        return texto, None
    detalle = _clave(texto)
    if detalle == _clave(zona) or detalle in {_clave(a) for a in MISMO_LUGAR.get(zona, [])}:
        return zona, None
    return zona, detalle
