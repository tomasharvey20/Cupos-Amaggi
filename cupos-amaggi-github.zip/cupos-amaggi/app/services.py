"""Reglas de negocio: saldos de contratos, asignación de cupos y solicitudes."""
from datetime import date, datetime

from . import avisos as avisos_mail  # ("avisos" ya se usa como nombre de la lista de advertencias)
from .db import audit, historial, rows, transaction


class ReglaError(Exception):
    pass


def hoy() -> str:
    return date.today().isoformat()


def ahora() -> str:
    return datetime.now().isoformat(sep=" ", timespec="seconds")


# Estado visible: un cupo DISPONIBLE con fecha pasada se muestra como VENCIDO.
ESTADO_VISIBLE = "CASE WHEN cu.estado='DISPONIBLE' AND cu.fecha < date('now','localtime') THEN 'VENCIDO' ELSE cu.estado END"

CONTRATO_SELECT = """
SELECT c.*,
  COALESCE(SUM(CASE WHEN cu.estado='ASIGNADO' THEN cu.toneladas END), 0)          AS tn_asignadas,
  COUNT(CASE WHEN cu.estado='ASIGNADO' THEN 1 END)                               AS cupos_asignados,
  COUNT(CASE WHEN cu.estado='UTILIZADO' THEN 1 END)                              AS cupos_utilizados,
  c.toneladas - c.toneladas_entregadas
    - COALESCE(SUM(CASE WHEN cu.estado='ASIGNADO' THEN cu.toneladas END), 0)      AS saldo
FROM contratos c
LEFT JOIN cupos cu ON cu.contrato_compra_id = c.id
"""

CONTRATO_VENTA_SELECT = """
SELECT c.*,
  COUNT(cu.id)                                                                    AS cupos_total,
  COUNT(CASE WHEN cu.estado='DISPONIBLE' AND cu.fecha >= date('now','localtime') THEN 1 END) AS cupos_disponibles,
  COUNT(CASE WHEN cu.estado='ASIGNADO' THEN 1 END)                                AS cupos_asignados,
  COUNT(CASE WHEN cu.estado='UTILIZADO' THEN 1 END)                               AS cupos_utilizados,
  c.toneladas - c.toneladas_entregadas                                            AS saldo
FROM contratos c
LEFT JOIN cupos cu ON cu.contrato_venta_id = c.id
"""


def contrato_compra(conn, contrato_id: int) -> dict:
    r = conn.execute(CONTRATO_SELECT + " WHERE c.id=? GROUP BY c.id", (contrato_id,)).fetchone()
    if not r or r["tipo"] != "COMPRA":
        raise ReglaError("Contrato de compra inexistente")
    return dict(r)


def asignar(conn, cupo_ids: list[int], contrato_id: int, user: dict, solicitud_id: int | None = None) -> dict:
    """Asigna cupos disponibles a un contrato de compra. Debe llamarse dentro de una transacción."""
    if not cupo_ids:
        raise ReglaError("No se seleccionaron cupos")
    c = contrato_compra(conn, contrato_id)
    if c["estado"] != "VIGENTE":
        raise ReglaError(f"El contrato {c['numero']} no está vigente ({c['estado']})")
    marks = ",".join("?" * len(cupo_ids))
    cupos = rows(conn.execute(f"SELECT * FROM cupos WHERE id IN ({marks})", cupo_ids))
    if len(cupos) != len(set(cupo_ids)):
        raise ReglaError("Algún cupo seleccionado no existe")
    avisos = []
    for cu in cupos:
        if cu["estado"] != "DISPONIBLE":
            raise ReglaError(f"El cupo {cu['codigo']} no está disponible ({cu['estado']})")
        if cu["fecha"] < hoy():
            raise ReglaError(f"El cupo {cu['codigo']} está vencido ({cu['fecha']})")
        if cu["producto"] != c["producto"]:
            raise ReglaError(f"El cupo {cu['codigo']} es de {cu['producto']} y el contrato de {c['producto']}")
        if (c["fecha_desde"] and cu["fecha"] < c["fecha_desde"]) or (c["fecha_hasta"] and cu["fecha"] > c["fecha_hasta"]):
            avisos.append(f"Cupo {cu['codigo']} ({cu['fecha']}) fuera del período de entrega del contrato")
    tn = sum(cu["toneladas"] for cu in cupos)
    if tn > c["saldo"] + 1e-6:
        raise ReglaError(
            f"Saldo insuficiente en contrato {c['numero']}: saldo {c['saldo']:.0f} tn, cupos {tn:.0f} tn")
    conn.execute(
        f"""UPDATE cupos SET estado='ASIGNADO', contrato_compra_id=?, solicitud_id=?, asignado_por=?, asignado_en=?
            WHERE id IN ({marks})""",
        (contrato_id, solicitud_id, user["id"], ahora(), *cupo_ids),
    )
    historial(conn, [cu["id"] for cu in cupos], "ASIGNADO", user["id"],
              f"Solicitud #{solicitud_id}" if solicitud_id else None)
    avisos_mail.encolar(conn, contrato_id, [cu["id"] for cu in cupos])  # mail al cliente en la bandeja de salida
    audit(conn, user["id"], "ASIGNAR", "contrato", contrato_id,
          f"{len(cupos)} cupos ({', '.join(cu['codigo'] for cu in cupos)}) al contrato {c['numero']}")
    return {"asignados": len(cupos), "toneladas": tn, "avisos": avisos}


def asignar_planilla(conn, user: dict, producto: str | None, destino: str | None, origen: str | None,
                     items: list[dict], contrato_venta_id: int | None = None) -> dict:
    """Asigna cantidades de cupos por contrato y día (desde la planilla semanal o la vista por contrato).
    Para cada (contrato, día) toma N cupos DISPONIBLES del producto/destino/origen filtrados,
    prefiriendo los del lugar de entrega del contrato. Todo o nada: si algo no alcanza, no se asigna nada.
    Sin producto: cada contrato usa el suyo. Cada ítem puede traer su propio destino (zona del contrato)."""
    if not items:
        raise ReglaError("No cargaste cantidades")
    tomados: set[int] = set()
    total, avisos, contratos = 0, [], set()
    destino_general = destino
    with transaction(conn):
        for it in sorted(items, key=lambda i: (i["fecha"], i["contrato_id"])):
            c = contrato_compra(conn, it["contrato_id"])
            if producto and c["producto"] != producto:
                raise ReglaError(f"El contrato {c['numero']} es de {c['producto']}, no de {producto}")
            destino = it.get("destino") or destino_general
            where, params = ["estado='DISPONIBLE'", "producto=?", "fecha=?"], [c["producto"], it["fecha"]]
            if destino:
                where.append("destino=?")
                params.append(destino)
            if origen:
                where.append("origen=?")
                params.append(origen)
            if contrato_venta_id:
                where.append("contrato_venta_id=?")
                params.append(contrato_venta_id)
            puerto = (it.get("puerto") or "").strip().upper() or None
            if puerto:
                # Sirven los cupos de esa terminal y los que no tienen terminal informada de la misma zona
                zona = destino or (conn.execute("SELECT zona FROM puertos WHERE nombre = ? LIMIT 1", (puerto,)).fetchone() or [None])[0]
                if not zona:
                    raise ReglaError(f"La terminal {puerto} no está en el catálogo (no se asignó nada)")
                if not destino:
                    where.append("destino=?")
                    params.append(zona)
                where.append("(puerto IS NULL OR puerto = ?)")
                params.append(puerto)
            if tomados:
                where.append(f"id NOT IN ({','.join('?' * len(tomados))})")
                params += list(tomados)
            ids = [r[0] for r in conn.execute(
                f"""SELECT id FROM cupos WHERE {' AND '.join(where)}
                    ORDER BY (puerto = ?) DESC, (destino = UPPER(COALESCE(?, ''))) DESC, codigo LIMIT ?""",
                (*params, puerto, c["lugar_entrega"], it["cantidad"]))]
            if len(ids) < it["cantidad"]:
                raise ReglaError(f"El {it['fecha'][8:10]}/{it['fecha'][5:7]} hay {len(ids)} cupos disponibles"
                                 f"{f' para {puerto}' if puerto else ''} y pediste {it['cantidad']} para {c['numero']} (no se asignó nada)")
            if puerto:  # se graba antes de asignar para que quede en el historial
                conn.execute(f"UPDATE cupos SET puerto_asignado=? WHERE puerto IS NULL AND id IN ({','.join('?' * len(ids))})",
                             (puerto, *ids))
            try:
                r = asignar(conn, ids, c["id"], user)
            except ReglaError as e:
                raise ReglaError(f"{e} (no se asignó nada)")
            tomados.update(ids)
            total += r["asignados"]
            avisos += r["avisos"]
            contratos.add(c["id"])
    return {"asignados": total, "contratos": len(contratos), "avisos": avisos}


def validar_ctg(conn, ctg, cupo_id: int | None = None) -> str | None:
    """CTG (Código de Trazabilidad de Granos, ARCA): 12 dígitos, y no puede estar en otro cupo."""
    if ctg in (None, ""):
        return None
    valor = "".join(ch for ch in str(ctg) if ch.isdigit())
    if len(valor) != 12:
        raise ReglaError(f"El CTG debe tener 12 dígitos (se ingresó '{ctg}')")
    otro = conn.execute("SELECT codigo FROM cupos WHERE ctg = ? AND id <> COALESCE(?, -1)", (valor, cupo_id)).fetchone()
    if otro:
        raise ReglaError(f"El CTG {valor} ya está asociado al cupo {otro[0]}")
    return valor


def cargar_ctg(conn, cupo_id: int, ctg, user: dict):
    with transaction(conn):
        cu = conn.execute("SELECT * FROM cupos WHERE id=?", (cupo_id,)).fetchone()
        if not cu:
            raise ReglaError("Cupo inexistente")
        if cu["estado"] not in ("ASIGNADO", "UTILIZADO"):
            raise ReglaError("El CTG se carga en cupos asignados a un contrato de compra")
        valor = validar_ctg(conn, ctg, cupo_id)
        conn.execute("UPDATE cupos SET ctg=? WHERE id=?", (valor, cupo_id))
        historial(conn, [cupo_id], "CTG", user["id"], f"CTG {valor}" if valor else "CTG borrado")
        audit(conn, user["id"], "CTG", "cupo", cupo_id, f"Cupo {cu['codigo']}: CTG {valor or '-'}")


def liberar(conn, cupo_id: int, user: dict):
    with transaction(conn):
        cu = conn.execute("SELECT * FROM cupos WHERE id=?", (cupo_id,)).fetchone()
        if not cu or cu["estado"] != "ASIGNADO":
            raise ReglaError("Solo se pueden liberar cupos asignados")
        historial(conn, [cupo_id], "LIBERADO", user["id"], "Se desvinculó del contrato de compra")  # antes de borrar el vínculo
        avisos_mail.quitar(conn, cupo_id)  # si todavía no se avisó al cliente, sale del mail pendiente
        conn.execute(
            """UPDATE cupos SET estado='DISPONIBLE', contrato_compra_id=NULL, solicitud_id=NULL, puerto_asignado=NULL,
               asignado_por=NULL, asignado_en=NULL, transportista=NULL, patente=NULL, ctg=NULL WHERE id=?""",
            (cupo_id,),
        )
        if cu["solicitud_id"]:
            s = conn.execute("SELECT * FROM solicitudes WHERE id=?", (cu["solicitud_id"],)).fetchone()
            aprobada = max(0, s["cantidad_aprobada"] - 1)
            estado = "PENDIENTE" if aprobada == 0 else "PARCIAL"
            conn.execute("UPDATE solicitudes SET cantidad_aprobada=?, estado=? WHERE id=?", (aprobada, estado, s["id"]))
        audit(conn, user["id"], "LIBERAR", "cupo", cupo_id, f"Cupo {cu['codigo']} liberado")


def cambiar_estado(conn, cupo_id: int, user: dict, nuevo: str, ctg=None):
    with transaction(conn):
        cu = conn.execute("SELECT * FROM cupos WHERE id=?", (cupo_id,)).fetchone()
        if not cu:
            raise ReglaError("Cupo inexistente")
        if nuevo == "UTILIZADO":
            if cu["estado"] != "ASIGNADO":
                raise ReglaError("Solo un cupo asignado puede marcarse como utilizado")
            valor = validar_ctg(conn, ctg, cupo_id)
            conn.execute("UPDATE cupos SET estado='UTILIZADO', ctg=COALESCE(?, ctg) WHERE id=?", (valor, cupo_id))
        elif nuevo == "ANULADO":
            if cu["estado"] != "DISPONIBLE":
                raise ReglaError("Solo un cupo disponible puede anularse (liberalo primero)")
            conn.execute("UPDATE cupos SET estado='ANULADO' WHERE id=?", (cupo_id,))
        else:
            raise ReglaError("Estado no válido")
        historial(conn, [cupo_id], nuevo, user["id"])
        audit(conn, user["id"], nuevo, "cupo", cupo_id, f"Cupo {cu['codigo']}")


def crear_solicitud(conn, user: dict, contrato_id: int, fecha: str, cantidad: int,
                    destino_preferido: str | None, observaciones: str | None, tn_por_cupo: float) -> int:
    with transaction(conn):
        c = contrato_compra(conn, contrato_id)
        if c["contraparte_cuit"] != user["cuit"]:
            raise ReglaError("El contrato no pertenece a tu CUIT")
        if c["estado"] != "VIGENTE":
            raise ReglaError("El contrato no está vigente")
        if fecha < hoy():
            raise ReglaError("La fecha no puede ser anterior a hoy")
        pendiente = conn.execute(
            "SELECT COALESCE(SUM(cantidad - cantidad_aprobada),0) FROM solicitudes WHERE contrato_compra_id=? AND estado IN ('PENDIENTE','PARCIAL')",
            (contrato_id,)).fetchone()[0]
        if (cantidad + pendiente) * tn_por_cupo > c["saldo"] + 1e-6:
            raise ReglaError(
                f"La cantidad supera el saldo del contrato: saldo {c['saldo']:.0f} tn, "
                f"ya hay {pendiente} cupos pedidos pendientes, cada cupo ≈ {tn_por_cupo:.0f} tn")
        cur = conn.execute(
            """INSERT INTO solicitudes (usuario_id, contrato_compra_id, fecha, destino_preferido, cantidad, observaciones)
               VALUES (?,?,?,?,?,?)""",
            (user["id"], contrato_id, fecha, (destino_preferido or None), cantidad, observaciones or None))
        audit(conn, user["id"], "SOLICITAR", "solicitud", cur.lastrowid,
              f"{cantidad} cupos para {fecha}, contrato {c['numero']}")
        return cur.lastrowid


def aprobar_solicitud(conn, solicitud_id: int, cupo_ids: list[int], respuesta: str | None, user: dict) -> dict:
    with transaction(conn):
        s = conn.execute("SELECT * FROM solicitudes WHERE id=?", (solicitud_id,)).fetchone()
        if not s or s["estado"] not in ("PENDIENTE", "PARCIAL"):
            raise ReglaError("La solicitud no está pendiente")
        faltan = s["cantidad"] - s["cantidad_aprobada"]
        if len(cupo_ids) > faltan:
            raise ReglaError(f"La solicitud pide {faltan} cupos más; seleccionaste {len(cupo_ids)}")
        res = asignar(conn, cupo_ids, s["contrato_compra_id"], user, solicitud_id=solicitud_id)
        aprobada = s["cantidad_aprobada"] + len(cupo_ids)
        estado = "APROBADA" if aprobada >= s["cantidad"] else "PARCIAL"
        conn.execute(
            "UPDATE solicitudes SET estado=?, cantidad_aprobada=?, respuesta=COALESCE(?,respuesta), resuelto_por=?, resuelto_en=? WHERE id=?",
            (estado, aprobada, respuesta or None, user["id"], ahora(), solicitud_id))
        audit(conn, user["id"], "APROBAR", "solicitud", solicitud_id, f"{len(cupo_ids)} cupos, estado {estado}")
        return {**res, "estado": estado}


def rechazar_solicitud(conn, solicitud_id: int, respuesta: str, user: dict):
    with transaction(conn):
        s = conn.execute("SELECT * FROM solicitudes WHERE id=?", (solicitud_id,)).fetchone()
        if not s or s["estado"] not in ("PENDIENTE", "PARCIAL"):
            raise ReglaError("La solicitud no está pendiente")
        if not (respuesta or "").strip():
            raise ReglaError("Indicá el motivo del rechazo")
        # PARCIAL = abierta con parte aprobada. Rechazar el resto la cierra como APROBADA
        # (queda registrado "x de y" y el motivo); sin nada aprobado queda RECHAZADA.
        estado = "APROBADA" if s["cantidad_aprobada"] else "RECHAZADA"
        conn.execute(
            "UPDATE solicitudes SET estado=?, respuesta=?, resuelto_por=?, resuelto_en=? WHERE id=?",
            (estado, respuesta, user["id"], ahora(), solicitud_id))
        audit(conn, user["id"], "RECHAZAR", "solicitud", solicitud_id, respuesta)
