"""Crea el usuario administrador inicial y, opcionalmente, datos de demostración.

Uso:
    python -m app.seed --admin admin@empresa.com --password "ClaveSegura123"
    python -m app.seed --demo        # además carga contratos, cupos y usuarios de ejemplo
"""
import argparse
from datetime import date, timedelta

from . import importers
from .db import connect, init_db
from .security import hash_password

DEMO_PASSWORD = "demo1234"


def crear_usuario(conn, email, nombre, rol, password, cuit=None):
    if conn.execute("SELECT 1 FROM usuarios WHERE email=?", (email,)).fetchone():
        return False
    conn.execute("INSERT INTO usuarios (email, nombre, password_hash, rol, cuit) VALUES (?,?,?,?,?)",
                 (email, nombre, hash_password(password), rol, cuit))
    return True


def demo(conn):
    d = lambda n: (date.today() + timedelta(days=n)).isoformat()
    crear_usuario(conn, "operador@demo.local", "Operador Logística", "OPERADOR", DEMO_PASSWORD)
    crear_usuario(conn, "agro.sur@demo.local", "Agro del Sur S.A.", "CLIENTE", DEMO_PASSWORD, "30711111118")
    crear_usuario(conn, "campos.norte@demo.local", "Campos del Norte S.R.L.", "CLIENTE", DEMO_PASSWORD, "30722222225")
    admin_id = conn.execute("SELECT id FROM usuarios WHERE rol='ADMIN' ORDER BY id LIMIT 1").fetchone()[0]

    contratos = [
        # numero, tipo, cuit, nombre, producto, tn, entregadas, desde, hasta, lugar
        ("C-1001", "COMPRA", "30711111118", "Agro del Sur S.A.", "SOJA", 1500, 300, d(-20), d(40), "Rosario"),
        ("C-1002", "COMPRA", "30711111118", "Agro del Sur S.A.", "MAIZ", 900, 0, d(-5), d(60), "Timbúes"),
        ("C-1003", "COMPRA", "30722222225", "Campos del Norte S.R.L.", "SOJA", 600, 120, d(0), d(30), "San Lorenzo"),
        ("C-1004", "COMPRA", "30722222225", "Campos del Norte S.R.L.", "TRIGO", 450, 0, d(10), d(50), "Rosario"),
        ("V-2001", "VENTA", "30733333332", "Exportadora Paraná S.A.", "SOJA", 5000, 1000, d(-10), d(45), "Terminal Paraná"),
        ("V-2002", "VENTA", "30744444449", "Molinos Litoral S.A.", "MAIZ", 2000, 0, d(0), d(60), "Puerto Litoral"),
    ]
    for tipo in ("COMPRA", "VENTA"):
        filas = [dict(numero=c[0], cuit=c[2], razon_social=c[3], producto=c[4], toneladas=c[5],
                      toneladas_entregadas=c[6], fecha_desde=c[7], fecha_hasta=c[8], lugar_entrega=c[9])
                 for c in contratos if c[1] == tipo]
        importers.importar_contratos(conn, filas, tipo, "demo", admin_id)

    stop, venta = [], []
    for i in range(24):
        dia = i % 6
        stop.append({"codigo_cupo": f"ST{date.today():%y%m%d}{i:03d}", "fecha": d(dia),
                     "terminal": ["ROSARIO", "TIMBUES", "SAN LORENZO"][i % 3],
                     "producto": ["SOJA", "SOJA", "MAIZ", "TRIGO"][i % 4],
                     "destinatario": "AMAGGI ARGENTINA S.A."})
    for i in range(16):
        venta.append({"codigo_cupo": f"VT{date.today():%y%m%d}{i:03d}", "fecha": d(i % 5 + 1),
                      "terminal": "TERMINAL PARANA" if i % 2 == 0 else "PUERTO LITORAL",
                      "producto": "SOJA" if i % 2 == 0 else "MAIZ",
                      "contrato_venta": "V-2001" if i % 2 == 0 else "V-2002"})
    importers.importar_cupos(conn, stop, "STOP", "demo", admin_id)
    importers.importar_cupos(conn, venta, "VENTA", "demo", admin_id)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--admin", default="admin@demo.local")
    ap.add_argument("--password", default=None)
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    init_db()
    conn = connect()
    pwd = a.password or (DEMO_PASSWORD if a.demo else None)
    if not pwd:
        ap.error("Indicá --password para el administrador (mín. 8 caracteres)")
    if crear_usuario(conn, a.admin, "Administrador", "ADMIN", pwd):
        print(f"Administrador creado: {a.admin}")
    if a.demo:
        demo(conn)
        print(f"Datos demo cargados. Usuarios demo con contraseña '{DEMO_PASSWORD}':")
        for r in conn.execute("SELECT email, rol FROM usuarios ORDER BY rol"):
            print(f"  {r['rol']:9} {r['email']}")
    conn.close()


if __name__ == "__main__":
    main()
