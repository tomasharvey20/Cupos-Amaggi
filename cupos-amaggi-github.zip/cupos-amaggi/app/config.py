"""Configuración del sistema desde el archivo config.env (al lado de iniciar.ps1).

Formato: una línea por valor, CLAVE=valor. Las variables de entorno ya definidas tienen prioridad.
El archivo NO se comparte ni se sube a ningún repositorio: tiene la clave de STOP.
"""
import os
from pathlib import Path

ARCHIVO = Path(__file__).resolve().parent.parent / "config.env"

PLANTILLA = """# Configuración del Sistema de Cupos AMAGGI
# Este archivo tiene datos privados (clave de STOP): no lo compartas.

# CUIT de Amaggi Argentina tal como figura en STOP (11 dígitos, sin guiones).
# Se usa para reconocer los cupos con destinatario Amaggi (stock propio).
AMAGGI_CUIT=

# Conexión con STOP (API para Corredores y Acopiadores):
#   desactivado = no se conecta
#   simulado    = datos de prueba generados por el sistema (no se conecta a STOP)
#   pruebas     = https://demo.ssta.gob.ar/turnos  (necesita clave del entorno de pruebas)
#   produccion  = https://www.ssta.gob.ar/turnos   (necesita la clave real)
STOP_MODO=desactivado

# Clave (secretKey / API KEY) que entrega la Mesa de Ayuda de STOP (sistemadeturnos@cent.gov.ar).
STOP_SECRET_KEY=

# Cada cuántos minutos se sincroniza solo (STOP permite 48 consultas por día: mínimo 30).
# 0 = solo a mano, con el botón "Sincronizar con STOP".
STOP_SYNC_MINUTOS=30
"""


def cargar() -> None:
    if not ARCHIVO.exists():
        ARCHIVO.write_text(PLANTILLA, encoding="utf-8")
    for linea in ARCHIVO.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#") or "=" not in linea:
            continue
        clave, valor = linea.split("=", 1)
        os.environ.setdefault(clave.strip(), valor.strip())


cargar()
