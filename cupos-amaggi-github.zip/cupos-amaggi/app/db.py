"""Base de datos SQLite: conexión y esquema."""
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("CUPOS_DB", BASE_DIR / "data" / "cupos.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
    id            INTEGER PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    nombre        TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    rol           TEXT NOT NULL CHECK (rol IN ('ADMIN','OPERADOR','CLIENTE')),
    cuit          TEXT,              -- solo clientes: CUIT de la contraparte en SIGAM
    activo        INTEGER NOT NULL DEFAULT 1,
    creado        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS sesiones (
    token      TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    expira     TEXT NOT NULL
);

-- Contratos de compra y venta, sincronizados desde SIGAM
CREATE TABLE IF NOT EXISTS contratos (
    id                   INTEGER PRIMARY KEY,
    numero               TEXT NOT NULL,
    tipo                 TEXT NOT NULL CHECK (tipo IN ('COMPRA','VENTA')),
    contraparte_cuit     TEXT,
    contraparte_nombre   TEXT,
    corredor             TEXT,
    operacion            TEXT,
    producto             TEXT NOT NULL,
    cosecha              TEXT,
    toneladas            REAL NOT NULL DEFAULT 0,
    toneladas_entregadas REAL NOT NULL DEFAULT 0,
    fecha_desde          TEXT,
    fecha_hasta          TEXT,
    lugar_entrega        TEXT,
    estado               TEXT NOT NULL DEFAULT 'VIGENTE',
    actualizado          TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (tipo, numero)
);

-- Cupos: origen STOP (destinatario Amaggi, stock propio) o VENTA (de contratos de venta)
CREATE TABLE IF NOT EXISTS cupos (
    id                  INTEGER PRIMARY KEY,
    codigo              TEXT NOT NULL UNIQUE,
    fecha               TEXT NOT NULL,
    destino             TEXT NOT NULL,
    producto            TEXT NOT NULL,
    cosecha             TEXT,
    toneladas           REAL NOT NULL DEFAULT 30,
    origen              TEXT NOT NULL CHECK (origen IN ('STOP','VENTA')),
    destinatario_cuit   TEXT,
    destinatario_nombre TEXT,
    contrato_venta_id   INTEGER REFERENCES contratos(id),
    estado              TEXT NOT NULL DEFAULT 'DISPONIBLE'
                        CHECK (estado IN ('DISPONIBLE','ASIGNADO','UTILIZADO','ANULADO')),
    contrato_compra_id  INTEGER REFERENCES contratos(id),
    solicitud_id        INTEGER REFERENCES solicitudes(id),
    transportista       TEXT,
    patente             TEXT,
    asignado_por        INTEGER REFERENCES usuarios(id),
    asignado_en         TEXT,
    observaciones       TEXT,
    importacion_id      INTEGER REFERENCES importaciones(id),
    creado              TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_cupos_fecha ON cupos(fecha);
CREATE INDEX IF NOT EXISTS ix_cupos_contrato ON cupos(contrato_compra_id);

-- Solicitudes de cupos hechas por clientes sobre sus contratos de compra
CREATE TABLE IF NOT EXISTS solicitudes (
    id                 INTEGER PRIMARY KEY,
    usuario_id         INTEGER NOT NULL REFERENCES usuarios(id),
    contrato_compra_id INTEGER NOT NULL REFERENCES contratos(id),
    fecha              TEXT NOT NULL,
    destino_preferido  TEXT,
    cantidad           INTEGER NOT NULL CHECK (cantidad > 0),
    observaciones      TEXT,
    estado             TEXT NOT NULL DEFAULT 'PENDIENTE'
                       CHECK (estado IN ('PENDIENTE','APROBADA','PARCIAL','RECHAZADA','CANCELADA')),
    cantidad_aprobada  INTEGER NOT NULL DEFAULT 0,
    respuesta          TEXT,
    resuelto_por       INTEGER REFERENCES usuarios(id),
    resuelto_en        TEXT,
    creado             TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS importaciones (
    id           INTEGER PRIMARY KEY,
    tipo         TEXT NOT NULL,      -- STOP | VENTA | SIGAM
    archivo      TEXT,
    total        INTEGER NOT NULL DEFAULT 0,
    insertados   INTEGER NOT NULL DEFAULT 0,
    actualizados INTEGER NOT NULL DEFAULT 0,
    omitidos     INTEGER NOT NULL DEFAULT 0,
    detalle      TEXT,               -- JSON con los motivos de filas omitidas
    usuario_id   INTEGER REFERENCES usuarios(id),
    creado       TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Catálogo de puertos / terminales específicos dentro de cada zona de destino (ej. UPRIVER -> TIMBUES)
CREATE TABLE IF NOT EXISTS puertos (
    id     INTEGER PRIMARY KEY,
    zona   TEXT NOT NULL,
    nombre TEXT NOT NULL,
    activo INTEGER NOT NULL DEFAULT 1,
    creado TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (zona, nombre)
);

-- Trazabilidad: cada evento de un cupo con una FOTO de los contratos de compra y venta en ese momento.
-- Se guardan número y contraparte (no solo el id) para que el registro no cambie aunque después
-- se libere el cupo o se reimporte el contrato.
CREATE TABLE IF NOT EXISTS cupos_historial (
    id                          INTEGER PRIMARY KEY,
    cupo_id                     INTEGER NOT NULL,
    codigo                      TEXT NOT NULL,
    evento                      TEXT NOT NULL,   -- ALTA | ASIGNADO | LIBERADO | UTILIZADO | ANULADO | CTG (TRANSPORTE: histórico)
    creado                      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    usuario_id                  INTEGER REFERENCES usuarios(id),
    fecha_cupo                  TEXT,
    destino                     TEXT,
    producto                    TEXT,
    origen                      TEXT,
    toneladas                   REAL,
    contrato_compra_id          INTEGER,
    contrato_compra_numero      TEXT,
    contrato_compra_contraparte TEXT,
    contrato_venta_id           INTEGER,
    contrato_venta_numero       TEXT,
    contrato_venta_contraparte  TEXT,
    solicitud_id                INTEGER,
    transportista               TEXT,
    patente                     TEXT,
    detalle                     TEXT
);
CREATE INDEX IF NOT EXISTS ix_hist_cupo ON cupos_historial(cupo_id);
CREATE INDEX IF NOT EXISTS ix_hist_codigo ON cupos_historial(codigo);
CREATE INDEX IF NOT EXISTS ix_hist_cc ON cupos_historial(contrato_compra_numero);
CREATE INDEX IF NOT EXISTS ix_hist_cv ON cupos_historial(contrato_venta_numero);

-- Contactos para avisos de cupos: empresa/cliente/corredor con uno o más mails
CREATE TABLE IF NOT EXISTS contactos (
    id           INTEGER PRIMARY KEY,
    tipo         TEXT NOT NULL DEFAULT 'CLIENTE' CHECK (tipo IN ('CLIENTE','CORREDOR','OTRO')),
    empresa      TEXT NOT NULL,                  -- razón social (para corredores: como figura en SIGAM)
    cuit         TEXT,                           -- clientes: CUIT de la contraparte en SIGAM
    nombre       TEXT,                           -- persona de contacto
    email        TEXT NOT NULL COLLATE NOCASE,
    recibe_cupos INTEGER NOT NULL DEFAULT 1,
    activo       INTEGER NOT NULL DEFAULT 1,
    usuario_id   INTEGER REFERENCES usuarios(id), -- si sale de un usuario registrado
    creado       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (tipo, cuit, email)
);

-- Modelos de Carta de Porte: datos fijos + variables {{...}} que se completan por cupo/contrato
CREATE TABLE IF NOT EXISTS cpe_modelos (
    id      INTEGER PRIMARY KEY,
    nombre  TEXT NOT NULL,
    origen  TEXT,                                -- STOP | VENTA | NULL (cualquiera)
    zona    TEXT,                                -- destino (UPRIVER, NECOCHEA…) o NULL
    puerto  TEXT,                                -- puerto específico o NULL
    campos  TEXT NOT NULL,                       -- JSON: [{"seccion","campo","valor"}]
    activo  INTEGER NOT NULL DEFAULT 1,
    creado  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Bandeja de salida: un mail por contrato de compra con los cupos asignados que todavía no se avisaron
CREATE TABLE IF NOT EXISTS envios (
    id                 INTEGER PRIMARY KEY,
    contrato_compra_id INTEGER NOT NULL REFERENCES contratos(id),
    cupo_ids           TEXT NOT NULL DEFAULT '[]',  -- JSON
    estado             TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE','ENVIADO','DESCARTADO')),
    destinatarios      TEXT,                        -- se guarda al enviar
    asunto             TEXT,
    cuerpo_html        TEXT,                        -- copia de lo enviado (para auditoría)
    creado             TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    actualizado        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    enviado_en         TEXT,
    enviado_por        INTEGER REFERENCES usuarios(id)
);

-- Integración con STOP (API para Corredores y Acopiadores)
CREATE TABLE IF NOT EXISTS stop_consultas (       -- para respetar el límite de 48 consultas diarias
    id       INTEGER PRIMARY KEY,
    fecha    TEXT NOT NULL DEFAULT (date('now','localtime')),
    creado   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    recurso  TEXT NOT NULL,                        -- auths | misturnosactivos | terminales | especies
    ok       INTEGER NOT NULL,
    detalle  TEXT
);
CREATE TABLE IF NOT EXISTS stop_terminales (      -- terminal de STOP -> destino (zona) y puerto nuestros
    id_terminal INTEGER PRIMARY KEY,
    descripcion TEXT,
    localidad   TEXT,
    provincia   TEXT,
    zona        TEXT,
    puerto      TEXT,
    editado     INTEGER NOT NULL DEFAULT 0,        -- 1 = zona/puerto cargados a mano (no se pisan)
    actualizado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS stop_especies (        -- código de grano de STOP -> producto nuestro
    cod_grano   INTEGER PRIMARY KEY,
    nombre      TEXT,
    producto    TEXT,
    actualizado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS stop_turnos (          -- último dato recibido de STOP por cada turno (cupo)
    codigo            TEXT PRIMARY KEY,
    id_terminal       INTEGER,
    fecha             TEXT,
    cuit_destinatario TEXT,
    es_amaggi         INTEGER,                      -- 1 = destinatario Amaggi (stock propio)
    cupo_id           INTEGER,                      -- cupo nuestro vinculado (si hay)
    estado            TEXT,
    ctg               TEXT,
    datos             TEXT,                         -- JSON completo recibido
    actualizado       TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS auditoria (
    id         INTEGER PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    accion     TEXT NOT NULL,
    entidad    TEXT,
    entidad_id INTEGER,
    detalle    TEXT,
    creado     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
"""


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    # autocommit + transacciones explícitas. FastAPI puede resolver dependencias y endpoint en
    # hilos distintos del pool; la conexión es de un solo request, así que es seguro compartirla.
    conn = sqlite3.connect(DB_PATH, isolation_level=None, check_same_thread=False, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection):
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def init_db() -> None:
    conn = connect()
    try:
        conn.executescript(SCHEMA)
        # Migraciones: columnas agregadas después de la primera versión
        existentes = {r["name"] for r in conn.execute("PRAGMA table_info(contratos)")}
        for col in ("corredor", "operacion", "lugar_detalle"):
            if col not in existentes:
                conn.execute(f"ALTER TABLE contratos ADD COLUMN {col} TEXT")
        # Puerto específico del cupo: "puerto" si vino informado en el cupo (STOP / comprador),
        # "puerto_asignado" si lo eligió Amaggi al asignar (se borra al liberar).
        cols_cupos = {r["name"] for r in conn.execute("PRAGMA table_info(cupos)")}
        # ctg = Código de Trazabilidad de Granos (12 dígitos) de la Carta de Porte Electrónica (ARCA)
        # carta_porte / stop_*: datos que informa STOP (estado del turno, terminal, última actualización)
        for col in ("puerto", "puerto_asignado", "ctg", "carta_porte", "stop_estado", "stop_id_terminal", "stop_actualizado"):
            if col not in cols_cupos:
                conn.execute(f"ALTER TABLE cupos ADD COLUMN {col} TEXT")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_cupos_ctg ON cupos(ctg) WHERE ctg IS NOT NULL")
        cols_hist = {r["name"] for r in conn.execute("PRAGMA table_info(cupos_historial)")}
        for col in ("puerto", "ctg"):
            if col not in cols_hist:
                conn.execute(f"ALTER TABLE cupos_historial ADD COLUMN {col} TEXT")
        _historial_inicial(conn)
        _unificar_zonas(conn)
        # Nombre unificado de producto (antes "GIRASOL ALTO OLEICO")
        for tabla in ("contratos", "cupos", "cupos_historial"):
            conn.execute(f"UPDATE {tabla} SET producto='GIRASOL OLEICO' WHERE producto='GIRASOL ALTO OLEICO'")
        from . import avisos  # modelos de Carta de Porte iniciales y contactos de los clientes registrados
        avisos.inicializar(conn)
    finally:
        conn.close()


def _unificar_zonas(conn):
    """Pasa los datos existentes a las zonas de app/zonas.py (ej. ROSARIO, TIMBUES -> UPRIVER).
    El destino original queda como puerto del cupo / lugar_detalle del contrato. Se puede correr
    siempre: si ya está todo unificado no cambia nada."""
    from . import zonas
    # Terminales cuyo nombre es una localidad de otra zona (ej. RAMALLO cargado en BAHIA BLANCA):
    # la terminal y sus cupos pasan a la zona correcta.
    for zona_actual, nombre in conn.execute("SELECT zona, nombre FROM puertos").fetchall():
        zona = zonas.zona_de(nombre)
        if zona and zona != zona_actual:
            conn.execute("UPDATE OR IGNORE puertos SET zona = ? WHERE zona = ? AND nombre = ?", (zona, zona_actual, nombre))
            conn.execute("DELETE FROM puertos WHERE zona = ? AND nombre = ?", (zona_actual, nombre))
            conn.execute("UPDATE cupos SET destino = ? WHERE destino = ? AND COALESCE(puerto, puerto_asignado) = ?",
                         (zona, zona_actual, nombre))
            conn.execute("UPDATE cupos_historial SET destino = ? WHERE destino = ? AND puerto = ?", (zona, zona_actual, nombre))
    cambios = {}
    for tabla, col in (("cupos", "destino"), ("cupos_historial", "destino"), ("contratos", "lugar_entrega"), ("puertos", "zona")):
        for (valor,) in conn.execute(f"SELECT DISTINCT {col} FROM {tabla} WHERE {col} IS NOT NULL").fetchall():
            zona, detalle = zonas.normalizar(valor)
            if zona != valor:
                cambios.setdefault((tabla, col), []).append((valor, zona, detalle))
    if not cambios:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        for (tabla, col), lista in cambios.items():
            for valor, zona, detalle in lista:
                if tabla == "cupos":
                    # el destino original pasa a ser el puerto (si el cupo no tenía uno)
                    conn.execute("UPDATE cupos SET puerto = COALESCE(puerto, ?), destino = ? WHERE destino = ?",
                                 (detalle, zona, valor))
                    if detalle:
                        conn.execute("INSERT OR IGNORE INTO puertos (zona, nombre) VALUES (?, ?)", (zona, detalle))
                elif tabla == "cupos_historial":
                    conn.execute("UPDATE cupos_historial SET puerto = COALESCE(puerto, ?), destino = ? WHERE destino = ?",
                                 (detalle, zona, valor))
                elif tabla == "contratos":
                    conn.execute("UPDATE contratos SET lugar_detalle = COALESCE(lugar_detalle, ?), lugar_entrega = ? "
                                 "WHERE lugar_entrega = ?", (detalle, zona, valor))
                else:  # puertos: se mueven a la zona; si ya existía allí, se descarta el duplicado
                    conn.execute("UPDATE OR IGNORE puertos SET zona = ? WHERE zona = ?", (zona, valor))
                    conn.execute("DELETE FROM puertos WHERE zona = ?", (valor,))
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def _historial_inicial(conn):
    """Para cupos cargados antes de que existiera la trazabilidad: crea su ALTA y, si están
    asignados o utilizados, el evento ASIGNADO con la fecha en que se asignaron."""
    sin = [r[0] for r in conn.execute(
        "SELECT id FROM cupos WHERE id NOT IN (SELECT cupo_id FROM cupos_historial)")]
    if not sin:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        for i in range(0, len(sin), 500):
            lote = sin[i:i + 500]
            marks = ",".join("?" * len(lote))
            _insert_historial(conn, f"cu.id IN ({marks})", lote, "ALTA", None,
                              "Registrado al activar la trazabilidad", creado="cu.creado", sin_compra=True)
            _insert_historial(conn, f"cu.id IN ({marks}) AND cu.contrato_compra_id IS NOT NULL", lote,
                              "ASIGNADO", None, "Registrado al activar la trazabilidad",
                              creado="COALESCE(cu.asignado_en, cu.creado)", usuario="cu.asignado_por")
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def _insert_historial(conn, where, params, evento, usuario_id, detalle, creado=None, usuario=None, sin_compra=False):
    compra = "NULL, NULL, NULL" if sin_compra else "cc.id, cc.numero, cc.contraparte_nombre"
    conn.execute(
        f"""INSERT INTO cupos_historial
              (cupo_id, codigo, evento, creado, usuario_id, fecha_cupo, destino, puerto, producto, origen, toneladas,
               contrato_compra_id, contrato_compra_numero, contrato_compra_contraparte,
               contrato_venta_id, contrato_venta_numero, contrato_venta_contraparte,
               solicitud_id, transportista, patente, ctg, detalle)
            SELECT cu.id, cu.codigo, ?, {creado or "datetime('now','localtime')"}, {usuario or "?"},
                   cu.fecha, cu.destino, COALESCE(cu.puerto, cu.puerto_asignado), cu.producto, cu.origen, cu.toneladas,
                   {compra}, cv.id, cv.numero, cv.contraparte_nombre,
                   cu.solicitud_id, cu.transportista, cu.patente, cu.ctg, ?
            FROM cupos cu
            LEFT JOIN contratos cc ON cc.id = cu.contrato_compra_id
            LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE {where}""",
        (evento, *([] if usuario else [usuario_id]), detalle, *params))


def historial(conn, cupo_ids, evento: str, usuario_id, detalle: str | None = None):
    """Registra un evento para los cupos dados, con la foto actual de sus contratos de compra y venta.
    Llamar DESPUÉS de asignar/marcar y ANTES de liberar (para que quede el contrato que se libera)."""
    ids = list(cupo_ids)
    for i in range(0, len(ids), 500):
        lote = ids[i:i + 500]
        _insert_historial(conn, f"cu.id IN ({','.join('?' * len(lote))})", lote, evento, usuario_id, detalle)


def get_conn():
    """Dependencia de FastAPI: una conexión por request."""
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()


def rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


def audit(conn, usuario_id, accion, entidad=None, entidad_id=None, detalle=None):
    conn.execute(
        "INSERT INTO auditoria (usuario_id, accion, entidad, entidad_id, detalle) VALUES (?,?,?,?,?)",
        (usuario_id, accion, entidad, entidad_id, detalle),
    )
