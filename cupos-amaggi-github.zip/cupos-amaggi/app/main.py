"""API del Sistema de Cupos Amaggi."""
import csv
import io
import json
import re
import urllib.error

from fastapi import Depends, FastAPI, File, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config  # noqa: F401  (primero: carga config.env antes que el resto lea la configuración)
from . import avisos, connectors, importers, services, stop, zonas
from .db import BASE_DIR, audit, get_conn, historial, init_db, rows, transaction
from .security import (SESSION_COOKIE, SESSION_HOURS, admin, create_session, current_user, hash_password,
                       staff, verify_password)
from .services import CONTRATO_SELECT, CONTRATO_VENTA_SELECT, ESTADO_VISIBLE, ReglaError

app = FastAPI(title="Sistema de Cupos Amaggi", version="1.0")
STATIC = BASE_DIR / "static"


@app.on_event("startup")
def _startup():
    init_db()
    stop.iniciar_automatico()  # sincronización con STOP cada STOP_SYNC_MINUTOS (si está configurada)


@app.middleware("http")
async def _sin_cache(request: Request, call_next):
    """El navegador revalida la página y los archivos de la app en cada carga,
    así después de una actualización nadie queda usando una versión vieja."""
    response = await call_next(request)
    if request.url.path == "/" or request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-cache"
    return response


@app.exception_handler(ReglaError)
async def _regla(_, exc: ReglaError):
    return JSONResponse({"detail": str(exc)}, status_code=400)


@app.exception_handler(importers.ImportError_)
async def _imp(_, exc):
    return JSONResponse({"detail": str(exc)}, status_code=400)


# ---------------------------------------------------------------- auth
class LoginIn(BaseModel):
    email: str
    password: str


@app.post("/api/login")
def login(data: LoginIn, response: Response, request: Request, conn=Depends(get_conn)):
    u = conn.execute("SELECT * FROM usuarios WHERE email=?", (data.email.strip(),)).fetchone()
    if not u or not u["activo"] or not verify_password(data.password, u["password_hash"]):
        raise HTTPException(401, "Email o contraseña incorrectos")
    token = create_session(conn, u["id"])
    response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="lax",
                        secure=request.url.scheme == "https", max_age=SESSION_HOURS * 3600)
    return {"id": u["id"], "nombre": u["nombre"], "rol": u["rol"]}


@app.post("/api/logout")
def logout(request: Request, response: Response, conn=Depends(get_conn)):
    conn.execute("DELETE FROM sesiones WHERE token=?", (request.cookies.get(SESSION_COOKIE, ""),))
    response.delete_cookie(SESSION_COOKIE)
    return {"ok": True}


@app.get("/api/me")
def me(user=Depends(current_user)):
    return {k: user[k] for k in ("id", "email", "nombre", "rol", "cuit")}


# ---------------------------------------------------------------- tablero
# Orden fijo de los destinos en el Tablero (los demás van después)
PUERTOS_TABLERO = ["UPRIVER", "TLP", "BUENOS AIRES", "NECOCHEA", "BAHIA BLANCA"]


@app.get("/api/tablero")
def tablero(producto: str | None = None, desde: str | None = None, hasta: str | None = None,
            user=Depends(staff), conn=Depends(get_conn)):
    """Indicadores por puerto/destino (UPRIVER, TLP, NECOCHEA, BAHIA BLANCA y cualquier otro con cupos),
    opcionalmente de un solo producto y de un rango de fechas de cupo (un día o una semana).
    Estado visible: un DISPONIBLE con fecha pasada cuenta como VENCIDO."""
    cond, params = [], []
    if producto:
        cond.append("cu.producto = ?")
        params.append(producto)
    if desde:
        cond.append("cu.fecha >= ?")
        params.append(desde)
    if hasta:
        cond.append("cu.fecha <= ?")
        params.append(hasta)
    where = (" WHERE " + " AND ".join(cond)) if cond else ""
    # Por destino, origen, estado y terminal (la del cupo o la elegida al asignar; "" = sin terminal)
    por_destino = rows(conn.execute(
        f"""SELECT cu.destino, COALESCE(cu.puerto, cu.puerto_asignado, '') AS terminal,
                   cu.origen, {ESTADO_VISIBLE} AS estado, COUNT(*) AS n
            FROM cupos cu{where} GROUP BY 1, 2, 3, 4""", params))
    productos = importers.catalogo_productos([r[0] for r in conn.execute("SELECT DISTINCT producto FROM cupos")])
    # Solicitudes abiertas de clientes por puerto (destino preferido, unificado en zonas),
    # con los mismos filtros de producto (del contrato) y fecha pedida
    scond, sparams = ["s.estado IN ('PENDIENTE','PARCIAL')"], []
    for col, op, val in (("c.producto", "=", producto), ("s.fecha", ">=", desde), ("s.fecha", "<=", hasta)):
        if val:
            scond.append(f"{col} {op} ?")
            sparams.append(val)
    sol_destino: dict[str, dict] = {}
    for r in conn.execute(
            f"""SELECT s.destino_preferido, COUNT(*) AS n, COALESCE(SUM(s.cantidad - s.cantidad_aprobada), 0) AS cupos
                FROM solicitudes s JOIN contratos c ON c.id = s.contrato_compra_id
                WHERE {" AND ".join(scond)} GROUP BY 1""", sparams):
        zona = zonas.normalizar(r["destino_preferido"])[0] if r["destino_preferido"] else "SIN DESTINO"
        x = sol_destino.setdefault(zona or "SIN DESTINO", {"n": 0, "cupos": 0})
        x["n"] += r["n"]
        x["cupos"] += r["cupos"]
    pendientes = (sum(x["n"] for x in sol_destino.values()), sum(x["cupos"] for x in sol_destino.values()))
    # Destinos: SIEMPRE todos, tengan o no cupos — la columna DESTINO de los contratos de COMPRA de SIGAM
    # (de todos los productos, ordenados por cantidad de contratos), las zonas fijas (ej. TLP), las zonas del
    # catálogo de terminales y cualquier otro destino con cupos o solicitudes.
    destinos = list(PUERTOS_TABLERO)
    destinos += [r[0] for r in conn.execute(
        """SELECT lugar_entrega FROM contratos WHERE tipo='COMPRA' AND COALESCE(lugar_entrega,'') <> ''
           GROUP BY 1 ORDER BY COUNT(*) DESC, 1""") if r[0] not in destinos]
    extra = ({r[0] for r in conn.execute("SELECT DISTINCT zona FROM puertos WHERE activo=1")}
             | {r["destino"] for r in por_destino} | set(sol_destino))
    destinos += sorted(extra - set(destinos) - {"SIN DESTINO", "", None})
    # Contratos de compra por destino (del producto elegido)
    contratos_destino = {r[0]: r[1] for r in conn.execute(
        f"""SELECT lugar_entrega, COUNT(*) FROM contratos WHERE tipo='COMPRA'
            {"AND producto = ?" if producto else ""} GROUP BY 1""", [producto] if producto else [])}
    # Terminales del catálogo por zona: se muestran en el desplegable aunque no tengan cupos
    terminales_zona: dict[str, list[str]] = {}
    for z, nombre in conn.execute("SELECT zona, nombre FROM puertos WHERE activo=1 ORDER BY nombre"):
        terminales_zona.setdefault(z, []).append(nombre)
    # Cupos NO ACTIVADOS: asignados a un contrato de compra, sin CTG y sin estado de activación en STOP,
    # de ayer en adelante (hay que pedirle al cliente que emita la Carta de Porte).
    no_activados = rows(conn.execute(
        f"""SELECT cu.id, cu.codigo, cu.fecha, cu.destino, COALESCE(cu.puerto, cu.puerto_asignado) AS puerto,
                   cu.producto, cu.origen, cu.ctg, cu.stop_estado, cu.estado, cc.id AS contrato_id, cc.numero AS contrato,
                   cc.contraparte_nombre AS vendedor, cc.corredor, cv.numero AS contrato_venta
            FROM cupos cu
            JOIN contratos cc ON cc.id = cu.contrato_compra_id
            LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE cu.estado = 'ASIGNADO' AND cu.ctg IS NULL
              AND COALESCE(cu.stop_estado, '') NOT IN ('ACTIVADO','ARRIBADO','DESCARGADO')
              AND cu.fecha >= date('now','localtime','-1 day')
              {"".join(" AND " + c for c in cond)}
            ORDER BY cu.fecha, cu.destino, cc.contraparte_nombre, cu.codigo""", params))
    # ¿se le avisó al cliente? (bandeja de envíos)
    aviso = {}
    for e in conn.execute("SELECT estado, cupo_ids FROM envios WHERE estado IN ('PENDIENTE','ENVIADO') ORDER BY id"):
        for cid in json.loads(e["cupo_ids"]):
            aviso[cid] = e["estado"]
    for r in no_activados:
        r["aviso"] = aviso.get(r["id"])
    return {"destinos": destinos, "contratos_destino": contratos_destino, "terminales_zona": terminales_zona,
            "por_destino": por_destino, "productos": productos,
            "solicitudes_pendientes": pendientes[0], "cupos_pedidos_pendientes": pendientes[1],
            "solicitudes_por_destino": sol_destino,
            "no_activados": no_activados}


# ---------------------------------------------------------------- planilla de asignación
def _semana(conn, semana: str | None) -> tuple[str, str]:
    ref = importers.parse_date(semana) if semana else None
    return conn.execute(
        "SELECT date(COALESCE(?, date('now','localtime')), 'weekday 0', '-6 days'), "
        "       date(COALESCE(?, date('now','localtime')), 'weekday 0')", (ref, ref)).fetchone()


@app.get("/api/planilla")
def planilla(producto: str | None = None, destino: str | None = None, origen: str | None = None,
             contrato_venta_id: int | None = None, puerto: str | None = None,
             semana: str | None = None, q: str | None = None, todos: bool = False, estado: str | None = None,
             con_asignados: bool = False,
             user=Depends(staff), conn=Depends(get_conn)):
    """Grilla semanal: cupos disponibles por día (con los filtros) y contratos de compra del producto.
    Contratos que se muestran: vigentes con saldo para al menos un cupo y período de entrega que se
    superpone con la semana (o todos con saldo si todos=true, o los que coinciden con q),
    más los que ya tienen cupos asignados en la semana."""
    desde, hasta = _semana(conn, semana)
    # Productos y destinos con cupos en la semana (para los filtros)
    productos = rows(conn.execute(
        """SELECT producto, COUNT(CASE WHEN estado='DISPONIBLE' THEN 1 END) AS disponibles, COUNT(*) AS total
           FROM cupos WHERE fecha BETWEEN ? AND ? AND estado <> 'ANULADO' GROUP BY producto ORDER BY producto""",
        (desde, hasta)))
    # Todos los productos del catálogo en el filtro (con 0 si no tienen cupos esa semana)
    con_cupos = {p["producto"]: p for p in productos}
    productos = [con_cupos.get(p, {"producto": p, "disponibles": 0, "total": 0})
                 for p in importers.catalogo_productos(con_cupos)]
    if not producto:
        con_disp = [p for p in productos if p["disponibles"]] or productos
        producto = con_disp[0]["producto"] if con_disp else None
    base = {"desde": desde, "hasta": hasta, "producto": producto, "productos": productos,
            "destinos": [], "dias": [], "contratos": []}
    if not producto:
        return base
    base["destinos"] = rows(conn.execute(
        """SELECT destino, COUNT(CASE WHEN estado='DISPONIBLE' THEN 1 END) AS disponibles, COUNT(*) AS total
           FROM cupos WHERE fecha BETWEEN ? AND ? AND producto=? AND estado <> 'ANULADO'
           GROUP BY destino ORDER BY destino""", (desde, hasta, producto)))

    filtro, fparams = ["cu.producto = ?"], [producto]
    if destino:
        filtro.append("cu.destino = ?")
        fparams.append(destino)
    if origen:
        filtro.append("cu.origen = ?")
        fparams.append(origen)
    # Contratos de venta que aportan cupos esta semana (para el filtro cuando el origen es VENTA)
    base["ventas"] = rows(conn.execute(
        f"""SELECT cv.id, cv.numero, cv.contraparte_nombre, cv.corredor,
                   COUNT(CASE WHEN cu.estado='DISPONIBLE' THEN 1 END) AS disponibles, COUNT(*) AS total
            FROM cupos cu JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE cu.fecha BETWEEN ? AND ? AND cu.estado <> 'ANULADO' AND cu.producto = ?
              {"AND cu.destino = ?" if destino else ""}
            GROUP BY cv.id ORDER BY cv.contraparte_nombre, cv.numero""", (desde, hasta, producto, *([destino] if destino else []))))
    # ... y sus cupos por día (para la grilla de contratos de venta)
    base["ventas_dias"] = rows(conn.execute(
        f"""SELECT cu.contrato_venta_id, cu.fecha, COUNT(*) AS total,
                   COUNT(CASE WHEN cu.estado IN ('ASIGNADO','UTILIZADO') THEN 1 END) AS asignados,
                   COUNT(CASE WHEN cu.estado='DISPONIBLE' THEN 1 END)                AS disponibles
            FROM cupos cu
            WHERE cu.contrato_venta_id IS NOT NULL AND cu.fecha BETWEEN ? AND ? AND cu.estado <> 'ANULADO'
              AND cu.producto = ? {"AND cu.destino = ?" if destino else ""}
            GROUP BY cu.contrato_venta_id, cu.fecha""", (desde, hasta, producto, *([destino] if destino else []))))
    if contrato_venta_id:
        filtro.append("cu.contrato_venta_id = ?")
        fparams.append(contrato_venta_id)
    # Puertos del destino elegido (catálogo activo) y filtro por puerto: muestra los cupos de ese puerto
    # (informado en el cupo o asignado) más los disponibles que no tienen puerto todavía.
    base["puertos"] = [r[0] for r in conn.execute(
        "SELECT nombre FROM puertos WHERE zona = ? AND activo = 1 ORDER BY nombre", ((destino or "").upper(),))] if destino else []
    # Disponibilidad por terminal y día (con los filtros elegidos, sin el de puerto): para elegir
    # a qué terminal asignar cada contrato. "" = cupos sin terminal informada (sirven para cualquiera).
    # Por zona (destino) y terminal: se elige terminal por contrato aunque no haya un destino filtrado.
    term: dict[tuple, dict] = {}
    for r in conn.execute(
            f"""SELECT cu.destino AS d, COALESCE(cu.puerto, '') AS t, cu.fecha, COUNT(*) AS n FROM cupos cu
                WHERE cu.estado='DISPONIBLE' AND cu.fecha BETWEEN ? AND ? AND {' AND '.join(filtro)}
                GROUP BY 1, 2, 3""", (desde, hasta, *fparams)):
        x = term.setdefault((r["d"], r["t"]), {"destino": r["d"], "terminal": r["t"], "disponibles": 0, "dias": {}})
        x["disponibles"] += r["n"]
        x["dias"][r["fecha"]] = r["n"]
    for zona, nombre in conn.execute(
            "SELECT zona, nombre FROM puertos WHERE activo = 1" + (" AND zona = ?" if destino else ""),
            ((destino or "").upper(),) if destino else ()):
        term.setdefault((zona, nombre), {"destino": zona, "terminal": nombre, "disponibles": 0, "dias": {}})
    base["terminales"] = sorted(term.values(), key=lambda x: (x["destino"], x["terminal"] == "", -x["disponibles"], x["terminal"]))
    if puerto:
        filtro.append("""(COALESCE(cu.puerto, cu.puerto_asignado) = ?
                          OR (cu.puerto IS NULL AND cu.puerto_asignado IS NULL AND cu.estado = 'DISPONIBLE'))""")
        fparams.append(puerto)
    where = " AND ".join(filtro)
    por_dia = {r["fecha"]: r for r in rows(conn.execute(
        f"""SELECT cu.fecha,
                   COUNT(CASE WHEN cu.estado='DISPONIBLE' THEN 1 END)                AS disponibles,
                   COUNT(CASE WHEN cu.estado IN ('ASIGNADO','UTILIZADO') THEN 1 END) AS asignados
            FROM cupos cu WHERE cu.fecha BETWEEN ? AND ? AND cu.estado <> 'ANULADO' AND {where}
            GROUP BY cu.fecha""", (desde, hasta, *fparams)))}
    dias = conn.execute(
        "WITH RECURSIVE d(x) AS (SELECT ? UNION ALL SELECT date(x,'+1 day') FROM d WHERE x < ?) SELECT x FROM d",
        (desde, hasta)).fetchall()
    hoy = services.hoy()
    base["dias"] = [{"fecha": d[0], "pasado": d[0] < hoy,
                     "disponibles": por_dia.get(d[0], {}).get("disponibles", 0),
                     "asignados": por_dia.get(d[0], {}).get("asignados", 0)} for d in dias]

    # Cupos ya asignados en la semana, por contrato y día (con los mismos filtros)
    ya = rows(conn.execute(
        f"""SELECT cu.contrato_compra_id AS contrato_id, cu.fecha, COUNT(*) AS n
            FROM cupos cu WHERE cu.fecha BETWEEN ? AND ? AND cu.estado IN ('ASIGNADO','UTILIZADO') AND {where}
            GROUP BY cu.contrato_compra_id, cu.fecha""", (desde, hasta, *fparams)))
    ids_con_asig = {r["contrato_id"] for r in ya}

    cwhere, cparams = ["c.tipo='COMPRA'", "c.producto = ?"], [producto]
    if q:
        cwhere.append("(c.numero LIKE ? OR c.contraparte_nombre LIKE ? OR c.contraparte_cuit LIKE ?)")
        cparams += [f"%{q}%"] * 3
    contratos = rows(conn.execute(
        CONTRATO_SELECT + " WHERE " + " AND ".join(cwhere) + " GROUP BY c.id", cparams))
    tn = importers.TONELADAS_POR_CUPO

    # Estado de entrega del contrato HOY (mismos colores que la grilla):
    #   vig = dentro del período, ven = pasó el fin de entrega, fue = la entrega todavía no empieza
    def estado_entrega(c):
        if c["fecha_hasta"] and hoy > c["fecha_hasta"]:
            return "ven"
        if c["fecha_desde"] and hoy < c["fecha_desde"]:
            return "fue"
        return "vig"

    estados = {e for e in (estado or "").split(",") if e in ("vig", "ven", "fue")}

    def visible(c):
        if estados and estado_entrega(c) not in estados:
            return False
        if con_asignados:  # solo los que ya tienen cupos asignados esta semana (con los filtros elegidos)
            return c["id"] in ids_con_asig
        if c["id"] in ids_con_asig:
            return True
        if c["estado"] != "VIGENTE" or c["saldo"] < tn:
            return False
        if q or todos or estados:  # filtrando por color se muestran todos los de ese estado con saldo
            return True
        return (not c["fecha_desde"] or c["fecha_desde"] <= hasta) and (not c["fecha_hasta"] or c["fecha_hasta"] >= desde)

    sel = [c for c in contratos if visible(c)]
    base["por_estado"] = {k: 0 for k in ("vig", "ven", "fue")}
    for c in contratos:  # cantidad de contratos con saldo por color (para las casillas del filtro)
        if c["estado"] == "VIGENTE" and c["saldo"] >= tn:
            base["por_estado"][estado_entrega(c)] += 1
    # Orden: los que ya tienen cupos esta semana, después los que entregan en el destino filtrado,
    # después por vencimiento de entrega.
    dest = (destino or "").upper()
    sel.sort(key=lambda c: (c["id"] not in ids_con_asig,
                            bool(dest) and (c["lugar_entrega"] or "").upper() != dest,
                            c["fecha_hasta"] or "9999", c["numero"]))
    total = len(sel)
    sel = sel[:300]
    # Puerto sugerido por contrato: el último usado con ese contrato en el destino, o su lugar de entrega
    # si figura en el catálogo de puertos del destino.
    ultimos = {}
    if sel:
        ids = [c["id"] for c in sel]
        for r in conn.execute(
                f"""SELECT contrato_compra_id, COALESCE(puerto, puerto_asignado) AS p FROM cupos
                    WHERE contrato_compra_id IN ({",".join("?" * len(ids))}) {"AND destino = ?" if destino else ""}
                      AND COALESCE(puerto, puerto_asignado) IS NOT NULL ORDER BY asignado_en""",
                (*ids, *([destino] if destino else []))):
            ultimos[r["contrato_compra_id"]] = r["p"]
    catalogo = {(t["destino"], t["terminal"]) for t in base["terminales"]}
    for c in sel:
        c["ya"] = {r["fecha"]: r["n"] for r in ya if r["contrato_id"] == c["id"]}
        lugar = (c["lugar_detalle"] or c["lugar_entrega"] or "").upper()  # ej. TIMBUES dentro de UPRIVER
        c["puerto_sugerido"] = puerto or ultimos.get(c["id"]) or (lugar if (c["lugar_entrega"], lugar) in catalogo else None)
    base.update(contratos=sel, contratos_total=total, toneladas_por_cupo=tn)
    return base


class PlanillaItem(BaseModel):
    contrato_id: int
    fecha: str
    cantidad: int = Field(gt=0, le=500)
    puerto: str | None = None
    destino: str | None = None   # zona de donde tomar los cupos para este contrato (vista por contrato)


class PlanillaIn(BaseModel):
    producto: str | None = None
    destino: str | None = None
    origen: str | None = None
    contrato_venta_id: int | None = None
    items: list[PlanillaItem]


@app.post("/api/planilla/asignar")
def planilla_asignar(data: PlanillaIn, user=Depends(staff), conn=Depends(get_conn)):
    return services.asignar_planilla(conn, user, data.producto, data.destino or None, data.origen or None,
                                     [i.model_dump() for i in data.items], data.contrato_venta_id)


# ---------------------------------------------------------------- contactos (mails de clientes y corredores)
@app.get("/api/contactos")
def listar_contactos(tipo: str | None = None, q: str | None = None, user=Depends(staff), conn=Depends(get_conn)):
    where, params = [], []
    if tipo:
        where.append("c.tipo = ?")
        params.append(tipo)
    if q:
        where.append("(c.empresa LIKE ? OR c.email LIKE ? OR c.nombre LIKE ? OR c.cuit LIKE ?)")
        params += [f"%{q}%"] * 4
    return rows(conn.execute(
        f"""SELECT c.*, u.email AS usuario_email FROM contactos c LEFT JOIN usuarios u ON u.id = c.usuario_id
            {"WHERE " + " AND ".join(where) if where else ""} ORDER BY c.tipo, c.empresa, c.email""", params))


@app.get("/api/contactos/empresas")
def empresas_contactos(tipo: str = "CLIENTE", q: str | None = None, user=Depends(staff), conn=Depends(get_conn)):
    """Sugerencias para cargar un contacto: clientes (contrapartes de contratos de compra, con CUIT) o corredores."""
    like = f"%{q or ''}%"
    if tipo == "CORREDOR":
        return [{"empresa": r[0], "cuit": None} for r in conn.execute(
            "SELECT DISTINCT corredor FROM contratos WHERE corredor LIKE ? AND corredor <> '' ORDER BY 1 LIMIT 30", (like,))]
    return [{"empresa": r[0], "cuit": r[1] or None} for r in conn.execute(
        """SELECT contraparte_nombre, MAX(contraparte_cuit) FROM contratos WHERE tipo='COMPRA'
           AND (contraparte_nombre LIKE ? OR contraparte_cuit LIKE ?) AND contraparte_nombre <> ''
           GROUP BY contraparte_nombre ORDER BY 1 LIMIT 30""", (like, like))]


class ContactoIn(BaseModel):
    tipo: str = "CLIENTE"
    empresa: str
    cuit: str | None = None
    nombre: str | None = None
    email: str
    recibe_cupos: bool = True
    activo: bool = True


def _validar_contacto(data: ContactoIn) -> dict:
    tipo = data.tipo.upper()
    if tipo not in ("CLIENTE", "CORREDOR", "OTRO"):
        raise ReglaError("Tipo inválido")
    email = data.email.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ReglaError(f"Mail inválido: {data.email}")
    cuit = importers.cuit_digits(data.cuit)
    if cuit and len(cuit) != 11:
        raise ReglaError("El CUIT debe tener 11 dígitos (o dejalo vacío: se asocia por razón social)")
    if not data.empresa.strip():
        raise ReglaError("Indicá la empresa (razón social como figura en los contratos)")
    return {"tipo": tipo, "empresa": data.empresa.strip().upper(), "cuit": cuit or None, "nombre": (data.nombre or "").strip() or None,
            "email": email, "recibe_cupos": int(data.recibe_cupos), "activo": int(data.activo)}


@app.post("/api/contactos")
def crear_contacto(data: ContactoIn, user=Depends(staff), conn=Depends(get_conn)):
    v = _validar_contacto(data)
    if conn.execute("SELECT 1 FROM contactos WHERE email=? AND COALESCE(cuit,'')=COALESCE(?,'') AND UPPER(empresa)=?",
                    (v["email"], v["cuit"], v["empresa"])).fetchone():
        raise ReglaError("Ese mail ya está cargado para esa empresa")
    cur = conn.execute(f"INSERT INTO contactos ({', '.join(v)}) VALUES ({', '.join('?' * len(v))})", tuple(v.values()))
    audit(conn, user["id"], "CREAR_CONTACTO", "contacto", cur.lastrowid, f"{v['empresa']} · {v['email']}")
    return {"id": cur.lastrowid}


@app.put("/api/contactos/{cid}")
def editar_contacto(cid: int, data: ContactoIn, user=Depends(staff), conn=Depends(get_conn)):
    actual = conn.execute("SELECT * FROM contactos WHERE id=?", (cid,)).fetchone()
    if not actual:
        raise HTTPException(404, "Contacto inexistente")
    v = _validar_contacto(data)
    if actual["usuario_id"]:  # los datos de un usuario registrado se cambian desde Usuarios
        v = {"recibe_cupos": v["recibe_cupos"], "activo": v["activo"]}
    conn.execute(f"UPDATE contactos SET {', '.join(f'{k}=?' for k in v)} WHERE id=?", (*v.values(), cid))
    audit(conn, user["id"], "EDITAR_CONTACTO", "contacto", cid)
    return {"ok": True}


# ---------------------------------------------------------------- modelos de Carta de Porte
@app.get("/api/cpe-modelos")
def listar_modelos(user=Depends(staff), conn=Depends(get_conn)):
    data = rows(conn.execute("SELECT * FROM cpe_modelos ORDER BY activo DESC, origen, zona, puerto, nombre"))
    for m in data:
        m["campos"] = json.loads(m["campos"])
    return {"modelos": data, "variables": avisos.VARIABLES}


class ModeloIn(BaseModel):
    nombre: str
    origen: str | None = None
    zona: str | None = None
    puerto: str | None = None
    campos: list[dict]
    activo: bool = True


def _modelo_vals(data: ModeloIn) -> dict:
    if not data.nombre.strip():
        raise ReglaError("Poné un nombre al modelo")
    campos = [{"seccion": (c.get("seccion") or "General").strip(), "campo": (c.get("campo") or "").strip(),
               "valor": (c.get("valor") or "").strip()} for c in data.campos if (c.get("campo") or "").strip()]
    if not campos:
        raise ReglaError("El modelo necesita al menos un campo")
    desconocidas = {v for c in campos for v in re.findall(r"\{\{\s*(\w+)\s*\}\}", c["valor"])} - set(avisos.VARIABLES)
    if desconocidas:
        raise ReglaError("Variables desconocidas: " + ", ".join("{{" + v + "}}" for v in sorted(desconocidas)))
    return {"nombre": data.nombre.strip(), "origen": (data.origen or "").upper() or None,
            "zona": zonas.normalizar(data.zona)[0] if data.zona else None,
            "puerto": (data.puerto or "").strip().upper() or None,
            "campos": json.dumps(campos, ensure_ascii=False), "activo": int(data.activo)}


@app.post("/api/cpe-modelos")
def crear_modelo(data: ModeloIn, user=Depends(staff), conn=Depends(get_conn)):
    v = _modelo_vals(data)
    cur = conn.execute(f"INSERT INTO cpe_modelos ({', '.join(v)}) VALUES ({', '.join('?' * len(v))})", tuple(v.values()))
    audit(conn, user["id"], "CREAR_MODELO_CPE", "cpe_modelo", cur.lastrowid, v["nombre"])
    return {"id": cur.lastrowid}


@app.put("/api/cpe-modelos/{mid}")
def editar_modelo(mid: int, data: ModeloIn, user=Depends(staff), conn=Depends(get_conn)):
    v = _modelo_vals(data)
    conn.execute(f"UPDATE cpe_modelos SET {', '.join(f'{k}=?' for k in v)} WHERE id=?", (*v.values(), mid))
    audit(conn, user["id"], "EDITAR_MODELO_CPE", "cpe_modelo", mid, v["nombre"])
    return {"ok": True}


# ---------------------------------------------------------------- bandeja de salida (avisos de cupos)
@app.get("/api/envios")
def listar_envios(estado: str = "PENDIENTE", user=Depends(staff), conn=Depends(get_conn)):
    data = rows(conn.execute(
        """SELECT e.*, c.numero, c.contraparte_nombre, c.contraparte_cuit, c.producto, c.corredor, u.nombre AS enviado_por_nombre
           FROM envios e JOIN contratos c ON c.id = e.contrato_compra_id LEFT JOIN usuarios u ON u.id = e.enviado_por
           WHERE e.estado = ? ORDER BY e.actualizado DESC LIMIT 300""", (estado,)))
    for e in data:
        e["cantidad"] = len(json.loads(e["cupo_ids"]))
        if estado == "PENDIENTE":
            e["destinatarios_lista"] = [d["email"] for d in avisos.destinatarios(conn, e)]
        e.pop("cuerpo_html", None)
    return data


@app.get("/api/envios/{eid}")
def ver_envio(eid: int, user=Depends(staff), conn=Depends(get_conn)):
    env = conn.execute("SELECT * FROM envios WHERE id=?", (eid,)).fetchone()
    if not env:
        raise HTTPException(404, "Envío inexistente")
    if env["estado"] != "PENDIENTE":  # lo enviado se muestra tal cual se mandó
        return {"envio": dict(env), "asunto": env["asunto"], "html": env["cuerpo_html"],
                "destinatarios": [{"email": x.strip()} for x in (env["destinatarios"] or "").split(",") if x.strip()]}
    a = avisos.armar(conn, eid)
    return {k: a[k] for k in ("envio", "asunto", "html", "destinatarios", "quitados")}


@app.get("/api/envios/{eid}/eml")
def envio_eml(eid: int, user=Depends(staff), conn=Depends(get_conn)):
    contenido = avisos.eml(conn, eid)
    return Response(contenido, media_type="message/rfc822",
                    headers={"Content-Disposition": f'attachment; filename="cupos_envio_{eid}.eml"'})


@app.post("/api/envios/{eid}/enviado")
def envio_enviado(eid: int, user=Depends(staff), conn=Depends(get_conn)):
    env = conn.execute("SELECT estado FROM envios WHERE id=?", (eid,)).fetchone()
    if not env or env["estado"] != "PENDIENTE":
        raise ReglaError("El envío no está pendiente")
    avisos.marcar_enviado(conn, eid, user)
    return {"ok": True}


@app.post("/api/envios/{eid}/descartar")
def envio_descartar(eid: int, user=Depends(staff), conn=Depends(get_conn)):
    conn.execute("UPDATE envios SET estado='DESCARTADO', actualizado=datetime('now','localtime') WHERE id=? AND estado='PENDIENTE'", (eid,))
    audit(conn, user["id"], "DESCARTAR_ENVIO", "envio", eid)
    return {"ok": True}


# ---------------------------------------------------------------- catálogo de puertos
@app.get("/api/puertos")
def listar_puertos(zona: str | None = None, user=Depends(staff), conn=Depends(get_conn)):
    where, params = "", []
    if zona:
        where, params = " WHERE p.zona = ?", [zona.upper()]
    return rows(conn.execute(
        f"""SELECT p.*, (SELECT COUNT(*) FROM cupos cu WHERE cu.destino = p.zona
                         AND COALESCE(cu.puerto, cu.puerto_asignado) = p.nombre) AS cupos
            FROM puertos p{where} ORDER BY p.zona, p.nombre""", params))


class PuertoIn(BaseModel):
    zona: str
    nombre: str


class PuertoUpd(BaseModel):
    activo: bool


@app.post("/api/puertos")
def crear_puerto(data: PuertoIn, user=Depends(admin), conn=Depends(get_conn)):
    zona, nombre = zonas.normalizar(data.zona)[0], data.nombre.strip().upper()
    if not zona or not nombre:
        raise ReglaError("Indicá zona y puerto")
    if conn.execute("SELECT 1 FROM puertos WHERE zona=? AND nombre=?", (zona, nombre)).fetchone():
        raise ReglaError(f"{nombre} ya está cargado en {zona}")
    cur = conn.execute("INSERT INTO puertos (zona, nombre) VALUES (?, ?)", (zona, nombre))
    audit(conn, user["id"], "CREAR_PUERTO", "puerto", cur.lastrowid, f"{zona} · {nombre}")
    return {"id": cur.lastrowid}


@app.patch("/api/puertos/{pid}")
def editar_puerto(pid: int, data: PuertoUpd, user=Depends(admin), conn=Depends(get_conn)):
    conn.execute("UPDATE puertos SET activo=? WHERE id=?", (int(data.activo), pid))
    audit(conn, user["id"], "EDITAR_PUERTO", "puerto", pid, "activo" if data.activo else "inactivo")
    return {"ok": True}


# ---------------------------------------------------------------- cupos
def _cupos_query(user, origen=None, estado=None, desde=None, hasta=None, destino=None, producto=None,
                 contrato_id=None, contrato_venta_id=None, q=None, puerto=None):
    where, params = [], []
    if puerto:  # terminal: la informada en el cupo o la elegida al asignar ("-" = sin terminal)
        where.append("COALESCE(cu.puerto, cu.puerto_asignado, '') = ?")
        params.append("" if puerto == "-" else puerto)
    if user["rol"] == "CLIENTE":
        where.append("cc.contraparte_cuit = ? AND cu.estado IN ('ASIGNADO','UTILIZADO')")
        params.append(user["cuit"])
    for col, val in (("cu.origen", origen), ("cu.destino", destino), ("cu.producto", producto),
                     ("cu.contrato_compra_id", contrato_id), ("cu.contrato_venta_id", contrato_venta_id)):
        if val not in (None, ""):
            where.append(f"{col} = ?")
            params.append(val)
    if estado:
        where.append(f"{ESTADO_VISIBLE} = ?")
        params.append(estado)
    if desde:
        where.append("cu.fecha >= ?")
        params.append(desde)
    if hasta:
        where.append("cu.fecha <= ?")
        params.append(hasta)
    if q:
        where.append("(cu.codigo LIKE ? OR cc.numero LIKE ? OR cc.contraparte_nombre LIKE ? OR cu.ctg LIKE ?)")
        params += [f"%{q}%"] * 4
    sql = f"""SELECT cu.*, {ESTADO_VISIBLE} AS estado_visible, COALESCE(cu.puerto, cu.puerto_asignado) AS puerto_efectivo,
                     cc.numero AS contrato_compra_numero, cc.contraparte_nombre AS contrato_compra_contraparte,
                     cc.corredor AS contrato_compra_corredor,
                     cv.numero AS contrato_venta_numero
              FROM cupos cu
              LEFT JOIN contratos cc ON cc.id = cu.contrato_compra_id
              LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
              {"WHERE " + " AND ".join(where) if where else ""}
              ORDER BY cu.fecha, cu.destino, cu.codigo"""
    return sql, params


@app.get("/api/cupos")
def listar_cupos(origen: str | None = None, estado: str | None = None, desde: str | None = None,
                 hasta: str | None = None, destino: str | None = None, producto: str | None = None,
                 contrato_id: int | None = None, contrato_venta_id: int | None = None, q: str | None = None,
                 puerto: str | None = None,
                 limit: int = 1000, user=Depends(current_user), conn=Depends(get_conn)):
    sql, params = _cupos_query(user, origen, estado, desde, hasta, destino, producto, contrato_id, contrato_venta_id, q, puerto)
    return rows(conn.execute(sql + " LIMIT ?", (*params, min(limit, 5000))))


@app.get("/api/cupos/export.csv")
def exportar_cupos(origen: str | None = None, estado: str | None = None, desde: str | None = None,
                   hasta: str | None = None, destino: str | None = None, producto: str | None = None,
                   q: str | None = None, puerto: str | None = None, user=Depends(current_user), conn=Depends(get_conn)):
    sql, params = _cupos_query(user, origen, estado, desde, hasta, destino, producto, None, None, q, puerto)
    data = rows(conn.execute(sql, params))
    cols = [("codigo", "Código"), ("fecha", "Fecha"), ("destino", "Destino"), ("puerto_efectivo", "Puerto"), ("producto", "Producto"),
            ("toneladas", "Toneladas"), ("origen", "Origen"), ("estado_visible", "Estado"),
            ("contrato_compra_numero", "Contrato compra"), ("contrato_compra_contraparte", "Vendedor"),
            ("contrato_venta_numero", "Contrato venta"), ("destinatario_nombre", "Destinatario"),
            ("ctg", "CTG")]
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow([c[1] for c in cols])
    for r in data:
        w.writerow([r.get(c[0]) if r.get(c[0]) is not None else "" for c in cols])
    return StreamingResponse(iter(["﻿" + buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=cupos.csv"})


@app.get("/api/filtros")
def filtros(user=Depends(current_user), conn=Depends(get_conn)):
    # Mismos destinos que el Tablero: los fijos, los de los contratos de compra y cualquiera con cupos
    dest = list(PUERTOS_TABLERO)
    dest += sorted({r[0] for r in conn.execute(
        "SELECT destino FROM cupos UNION SELECT lugar_entrega FROM contratos WHERE tipo='COMPRA'") if r[0]} - set(dest))
    prod = importers.catalogo_productos([r[0] for r in conn.execute(
        "SELECT producto FROM cupos UNION SELECT producto FROM contratos")])
    return {"destinos": dest, "productos": prod}


class AsignarIn(BaseModel):
    cupo_ids: list[int]
    contrato_id: int


@app.post("/api/cupos/asignar")
def asignar_cupos(data: AsignarIn, user=Depends(staff), conn=Depends(get_conn)):
    with transaction(conn):
        return services.asignar(conn, data.cupo_ids, data.contrato_id, user)


@app.post("/api/cupos/{cupo_id}/liberar")
def liberar_cupo(cupo_id: int, user=Depends(staff), conn=Depends(get_conn)):
    services.liberar(conn, cupo_id, user)
    return {"ok": True}


class CtgIn(BaseModel):
    ctg: str | None = None   # Código de Trazabilidad de Granos (12 dígitos, Carta de Porte Electrónica)


@app.post("/api/cupos/{cupo_id}/utilizar")
def utilizar_cupo(cupo_id: int, data: CtgIn, user=Depends(staff), conn=Depends(get_conn)):
    services.cambiar_estado(conn, cupo_id, user, "UTILIZADO", data.ctg)
    return {"ok": True}


@app.post("/api/cupos/{cupo_id}/anular")
def anular_cupo(cupo_id: int, user=Depends(staff), conn=Depends(get_conn)):
    services.cambiar_estado(conn, cupo_id, user, "ANULADO")
    return {"ok": True}


@app.post("/api/cupos/{cupo_id}/ctg")
def cargar_ctg(cupo_id: int, data: CtgIn, user=Depends(current_user), conn=Depends(get_conn)):
    """Carga manual del CTG de un cupo asignado (para los que no llegan automáticamente desde STOP,
    ej. cupos de contratos de venta). Lo puede cargar un operador o el cliente dueño del contrato."""
    cu = conn.execute(
        "SELECT cu.*, cc.contraparte_cuit FROM cupos cu LEFT JOIN contratos cc ON cc.id=cu.contrato_compra_id WHERE cu.id=?",
        (cupo_id,)).fetchone()
    if not cu or (user["rol"] == "CLIENTE" and cu["contraparte_cuit"] != user["cuit"]):
        raise HTTPException(404, "Cupo inexistente")
    services.cargar_ctg(conn, cupo_id, data.ctg, user)
    return {"ok": True}


class CuposVentaIn(BaseModel):
    contrato_venta_id: int
    codigos: str                      # separados por ";" (también se aceptan saltos de línea)
    fecha: str | None = None          # para los códigos que no traen la fecha (AAAAMMDD…) al comienzo
    destino: str | None = None        # por defecto, el lugar de entrega del contrato
    puerto: str | None = None         # terminal dentro del destino (obligatoria)
    toneladas: float | None = None
    observaciones: str | None = None


@app.post("/api/cupos/venta")
def alta_cupos_venta(data: CuposVentaIn, user=Depends(staff), conn=Depends(get_conn)):
    """Alta manual de uno o varios cupos de un contrato de venta.
    Producto y comprador salen del contrato; la fecha, del código de cupo si la trae."""
    cv = conn.execute("SELECT * FROM contratos WHERE id=? AND tipo='VENTA'", (data.contrato_venta_id,)).fetchone()
    if not cv:
        raise ReglaError("Elegí un contrato de venta")
    codigos = importers.separar_codigos(data.codigos)
    if not codigos:
        raise ReglaError("Pegá al menos un código de cupo")
    destino = (data.destino or cv["lugar_entrega"] or "").strip()
    if not destino:
        raise ReglaError("El contrato no tiene lugar de entrega: indicá el destino")
    if not (data.puerto or "").strip():
        raise ReglaError("Indicá la terminal: es obligatoria en los cupos de venta")
    fecha_def = importers.parse_date(data.fecha) if data.fecha else None
    filas = []
    for c in codigos:
        fecha = importers.fecha_de_codigo(c) or fecha_def
        filas.append({"codigo": c, "fecha": fecha, "destino": destino, "puerto": (data.puerto or "").strip() or None,
                      "producto": cv["producto"],
                      "contrato_venta": cv["numero"], "toneladas": data.toneladas,
                      "observaciones": data.observaciones})
    return importers.importar_cupos(conn, filas, "VENTA", f"alta manual {cv['numero']}", user["id"])


# ---------------------------------------------------------------- trazabilidad
def _traza_where(q, desde, hasta, producto, evento, origen):
    where, params = [], []
    if q:
        where.append("""(h.codigo LIKE ? OR h.contrato_compra_numero LIKE ? OR h.contrato_venta_numero LIKE ?
                         OR h.contrato_compra_contraparte LIKE ? OR h.contrato_venta_contraparte LIKE ? OR h.ctg LIKE ?)""")
        params += [f"%{q.strip()}%"] * 6
    for col, val in (("h.producto", producto), ("h.evento", evento), ("h.origen", origen)):
        if val:
            where.append(f"{col} = ?")
            params.append(val)
    if desde:
        where.append("h.fecha_cupo >= ?")
        params.append(desde)
    if hasta:
        where.append("h.fecha_cupo <= ?")
        params.append(hasta)
    return (" WHERE " + " AND ".join(where)) if where else "", params


TRAZA_EVENTOS = """SELECT h.*, u.nombre AS usuario_nombre FROM cupos_historial h
                   LEFT JOIN usuarios u ON u.id = h.usuario_id"""


@app.get("/api/trazabilidad")
def trazabilidad(modo: str = "cupos", q: str | None = None, desde: str | None = None, hasta: str | None = None,
                 producto: str | None = None, evento: str | None = None, origen: str | None = None,
                 user=Depends(staff), conn=Depends(get_conn)):
    """modo=cupos: un renglón por cupo con su contrato de venta, el de compra actual y el último asignado.
    modo=eventos: todos los eventos registrados. La búsqueda mira el historial completo, así un cupo
    aparece aunque ya se haya liberado del contrato buscado."""
    where, params = _traza_where(q, desde, hasta, producto, evento, origen)
    if modo == "eventos":
        return rows(conn.execute(TRAZA_EVENTOS + where + " ORDER BY h.id DESC LIMIT 2000", params))
    return rows(conn.execute(
        f"""SELECT cu.id, cu.codigo, cu.fecha, cu.destino, COALESCE(cu.puerto, cu.puerto_asignado) AS puerto,
                   cu.producto, cu.origen, cu.toneladas,
                   {ESTADO_VISIBLE} AS estado, cu.ctg,
                   cv.numero AS contrato_venta_numero, cv.contraparte_nombre AS contrato_venta_contraparte,
                   cc.numero AS contrato_compra_numero, cc.contraparte_nombre AS contrato_compra_contraparte,
                   cc.corredor AS contrato_compra_corredor, cv.corredor AS contrato_venta_corredor,
                   (SELECT h2.contrato_compra_numero || ' · ' || COALESCE(h2.contrato_compra_contraparte,'')
                      FROM cupos_historial h2 WHERE h2.cupo_id = cu.id AND h2.evento = 'ASIGNADO'
                      ORDER BY h2.id DESC LIMIT 1) AS ultimo_compra,
                   (SELECT COUNT(*) FROM cupos_historial h3 WHERE h3.cupo_id = cu.id AND h3.evento = 'ASIGNADO') AS veces_asignado,
                   (SELECT COUNT(*) FROM cupos_historial h4 WHERE h4.cupo_id = cu.id) AS eventos
            FROM cupos cu
            LEFT JOIN contratos cc ON cc.id = cu.contrato_compra_id
            LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE cu.id IN (SELECT h.cupo_id FROM cupos_historial h {where})
            ORDER BY cu.fecha DESC, cu.codigo LIMIT 2000""", params))


@app.get("/api/trazabilidad/export.csv")
def trazabilidad_csv(q: str | None = None, desde: str | None = None, hasta: str | None = None,
                     producto: str | None = None, evento: str | None = None, origen: str | None = None,
                     user=Depends(staff), conn=Depends(get_conn)):
    where, params = _traza_where(q, desde, hasta, producto, evento, origen)
    data = rows(conn.execute(TRAZA_EVENTOS + where + " ORDER BY h.codigo, h.id", params))
    cols = [("creado", "Fecha evento"), ("evento", "Evento"), ("codigo", "Cupo"), ("fecha_cupo", "Fecha cupo"),
            ("destino", "Destino"), ("puerto", "Puerto"), ("producto", "Producto"), ("origen", "Origen"), ("toneladas", "Toneladas"),
            ("contrato_compra_numero", "Contrato compra"), ("contrato_compra_contraparte", "Vendedor"),
            ("contrato_venta_numero", "Contrato venta"), ("contrato_venta_contraparte", "Comprador"),
            ("ctg", "CTG"), ("usuario_nombre", "Usuario"), ("detalle", "Detalle")]
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow([c[1] for c in cols])
    for r in data:
        w.writerow(["" if r.get(c[0]) is None else r.get(c[0]) for c in cols])
    return StreamingResponse(iter(["﻿" + buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=trazabilidad_cupos.csv"})


@app.get("/api/cupos/{cupo_id}/historial")
def historial_cupo(cupo_id: int, user=Depends(staff), conn=Depends(get_conn)):
    cu = conn.execute(
        f"""SELECT cu.*, {ESTADO_VISIBLE} AS estado_visible, COALESCE(cu.puerto, cu.puerto_asignado) AS puerto_efectivo,
                   cc.numero AS contrato_compra_numero,
                   cc.contraparte_nombre AS contrato_compra_contraparte, cv.numero AS contrato_venta_numero,
                   cv.contraparte_nombre AS contrato_venta_contraparte,
                   cc.corredor AS contrato_compra_corredor, cv.corredor AS contrato_venta_corredor
            FROM cupos cu LEFT JOIN contratos cc ON cc.id = cu.contrato_compra_id
            LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id WHERE cu.id = ?""", (cupo_id,)).fetchone()
    if not cu:
        raise HTTPException(404, "Cupo inexistente")
    eventos = rows(conn.execute(TRAZA_EVENTOS + " WHERE h.cupo_id = ? ORDER BY h.id", (cupo_id,)))
    return {"cupo": dict(cu), "eventos": eventos}


# ---------------------------------------------------------------- contratos
@app.get("/api/contratos")
def listar_contratos(tipo: str = "COMPRA", q: str | None = None, producto: str | None = None,
                     lugar: str | None = None, con_saldo: bool = False,
                     user=Depends(current_user), conn=Depends(get_conn)):
    tipo = tipo.upper()
    where, params = ["c.tipo = ?"], [tipo]
    if user["rol"] == "CLIENTE":
        if tipo != "COMPRA":
            raise HTTPException(403, "Sin permiso")
        where.append("c.contraparte_cuit = ?")
        params.append(user["cuit"])
    if q:
        where.append("(c.numero LIKE ? OR c.contraparte_nombre LIKE ? OR c.contraparte_cuit LIKE ?)")
        params += [f"%{q}%"] * 3
    if producto:
        where.append("c.producto = ?")
        params.append(producto)
    if lugar:
        where.append("UPPER(c.lugar_entrega) = UPPER(?)")
        params.append(lugar)
    base = CONTRATO_SELECT if tipo == "COMPRA" else CONTRATO_VENTA_SELECT
    sql = base + " WHERE " + " AND ".join(where) + " GROUP BY c.id"
    if con_saldo:
        sql += " HAVING saldo > 0 AND c.estado='VIGENTE'"
    return rows(conn.execute(sql + " ORDER BY c.fecha_hasta, c.numero", params))


@app.get("/api/contratos-opciones")
def opciones_contratos(tipo: str = "VENTA", user=Depends(staff), conn=Depends(get_conn)):
    """Productos y lugares de entrega que existen en los contratos de un tipo (para los filtros)."""
    tipo = tipo.upper()
    return {
        "productos": [r[0] for r in conn.execute(
            "SELECT DISTINCT producto FROM contratos WHERE tipo=? ORDER BY 1", (tipo,))],
        "lugares": [r[0] for r in conn.execute(
            "SELECT DISTINCT UPPER(lugar_entrega) FROM contratos WHERE tipo=? AND COALESCE(lugar_entrega,'') <> '' ORDER BY 1", (tipo,))],
    }


@app.get("/api/contratos/{contrato_id}")
def ver_contrato(contrato_id: int, user=Depends(current_user), conn=Depends(get_conn)):
    tipo = conn.execute("SELECT tipo, contraparte_cuit FROM contratos WHERE id=?", (contrato_id,)).fetchone()
    if not tipo or (user["rol"] == "CLIENTE" and (tipo["tipo"] != "COMPRA" or tipo["contraparte_cuit"] != user["cuit"])):
        raise HTTPException(404, "Contrato inexistente")
    base = CONTRATO_SELECT if tipo["tipo"] == "COMPRA" else CONTRATO_VENTA_SELECT
    c = dict(conn.execute(base + " WHERE c.id=? GROUP BY c.id", (contrato_id,)).fetchone())
    if tipo["tipo"] == "COMPRA":
        sql, params = _cupos_query(user, contrato_id=contrato_id)
    else:
        sql, params = _cupos_query(user, contrato_venta_id=contrato_id)
    c["cupos"] = rows(conn.execute(sql, params))
    return c


@app.get("/api/asignados-semana")
def asignados_semana(desde: str, hasta: str, user=Depends(staff), conn=Depends(get_conn)):
    """Cupos asignados (o utilizados) por contrato de compra y día, entre desde y hasta (para la vista en grilla)."""
    out: dict[int, dict[str, int]] = {}
    for r in conn.execute(
            """SELECT contrato_compra_id, fecha, COUNT(*) FROM cupos
               WHERE contrato_compra_id IS NOT NULL AND estado IN ('ASIGNADO','UTILIZADO') AND fecha BETWEEN ? AND ?
               GROUP BY 1, 2""", (desde, hasta)):
        out.setdefault(r[0], {})[r[1]] = r[2]
    return out


@app.get("/api/contratos/{contrato_id}/candidatos")
def candidatos_contrato(contrato_id: int, destino: str | None = None, origen: str | None = None,
                        desde: str | None = None, hasta: str | None = None, terminal: str | None = None,
                        user=Depends(staff), conn=Depends(get_conn)):
    """Cupos disponibles que se pueden asignar a un contrato de compra: mismo producto y no vencidos.
    Primero los que caen dentro del período de entrega, después por fecha.
    terminales: disponibilidad por terminal con los demás filtros (para elegir a qué terminal asignar)."""
    c = services.contrato_compra(conn, contrato_id)
    where = ["cu.estado='DISPONIBLE'", "cu.fecha >= date('now','localtime')", "cu.producto = ?"]
    params = [c["producto"]]
    for col, val in (("cu.destino", destino), ("cu.origen", origen)):
        if val:
            where.append(f"{col} = ?")
            params.append(val)
    if desde:
        where.append("cu.fecha >= ?")
        params.append(desde)
    if hasta:
        where.append("cu.fecha <= ?")
        params.append(hasta)
    terminales = rows(conn.execute(
        f"""SELECT COALESCE(cu.puerto, '') AS terminal, cu.destino, COUNT(*) AS disponibles
            FROM cupos cu WHERE {" AND ".join(where)} GROUP BY 1, 2 ORDER BY (terminal = ''), cu.destino, 3 DESC""", params))
    if terminal is not None and terminal != "*":
        where.append("COALESCE(cu.puerto, '') = ?")
        params.append(terminal)
    data = rows(conn.execute(
        f"""SELECT cu.*, cv.numero AS contrato_venta_numero, cv.contraparte_nombre AS contrato_venta_contraparte,
                   (COALESCE(? <= cu.fecha, 1) AND COALESCE(cu.fecha <= ?, 1)) AS en_periodo
            FROM cupos cu LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
            WHERE {" AND ".join(where)}
            ORDER BY en_periodo DESC, cu.fecha, cu.destino, cu.codigo LIMIT 500""",
        (c["fecha_desde"], c["fecha_hasta"], *params)))
    return {"contrato": c, "cupos": data, "terminales": terminales}


# ---------------------------------------------------------------- solicitudes
SOLICITUD_SELECT = """
SELECT s.*, c.numero AS contrato_numero, c.producto, c.contraparte_nombre, c.contraparte_cuit,
       u.nombre AS usuario_nombre, r.nombre AS resuelto_por_nombre
FROM solicitudes s
JOIN contratos c ON c.id = s.contrato_compra_id
JOIN usuarios u ON u.id = s.usuario_id
LEFT JOIN usuarios r ON r.id = s.resuelto_por
"""


@app.get("/api/solicitudes")
def listar_solicitudes(estado: str | None = None, user=Depends(current_user), conn=Depends(get_conn)):
    where, params = [], []
    if user["rol"] == "CLIENTE":
        where.append("c.contraparte_cuit = ?")
        params.append(user["cuit"])
    if estado == "ABIERTAS":
        where.append("s.estado IN ('PENDIENTE','PARCIAL')")
    elif estado and estado != "TODAS":
        where.append("s.estado = ?")
        params.append(estado)
    sql = SOLICITUD_SELECT + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY s.fecha, s.creado"
    data = rows(conn.execute(sql, params))
    for s in data:
        s["cupos"] = rows(conn.execute(
            "SELECT id, codigo, fecha, destino, estado, ctg FROM cupos WHERE solicitud_id=? ORDER BY fecha",
            (s["id"],)))
    return data


class SolicitudIn(BaseModel):
    contrato_compra_id: int
    fecha: str
    cantidad: int = Field(gt=0, le=200)
    destino_preferido: str | None = None
    observaciones: str | None = None


@app.post("/api/solicitudes")
def crear_solicitud(data: SolicitudIn, user=Depends(current_user), conn=Depends(get_conn)):
    if user["rol"] != "CLIENTE":
        raise HTTPException(403, "Solo los clientes crean solicitudes")
    sid = services.crear_solicitud(conn, user, data.contrato_compra_id, importers.parse_date(data.fecha),
                                   data.cantidad, data.destino_preferido, data.observaciones,
                                   importers.TONELADAS_POR_CUPO)
    return {"id": sid}


@app.post("/api/solicitudes/{sid}/cancelar")
def cancelar_solicitud(sid: int, user=Depends(current_user), conn=Depends(get_conn)):
    s = conn.execute("SELECT * FROM solicitudes WHERE id=?", (sid,)).fetchone()
    if not s or (user["rol"] == "CLIENTE" and s["usuario_id"] != user["id"]):
        raise HTTPException(404, "Solicitud inexistente")
    if s["estado"] != "PENDIENTE":
        raise ReglaError("Solo se cancelan solicitudes pendientes sin cupos aprobados")
    conn.execute("UPDATE solicitudes SET estado='CANCELADA' WHERE id=?", (sid,))
    audit(conn, user["id"], "CANCELAR", "solicitud", sid)
    return {"ok": True}


@app.get("/api/solicitudes/{sid}/candidatos")
def candidatos(sid: int, user=Depends(staff), conn=Depends(get_conn)):
    """Cupos disponibles compatibles: mismo producto, no vencidos; primero el destino preferido y la fecha pedida."""
    s = conn.execute(SOLICITUD_SELECT + " WHERE s.id=?", (sid,)).fetchone()
    if not s:
        raise HTTPException(404, "Solicitud inexistente")
    # El destino pedido se compara por zona (ej. "Rosario" -> UPRIVER) y, si es una localidad/terminal, por puerto
    zona, detalle = zonas.normalizar(s["destino_preferido"]) if s["destino_preferido"] else (None, None)
    return rows(conn.execute(
        """SELECT cu.*, cv.numero AS contrato_venta_numero,
                  ABS(julianday(cu.fecha) - julianday(?)) AS distancia
           FROM cupos cu LEFT JOIN contratos cv ON cv.id = cu.contrato_venta_id
           WHERE cu.estado='DISPONIBLE' AND cu.fecha >= date('now','localtime') AND cu.producto = ?
           ORDER BY (cu.destino = COALESCE(?, cu.destino)) DESC, (COALESCE(cu.puerto, '') = COALESCE(?, '')) DESC,
                    distancia, cu.fecha, cu.codigo
           LIMIT 300""",
        (s["fecha"], s["producto"], zona, detalle)))


class AprobarIn(BaseModel):
    cupo_ids: list[int]
    respuesta: str | None = None


@app.post("/api/solicitudes/{sid}/aprobar")
def aprobar(sid: int, data: AprobarIn, user=Depends(staff), conn=Depends(get_conn)):
    return services.aprobar_solicitud(conn, sid, data.cupo_ids, data.respuesta, user)


class RechazarIn(BaseModel):
    respuesta: str


@app.post("/api/solicitudes/{sid}/rechazar")
def rechazar(sid: int, data: RechazarIn, user=Depends(staff), conn=Depends(get_conn)):
    services.rechazar_solicitud(conn, sid, data.respuesta, user)
    return {"ok": True}


# ---------------------------------------------------------------- importaciones
@app.post("/api/importar/{tipo}")
async def importar(tipo: str, archivo: UploadFile = File(...), user=Depends(staff), conn=Depends(get_conn)):
    """tipo: stop | venta (cupos) | sigam_compra | sigam_venta (contratos)."""
    tipo = tipo.upper()
    if tipo not in ("STOP", "VENTA", "SIGAM_COMPRA", "SIGAM_VENTA"):
        raise HTTPException(404, "Tipo de importación inválido")
    content = await archivo.read()
    if len(content) > 20 * 1024 * 1024:
        raise ReglaError("Archivo demasiado grande (máx. 20 MB)")
    filas = importers.read_table(archivo.filename, content)
    if tipo.startswith("SIGAM_"):
        return importers.importar_contratos(conn, filas, tipo.removeprefix("SIGAM_"), archivo.filename, user["id"])
    return importers.importar_cupos(conn, filas, tipo, archivo.filename, user["id"])


@app.get("/api/stop/estado")
def stop_estado(user=Depends(staff), conn=Depends(get_conn)):
    return stop.estado(conn)


@app.get("/api/stop/terminales")
def stop_terminales(user=Depends(staff), conn=Depends(get_conn)):
    return rows(conn.execute(
        """SELECT t.*, (SELECT COUNT(*) FROM stop_turnos s WHERE s.id_terminal = t.id_terminal) AS turnos
           FROM stop_terminales t ORDER BY t.zona, t.descripcion"""))


class TerminalUpd(BaseModel):
    zona: str
    puerto: str | None = None


@app.patch("/api/stop/terminales/{id_terminal}")
def stop_terminal_editar(id_terminal: int, data: TerminalUpd, user=Depends(admin), conn=Depends(get_conn)):
    """Asocia una terminal de STOP con nuestro destino (zona) y puerto. Queda fija aunque STOP la vuelva a informar."""
    zona = zonas.normalizar(data.zona)[0]
    puerto = (data.puerto or "").strip().upper() or None
    conn.execute("UPDATE stop_terminales SET zona=?, puerto=?, editado=1 WHERE id_terminal=?", (zona, puerto, id_terminal))
    if puerto:
        importers.asegurar_puerto(conn, zona, puerto)
    audit(conn, user["id"], "STOP_TERMINAL", "stop_terminal", id_terminal, f"{zona} · {puerto or '-'}")
    return {"ok": True}


@app.post("/api/sync/{fuente}")
def sincronizar(fuente: str, user=Depends(staff), conn=Depends(get_conn)):
    fuente = fuente.upper()
    try:
        if fuente == "STOP":
            if stop.modo() != "desactivado" or not connectors.estado().get("STOP"):
                return stop.sincronizar(conn, user["id"], "manual")
            return connectors.sync_stop(conn, user["id"])  # alternativa: archivo exportado (STOP_EXPORT_PATH)
        if fuente in ("SIGAM_COMPRA", "SIGAM_VENTA"):
            return connectors.sync_sigam(conn, fuente.removeprefix("SIGAM_"), user["id"])
    except (connectors.NoConfigurado, stop.StopError) as e:
        raise ReglaError(str(e))
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError) as e:
        raise ReglaError(f"Error al conectar con {fuente}: {e}")
    raise HTTPException(404, "Fuente inválida")


@app.get("/api/conectores")
def estado_conectores(user=Depends(staff)):
    return connectors.estado()


@app.get("/api/importaciones")
def listar_importaciones(user=Depends(staff), conn=Depends(get_conn)):
    data = rows(conn.execute(
        """SELECT i.*, u.nombre AS usuario_nombre FROM importaciones i
           LEFT JOIN usuarios u ON u.id = i.usuario_id ORDER BY i.id DESC LIMIT 100"""))
    for r in data:
        r["detalle"] = json.loads(r["detalle"] or "[]")
    return data


@app.get("/api/auditoria")
def auditoria(user=Depends(staff), conn=Depends(get_conn)):
    return rows(conn.execute(
        """SELECT a.*, u.nombre AS usuario_nombre FROM auditoria a
           LEFT JOIN usuarios u ON u.id = a.usuario_id ORDER BY a.id DESC LIMIT 300"""))


# ---------------------------------------------------------------- usuarios
class UsuarioIn(BaseModel):
    email: str
    nombre: str
    rol: str
    password: str = Field(min_length=8)
    cuit: str | None = None


class UsuarioUpd(BaseModel):
    nombre: str | None = None
    rol: str | None = None
    cuit: str | None = None
    activo: bool | None = None
    password: str | None = Field(default=None, min_length=8)


def _validar_usuario(rol, cuit):
    if rol not in ("ADMIN", "OPERADOR", "CLIENTE"):
        raise ReglaError("Rol inválido")
    if rol == "CLIENTE" and len(importers.cuit_digits(cuit)) != 11:
        raise ReglaError("Un cliente necesita un CUIT de 11 dígitos")


@app.get("/api/usuarios")
def listar_usuarios(user=Depends(admin), conn=Depends(get_conn)):
    data = rows(conn.execute("SELECT id, email, nombre, rol, cuit, activo, creado FROM usuarios ORDER BY rol, nombre"))
    for u in data:
        if u["cuit"]:
            r = conn.execute("SELECT contraparte_nombre FROM contratos WHERE contraparte_cuit=? LIMIT 1", (u["cuit"],)).fetchone()
            u["razon_social"] = r[0] if r else None
    return data


@app.post("/api/usuarios")
def crear_usuario(data: UsuarioIn, user=Depends(admin), conn=Depends(get_conn)):
    rol = data.rol.upper()
    _validar_usuario(rol, data.cuit)
    if conn.execute("SELECT 1 FROM usuarios WHERE email=?", (data.email.strip(),)).fetchone():
        raise ReglaError("Ya existe un usuario con ese email")
    cur = conn.execute(
        "INSERT INTO usuarios (email, nombre, password_hash, rol, cuit) VALUES (?,?,?,?,?)",
        (data.email.strip(), data.nombre.strip(), hash_password(data.password), rol,
         importers.cuit_digits(data.cuit) if rol == "CLIENTE" else None))
    audit(conn, user["id"], "CREAR_USUARIO", "usuario", cur.lastrowid, data.email)
    avisos.sync_contacto_usuario(conn, cur.lastrowid)  # los clientes registrados reciben los avisos de cupos
    return {"id": cur.lastrowid}


@app.patch("/api/usuarios/{uid}")
def editar_usuario(uid: int, data: UsuarioUpd, user=Depends(admin), conn=Depends(get_conn)):
    u = conn.execute("SELECT * FROM usuarios WHERE id=?", (uid,)).fetchone()
    if not u:
        raise HTTPException(404, "Usuario inexistente")
    rol = (data.rol or u["rol"]).upper()
    cuit = data.cuit if data.cuit is not None else u["cuit"]
    _validar_usuario(rol, cuit)
    if uid == user["id"] and (data.activo is False or rol != "ADMIN"):
        raise ReglaError("No podés desactivarte ni quitarte el rol de administrador")
    conn.execute(
        "UPDATE usuarios SET nombre=?, rol=?, cuit=?, activo=? WHERE id=?",
        (data.nombre or u["nombre"], rol, importers.cuit_digits(cuit) if rol == "CLIENTE" else None,
         int(data.activo) if data.activo is not None else u["activo"], uid))
    if data.password:
        conn.execute("UPDATE usuarios SET password_hash=? WHERE id=?", (hash_password(data.password), uid))
        conn.execute("DELETE FROM sesiones WHERE usuario_id=?", (uid,))
    if data.activo is False:
        conn.execute("DELETE FROM sesiones WHERE usuario_id=?", (uid,))
    audit(conn, user["id"], "EDITAR_USUARIO", "usuario", uid)
    avisos.sync_contacto_usuario(conn, uid)
    return {"ok": True}


# ---------------------------------------------------------------- frontend
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")
